#!/usr/bin/env node
/* Release guard: one version for PC + phone + changelog + service worker. */
const fs = require('fs');
const path = require('path');

const root = path.resolve(__dirname, '..');
const read = (name) => fs.readFileSync(path.join(root, name), 'utf8');
const pkg = JSON.parse(read('package.json'));
const errors = [];

const app = read('app/app.js');
const changelog = app.match(/const CHANGELOG\s*=\s*\[([\s\S]*?)\n\];/);
const first = changelog && changelog[1].match(/\['([^']+)'/);
const changelogVersion = first ? first[1] : '';
if (changelogVersion !== pkg.version) {
  errors.push(`changelog top is ${changelogVersion || 'missing'}, expected ${pkg.version}`);
}

const manifest = read('android/AndroidManifest.xml');
const androidName = (manifest.match(/android:versionName="([^"]+)"/) || [])[1] || '';
const androidCode = (manifest.match(/android:versionCode="([^"]+)"/) || [])[1] || '';
if (androidName !== pkg.version) {
  errors.push(`Android versionName is ${androidName || 'missing'}, expected ${pkg.version}`);
}
if (!androidCode) errors.push('Android versionCode is missing');

const sw = (read('app/sw.js').match(/xphoto-shell-v([0-9.]+)/) || [])[1] || '';
if (sw !== pkg.version) errors.push(`service worker cache is ${sw || 'missing'}, expected ${pkg.version}`);

const readme = read('README.md');
if (!readme.includes(`**${pkg.version}（versionCode ${androidCode}`)) {
  errors.push(`README does not mention ${pkg.version} (versionCode ${androidCode})`);
}

if (errors.length) {
  console.error('RELEASE CHECK FAILED');
  for (const error of errors) console.error(' - ' + error);
  process.exit(1);
}
console.log(`RELEASE CHECK OK  xphoto ${pkg.version} / Android ${androidCode}`);
