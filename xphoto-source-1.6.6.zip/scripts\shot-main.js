'use strict';

const { app, BrowserWindow } = require('electron');
const fs = require('fs');
const os = require('os');
const path = require('path');

console.log('BOOT shot-main');
process.on('uncaughtException', (error) => { console.error('UNCAUGHT', error); app.exit(1); });

app.setPath('userData', path.join(os.tmpdir(), 'xphoto-shot', `${process.pid}-${Date.now()}`));

const url = process.env.XPHOTO_URL || process.argv[2] || 'http://127.0.0.1:18575/';
const width = Number(process.env.XPHOTO_WIDTH || process.argv[2] || 1440);
const height = Number(process.env.XPHOTO_HEIGHT || process.argv[3] || 900);
const out = process.env.XPHOTO_OUT || process.argv[4] || path.join(process.cwd(), '.shots', 'electron.png');
let script = process.env.XPHOTO_EVAL || process.argv[5] || '';
if (script.startsWith('@')) {
  script = fs.readFileSync(script.slice(1), 'utf8');
}

app.whenReady().then(async () => {
  const win = new BrowserWindow({
    width, height, show: false,
    webPreferences: { contextIsolation: true, nodeIntegration: false, sandbox: true }
  });
  const logs = [];
  win.webContents.on('console-message', (_event, level, message, line, sourceId) => {
    logs.push(`[${level}] ${message} (${sourceId}:${line})`);
  });
  win.webContents.on('render-process-gone', (_event, details) => logs.push(`CRASH ${JSON.stringify(details)}`));
  win.webContents.session.webRequest.onErrorOccurred({ urls: ['*://*/*'] }, (details) => {
    if (details.url.includes('/api/')) logs.push(`NETFAIL ${details.error} ${details.url}`);
  });
  win.webContents.session.webRequest.onCompleted({ urls: ['*://*/*'] }, (details) => {
    if (details.url.includes('/api/')) logs.push(`NET ${details.statusCode} ${details.url}`);
  });
  await win.loadURL(url);
  if (process.env.XPHOTO_SHOW === '1') win.showInactive();
  await new Promise((resolve) => setTimeout(resolve, Number(process.env.XPHOTO_WAIT || 5200)));
  if (script) {
    try {
      const value = await win.webContents.executeJavaScript(script, true);
      console.log('EVAL ' + JSON.stringify(value, null, 2));
    } catch (error) {
      console.log('EVAL_ERROR ' + error.message);
    }
    await new Promise((resolve) => setTimeout(resolve, 600));
  }
  fs.mkdirSync(path.dirname(out), { recursive: true });
  const image = await win.webContents.capturePage();
  fs.writeFileSync(out, image.toPNG());
  console.log('SHOT ' + out + ' ' + image.getSize().width + 'x' + image.getSize().height);
  console.log('LOGS ' + JSON.stringify(logs));
  win.destroy();
  app.quit();
}).catch((error) => {
  console.error('FATAL', error);
  app.exit(1);
});
