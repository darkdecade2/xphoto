'use strict';

const { execFile } = require('child_process');
const fs = require('fs');
const path = require('path');

const CANDIDATES = [
  process.env.TAILSCALE_PATH,
  'C:\\Program Files\\Tailscale\\tailscale.exe',
  'C:\\Program Files (x86)\\Tailscale\\tailscale.exe'
].filter(Boolean);

function findBinary() {
  for (const candidate of CANDIDATES) {
    try {
      if (fs.existsSync(candidate)) return candidate;
    } catch {}
  }
  return 'tailscale';
}

function run(args, timeout = 4000) {
  return new Promise((resolve) => {
    execFile(findBinary(), args, { timeout, windowsHide: true }, (error, stdout, stderr) => {
      resolve({ error, stdout: String(stdout || '').trim(), stderr: String(stderr || '').trim() });
    });
  });
}

class Tailscale {
  constructor() {
    this.cache = { at: 0, value: null };
  }

  async info(force = false) {
    if (!force && this.cache.value && Date.now() - this.cache.at < 8000) return this.cache.value;
    const ipResult = await run(['ip', '-4']);
    const ip = (ipResult.stdout || '').split(/\s+/).find((value) => /^\d+\.\d+\.\d+\.\d+$/.test(value)) || '';
    if (!ip) {
      const value = {
        installed: false,
        online: false,
        ip: '',
        dnsName: '',
        error: ipResult.error ? '未检测到 Tailscale，请先安装并登录' : 'Tailscale 未登录或未启动'
      };
      this.cache = { at: Date.now(), value };
      return value;
    }

    const statusResult = await run(['status', '--json']);
    let online = true;
    let dnsName = '';
    let version = '';
    if (!statusResult.error && statusResult.stdout) {
      try {
        const status = JSON.parse(statusResult.stdout);
        online = status.Self ? Boolean(status.Self.Online) : true;
        dnsName = status.Self && status.Self.DNSName ? String(status.Self.DNSName).replace(/\.$/, '') : '';
        version = status.Version || '';
      } catch {}
    }
    const value = { installed: true, online, ip, dnsName, version, error: '' };
    this.cache = { at: Date.now(), value };
    return value;
  }
}

function isTailscaleAddress(value) {
  const ip = String(value || '').replace(/^::ffff:/, '').toLowerCase();
  if (ip.startsWith('fd7a:115c:a1e0:')) return true;
  const parts = ip.split('.').map(Number);
  return parts.length === 4 && parts[0] === 100 && parts[1] >= 64 && parts[1] <= 127;
}

module.exports = { Tailscale, isTailscaleAddress };
