package com.xphoto.app;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.DownloadManager;
import android.content.BroadcastReceiver;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.text.InputType;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.URLUtil;
import android.webkit.ValueCallback;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.json.JSONArray;

public class MainActivity extends Activity implements LocalGalleryView.Listener {
    static final String PREFS = "xphoto";
    private static final String PREF_URL = "url";
    private static final int REQ_MEDIA = 41;
    private static final int REQ_WRITE = 42;

    private LocalGalleryView localView;
    private WebView webView;
    private FrameLayout webRoot;
    private ProgressBar progress;
    private SharedPreferences prefs;
    private final Handler main = new Handler(Looper.getMainLooper());
    private boolean downloadReceiverRegistered;

    private final BroadcastReceiver downloadReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) {
            Toast.makeText(MainActivity.this, "照片已保存到「下载/xphoto」", Toast.LENGTH_LONG).show();
            if (localView != null) localView.refresh();
        }
    };

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        setLightBars();
        showLocal();
        handleIncoming(getIntent());
        if (!hasMediaPermission()) requestMediaPermission();
        IntentFilter filter = new IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE);
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(downloadReceiver, filter, Context.RECEIVER_NOT_EXPORTED);
        } else {
            registerReceiver(downloadReceiver, filter);
        }
        downloadReceiverRegistered = true;
    }

    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleIncoming(intent);
    }

    private void handleIncoming(Intent intent) {
        if (intent == null || !Intent.ACTION_VIEW.equals(intent.getAction())) return;
        Uri uri = intent.getData();
        if (uri == null) return;
        String mime = getContentResolver().getType(uri);
        boolean video = mime != null && mime.startsWith("video/");
        if (video) {
            if (PhotoViewerDialog.playExternal(this, uri)) return;
            PhotoViewerDialog.showVideo(this, uri, "视频");
            return;
        }
        String name = uri.getLastPathSegment();
        if (name == null) name = "图片";
        ArrayList<PhotoItem> list = new ArrayList<>();
        list.add(new PhotoItem(-1, name, "其他应用", System.currentTimeMillis(), 0, uri, false, false, false, uri.toString()));
        PhotoViewerDialog.show(this, list, 0);
    }

    private int dp(float value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private GradientDrawable rounded(int color, float radiusDp) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radiusDp));
        return d;
    }

    private void setLightBars() {
        getWindow().setStatusBarColor(0xFFF5F7FC);
        getWindow().setNavigationBarColor(0xFFF5F7FC);
        int flags = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
        if (Build.VERSION.SDK_INT >= 26) flags |= View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
        getWindow().getDecorView().setSystemUiVisibility(flags);
    }

    private void hideKeyboard() {
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm != null && getCurrentFocus() != null) imm.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(), 0);
    }

    private String[] mediaPermissions() {
        if (Build.VERSION.SDK_INT >= 33) {
            return new String[]{Manifest.permission.READ_MEDIA_IMAGES, Manifest.permission.READ_MEDIA_VIDEO};
        }
        return new String[]{Manifest.permission.READ_EXTERNAL_STORAGE};
    }

    private boolean hasMediaPermission() {
        for (String permission : mediaPermissions()) {
            if (checkSelfPermission(permission) != PackageManager.PERMISSION_GRANTED) return false;
        }
        return true;
    }

    private void requestMediaPermission() {
        requestPermissions(mediaPermissions(), REQ_MEDIA);
    }

    private void showLocal() {
        destroyWeb();
        if (localView == null) {
            localView = new LocalGalleryView(this, this);
        }
        localView.setPermissionGranted(hasMediaPermission());
        setContentView(localView);
        localView.refresh();
    }

    private void destroyWeb() {
        if (webView != null) {
            webView.stopLoading();
            webView.loadUrl("about:blank");
            webView.removeAllViews();
            webView.destroy();
            webView = null;
        }
        webRoot = null;
        progress = null;
    }

    @Override public void onConnectRequested() {
        openConnectDialog();
    }

    @Override public void onPermissionRequested() {
        requestMediaPermission();
    }

    private void openConnectDialog() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(22), dp(10), dp(22), dp(4));

        TextView hint = new TextView(this);
        hint.setText("支持两种连接：同一 Wi-Fi 下粘贴电脑端「局域网」网址；不在同一网络时，粘贴电脑端「Tailscale」里的 100.x 网址，并在打开后输入访问密码。");
        hint.setTextColor(0xFF667085);
        hint.setTextSize(12);
        hint.setLineSpacing(dp(3), 1f);
        box.addView(hint);

        EditText input = new EditText(this);
        input.setHint("局域网 http://192.168.x.x:18573/?t=... 或 Tailscale http://100.x.x.x:18573/");
        input.setText(prefs.getString(PREF_URL, ""));
        input.setTextSize(13);
        input.setSingleLine(false);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        input.setPadding(dp(10), dp(10), dp(10), dp(10));
        input.setBackground(rounded(0xFFF2F5FB, 12));
        LinearLayout.LayoutParams inputParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        inputParams.topMargin = dp(12);
        box.addView(input, inputParams);

        TextView paste = new TextView(this);
        paste.setText("粘贴网址");
        paste.setTextColor(0xFF356DF3);
        paste.setTextSize(12);
        paste.setPadding(0, dp(10), 0, dp(4));
        paste.setOnClickListener(v -> {
            ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            if (cm != null && cm.hasPrimaryClip()) {
                ClipData clip = cm.getPrimaryClip();
                if (clip != null && clip.getItemCount() > 0) {
                    input.setText(String.valueOf(clip.getItemAt(0).coerceToText(this)));
                }
            }
        });
        box.addView(paste);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("连接电脑")
                .setView(box)
                .setNegativeButton("取消", null)
                .create();

        Button connect = new Button(this);
        connect.setText("连接");
        connect.setAllCaps(false);
        connect.setTextColor(Color.WHITE);
        connect.setBackground(rounded(0xFF356DF3, 12));
        connect.setOnClickListener(v -> {
            String url = normalizeUrl(input.getText().toString());
            if (url.isEmpty()) {
                Toast.makeText(this, "请先粘贴电脑上的访问网址", Toast.LENGTH_SHORT).show();
                return;
            }
            prefs.edit().putString(PREF_URL, url).apply();
            hideKeyboard();
            dialog.dismiss();
            showRemote(url);
        });
        LinearLayout.LayoutParams connectParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(44));
        connectParams.topMargin = dp(12);
        box.addView(connect, connectParams);

        dialog.show();
    }

    private String normalizeUrl(String raw) {
        String url = raw == null ? "" : raw.trim();
        if (url.isEmpty()) return "";
        if (!url.startsWith("http://") && !url.startsWith("https://")) url = "http://" + url;
        while (url.endsWith("/")) url = url.substring(0, url.length() - 1);
        return url;
    }

    private void showRemote(String url) {
        destroyWeb();
        webRoot = new FrameLayout(this);
        webRoot.setBackgroundColor(0xFFF5F7FC);

        webView = new WebView(this);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setLoadsImagesAutomatically(true);
        settings.setCacheMode(WebSettings.LOAD_NO_CACHE);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setSupportZoom(false);
        CookieManager.getInstance().setAcceptCookie(true);

        progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progress.setMax(100);
        progress.setProgress(0);
        progress.setVisibility(View.GONE);
        FrameLayout.LayoutParams progressParams = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(3), Gravity.TOP);
        webRoot.addView(webView, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        webRoot.addView(progress, progressParams);

        webView.addJavascriptInterface(new Bridge(), "XPhotoAndroid");
        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return handleUri(request.getUrl());
            }

            @Override public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return handleUri(Uri.parse(url));
            }

            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if (uri != null && "xphoto.local".equals(uri.getHost())) return localMedia(uri);
                return null;
            }

            @Override public void onPageStarted(WebView view, String url, Bitmap favicon) {
                if (progress != null) progress.setVisibility(View.VISIBLE);
            }

            @Override public void onPageFinished(WebView view, String url) {
                if (progress != null) {
                    progress.setProgress(100);
                    progress.setVisibility(View.GONE);
                }
            }

            @Override public void onReceivedError(WebView view, WebResourceRequest request, android.webkit.WebResourceError error) {
                if (request.isForMainFrame()) failRemote(error.getDescription().toString());
            }

            @Override public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
                failRemote(description);
            }
        });

        webView.setDownloadListener((downloadUrl, userAgent, contentDisposition, mimeType, contentLength) ->
                requestDownload(downloadUrl, contentDisposition, mimeType));

        setContentView(webRoot);
        webView.loadUrl(url);
    }

    private WebResourceResponse localMedia(Uri requestUri) {
        try {
            String raw = requestUri.getQueryParameter("u");
            if (raw == null) return null;
            Uri image = Uri.parse(raw);
            int target = 480;
            try { target = Integer.parseInt(requestUri.getQueryParameter("w")); } catch (Exception ignored) {}
            target = Math.max(120, Math.min(2048, target));
            ContentResolver resolver = getContentResolver();
            String mime = resolver.getType(image);
            Bitmap bitmap;
            if (mime != null && mime.startsWith("video/")) {
                bitmap = videoFrame(image);
            } else {
                BitmapFactory.Options bounds = new BitmapFactory.Options();
                bounds.inJustDecodeBounds = true;
                try (InputStream in = resolver.openInputStream(image)) {
                    BitmapFactory.decodeStream(in, null, bounds);
                }
                int sample = 1;
                int longest = Math.max(bounds.outWidth, bounds.outHeight);
                while (longest / sample > target * 2) sample *= 2;
                BitmapFactory.Options options = new BitmapFactory.Options();
                options.inSampleSize = sample;
                try (InputStream in = resolver.openInputStream(image)) {
                    bitmap = BitmapFactory.decodeStream(in, null, options);
                }
            }
            if (bitmap == null) return null;
            int max = Math.max(bitmap.getWidth(), bitmap.getHeight());
            if (max > target) {
                float ratio = (float) target / max;
                Bitmap scaled = Bitmap.createScaledBitmap(bitmap,
                        Math.max(1, Math.round(bitmap.getWidth() * ratio)),
                        Math.max(1, Math.round(bitmap.getHeight() * ratio)), true);
                if (scaled != bitmap) bitmap.recycle();
                bitmap = scaled;
            }
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            bitmap.compress(Bitmap.CompressFormat.JPEG, 84, out);
            bitmap.recycle();
            Map<String, String> headers = new HashMap<>();
            headers.put("Cache-Control", "no-store");
            return new WebResourceResponse("image/jpeg", "UTF-8",
                    new ByteArrayInputStream(out.toByteArray()));
        } catch (Exception error) {
            return null;
        }
    }

    private Bitmap videoFrame(Uri uri) {
        MediaMetadataRetriever retriever = new MediaMetadataRetriever();
        try {
            retriever.setDataSource(this, uri);
            if (Build.VERSION.SDK_INT >= 27) {
                return retriever.getScaledFrameAtTime(0, MediaMetadataRetriever.OPTION_CLOSEST_SYNC,
                        dp(480), dp(480));
            }
            return retriever.getFrameAtTime(0, MediaMetadataRetriever.OPTION_CLOSEST_SYNC);
        } catch (Exception error) {
            return null;
        } finally {
            try { retriever.release(); } catch (Exception ignored) {}
        }
    }

    private boolean handleUri(Uri uri) {
        String scheme = uri.getScheme() == null ? "" : uri.getScheme().toLowerCase();
        if ("http".equals(scheme) || "https".equals(scheme)) return false;
        if ("content".equals(scheme) || "file".equals(scheme)) {
            return PhotoViewerDialog.playExternal(this, uri);
        }
        return false;
    }

    private void failRemote(String description) {
        if (progress != null) progress.setVisibility(View.GONE);
        new AlertDialog.Builder(this)
                .setTitle("连不上这台电脑")
                .setMessage("连接失败：" + description
                        + "\n\n请确认电脑端 xphoto 正在运行、手机和电脑在同一 Wi-Fi，并且网址里的口令完整。")
                .setPositiveButton("重试", (dialog, which) -> {
                    String url = prefs.getString(PREF_URL, "");
                    if (!url.isEmpty()) showRemote(url);
                })
                .setNegativeButton("返回本机", (dialog, which) -> showLocal())
                .show();
    }

    private String stripArchive(String url) {
        return url.replaceAll("([?&])archive=1(&?)", "$1").replaceAll("&&", "&").replaceAll("[?&]$", "");
    }

    private void requestDownload(String url, String contentDisposition, String mimeType) {
        startDownload(stripArchive(url), contentDisposition, mimeType);
    }

    private String uniqueName(String name) {
        String base = name;
        String ext = "";
        int dot = base.lastIndexOf('.');
        if (dot > 0 && dot > base.length() - 8) {
            ext = base.substring(dot);
            base = base.substring(0, dot);
        }
        File dir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "xphoto");
        if (!dir.exists()) dir.mkdirs();
        String candidate = name;
        int i = 1;
        while (new File(dir, candidate).exists()) candidate = base + " (" + i++ + ")" + ext;
        return candidate;
    }

    private void startDownload(String url, String contentDisposition, String mimeType) {
        try {
            String mime = TextUtils.isEmpty(mimeType) ? "application/octet-stream" : mimeType;
            String name = URLUtil.guessFileName(url, contentDisposition, mime);
            name = uniqueName(name);
            DownloadManager manager = (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
            DownloadManager.Request request = new DownloadManager.Request(Uri.parse(url));
            request.setMimeType(mime);
            request.addRequestHeader("Cookie", CookieManager.getInstance().getCookie(url));
            request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "xphoto/" + name);
            manager.enqueue(request);
            Toast.makeText(this, "已开始下载，完成后在「下载/xphoto」里查看", Toast.LENGTH_LONG).show();
        } catch (Exception error) {
            Toast.makeText(this, "下载失败：" + error.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        boolean granted = grantResults.length > 0;
        for (int result : grantResults) if (result != PackageManager.PERMISSION_GRANTED) granted = false;
        if (localView != null) {
            localView.setPermissionGranted(granted);
            if (granted) localView.refresh();
        }
    }

    @Override public void onBackPressed() {
        if (webView != null) {
            if (webView.canGoBack()) webView.goBack();
            else showLocal();
            return;
        }
        super.onBackPressed();
    }

    @Override protected void onResume() {
        super.onResume();
        if (webView != null) webView.onResume();
        if (localView != null) localView.refresh();
    }

    private void notifyLocalChanged() {
        if (webView != null) {
            webView.evaluateJavascript("window.onAndroidLocalChanged&&window.onAndroidLocalChanged()", null);
        }
    }

    @Override protected void onPause() {
        if (webView != null) webView.onPause();
        super.onPause();
    }

    @Override protected void onDestroy() {
        if (downloadReceiverRegistered) {
            try { unregisterReceiver(downloadReceiver); } catch (Exception ignored) {}
        }
        destroyWeb();
        super.onDestroy();
    }

    private File shareDir() {
        File dir = new File(getCacheDir(), "share");
        if (!dir.exists()) dir.mkdirs();
        return dir;
    }

    private String shareExtension(String raw, String mime) {
        String lower = raw.toLowerCase();
        String[] known = {".mp4", ".m4v", ".mov", ".webm", ".mkv", ".jpg", ".jpeg",
                ".png", ".webp", ".gif", ".heic", ".3gp"};
        for (String ext : known) if (lower.contains(ext)) return ext;
        if (mime != null && mime.startsWith("video/")) return ".mp4";
        if (mime != null && mime.contains("png")) return ".png";
        if (mime != null && mime.contains("webp")) return ".webp";
        if (mime != null && mime.contains("gif")) return ".gif";
        return ".jpg";
    }

    private File downloadShare(String raw, int index) throws Exception {
        HttpURLConnection connection = (HttpURLConnection) new URL(raw).openConnection();
        connection.setConnectTimeout(15000);
        connection.setReadTimeout(30000);
        connection.setInstanceFollowRedirects(true);
        connection.setRequestProperty("User-Agent", "xphoto");
        int code = connection.getResponseCode();
        if (code < 200 || code >= 300) {
            connection.disconnect();
            throw new IllegalStateException("电脑文件下载失败（" + code + "）");
        }
        String mime = connection.getContentType();
        File file = new File(shareDir(), "share_" + System.currentTimeMillis() + "_" + index
                + shareExtension(raw, mime));
        try (InputStream input = connection.getInputStream();
             FileOutputStream output = new FileOutputStream(file)) {
            byte[] buffer = new byte[64 * 1024];
            int read;
            while ((read = input.read(buffer)) > 0) output.write(buffer, 0, read);
        } finally {
            connection.disconnect();
        }
        if (file.length() == 0) throw new IllegalStateException("电脑文件是空的");
        return file;
    }

    private File copyToShareCache(File source, int index) throws Exception {
        if (!source.isFile()) throw new IllegalStateException("找不到要分享的文件");
        File target = new File(shareDir(), "share_" + System.currentTimeMillis() + "_" + index
                + shareExtension(source.getName(), null));
        try (InputStream input = new java.io.FileInputStream(source);
             FileOutputStream output = new FileOutputStream(target)) {
            byte[] buffer = new byte[64 * 1024];
            int read;
            while ((read = input.read(buffer)) > 0) output.write(buffer, 0, read);
        }
        return target;
    }

    private boolean isVideoFile(String name) {
        String lower = name == null ? "" : name.toLowerCase();
        return lower.endsWith(".mp4") || lower.endsWith(".m4v") || lower.endsWith(".mov")
                || lower.endsWith(".webm") || lower.endsWith(".mkv") || lower.endsWith(".3gp");
    }

    private void openShare(ArrayList<Uri> uris, boolean image, boolean video) {
        try {
            Intent intent = new Intent(uris.size() > 1
                    ? Intent.ACTION_SEND_MULTIPLE : Intent.ACTION_SEND);
            intent.setType(video && !image ? "video/*" : image && !video ? "image/*" : "*/*");
            if (uris.size() > 1) intent.putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris);
            else intent.putExtra(Intent.EXTRA_STREAM, uris.get(0));
            ClipData clip = ClipData.newRawUri("xphoto", uris.get(0));
            for (int i = 1; i < uris.size(); i++) clip.addItem(new ClipData.Item(uris.get(i)));
            intent.setClipData(clip);
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            Intent chooser = Intent.createChooser(intent, "分享照片");
            chooser.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(chooser);
        } catch (Exception error) {
            Toast.makeText(this, "分享失败：" + error.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private void deleteTree(File file) {
        if (file == null || !file.exists()) return;
        File[] children = file.listFiles();
        if (children != null) for (File child : children) deleteTree(child);
        file.delete();
    }

    public class Bridge {
        @JavascriptInterface public boolean isAndroidApp() { return true; }

        @JavascriptInterface public String version() { return "1.6.6"; }

        @JavascriptInterface public boolean clearImageCache() {
            if (webView != null) {
                webView.clearCache(true);
                webView.clearFormData();
            }
            if (localView != null) localView.clearThumbCache();
            deleteTree(new File(getCacheDir(), "share"));
            return true;
        }

        @JavascriptInterface public String localFolders() {
            try {
                return new LocalStore(MainActivity.this).foldersJson();
            } catch (Exception error) {
                return "[]";
            }
        }

        @JavascriptInterface public String localPhotos(String folderId) {
            try {
                return new LocalStore(MainActivity.this).photosJson(folderId);
            } catch (Exception error) {
                return "[]";
            }
        }

        @JavascriptInterface public String localRecycle() {
            try {
                return localView == null ? "[]" : localView.recycleJson();
            } catch (Exception error) {
                return "[]";
            }
        }

        @JavascriptInterface public void emptyLocalRecycle() {
            main.post(() -> {
                int removed = localView == null ? 0 : localView.emptyRecycleNow();
                Toast.makeText(MainActivity.this,
                        removed > 0 ? "已永久删除 " + removed + " 个文件" : "手机回收站是空的",
                        Toast.LENGTH_SHORT).show();
                notifyLocalChanged();
            });
        }

        @JavascriptInterface public void playVideo(String raw, String name) {
            if (raw == null) return;
            Uri uri = Uri.parse(raw);
            String scheme = uri.getScheme() == null ? "" : uri.getScheme().toLowerCase();
            if (!("content".equals(scheme) || "http".equals(scheme)
                    || "https".equals(scheme) || "file".equals(scheme))) return;
            if (("content".equals(scheme) || "file".equals(scheme))
                    && PhotoViewerDialog.playExternal(MainActivity.this, uri)) return;
            PhotoViewerDialog.showVideo(MainActivity.this, uri, name == null ? "视频" : name);
        }

        @JavascriptInterface public void showLocal() {
            main.post(MainActivity.this::showLocal);
        }

        @JavascriptInterface public void disconnect() {
            main.post(MainActivity.this::showLocal);
        }

        @JavascriptInterface public boolean shareFiles(String json) {
            main.post(() -> Toast.makeText(MainActivity.this, "正在准备分享…", Toast.LENGTH_SHORT).show());
            new Thread(() -> {
                try {
                    JSONArray array = new JSONArray(json);
                    ArrayList<Uri> uris = new ArrayList<>();
                    boolean image = false;
                    boolean video = false;
                    for (int i = 0; i < array.length() && uris.size() < 9; i++) {
                        String raw = array.getString(i).trim();
                        Uri uri = Uri.parse(raw);
                        String scheme = uri.getScheme() == null ? "" : uri.getScheme().toLowerCase();
                        if ("content".equals(scheme)) {
                            uris.add(uri);
                            String mime = getContentResolver().getType(uri);
                            if (mime != null && mime.startsWith("video/")) video = true;
                            else image = true;
                        } else if ("http".equals(scheme) || "https".equals(scheme)) {
                            File cached = downloadShare(raw, i);
                            uris.add(ShareProvider.uriFor(MainActivity.this, cached));
                            if (isVideoFile(cached.getName())) video = true;
                            else image = true;
                        } else if ("file".equals(scheme) && uri.getPath() != null) {
                            File cached = copyToShareCache(new File(uri.getPath()), i);
                            uris.add(ShareProvider.uriFor(MainActivity.this, cached));
                            if (isVideoFile(cached.getName())) video = true;
                            else image = true;
                        }
                    }
                    if (uris.isEmpty()) throw new IllegalStateException("没有可分享的文件");
                    final boolean hasImage = image;
                    final boolean hasVideo = video;
                    main.post(() -> openShare(uris, hasImage, hasVideo));
                } catch (Exception error) {
                    main.post(() -> Toast.makeText(MainActivity.this,
                            "分享失败：" + (error.getMessage() == null ? "无法读取电脑文件" : error.getMessage()),
                            Toast.LENGTH_LONG).show());
                }
            }).start();
            return true;
        }

        @JavascriptInterface public void toast(String text) {
            main.post(() -> Toast.makeText(MainActivity.this, text, Toast.LENGTH_SHORT).show());
        }
    }
}
