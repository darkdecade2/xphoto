const sharp = require('sharp');
const fs = require('fs');
const path = require('path');
(async () => {
  const svg = fs.readFileSync('assets/icon.svg');
  const sizes = [1024, 512, 256, 192, 128, 64, 48, 32, 16];
  for (const size of sizes) {
    const out = size === 1024 ? 'assets/icon-1024.png' : `assets/icon-${size}.png`;
    await sharp(svg, { density: 300 }).resize(size, size, { fit: 'cover' }).png({ compressionLevel: 9 }).toFile(out);
  }
  await sharp(svg, { density: 300 }).resize(512, 512).png().toFile('app/icons/icon-512.png');
  await sharp(svg, { density: 300 }).resize(192, 192).png().toFile('app/icons/icon-192.png');
  await sharp(svg, { density: 300 }).resize(180, 180).png().toFile('app/icons/apple-touch-icon.png');
  await sharp(svg, { density: 300 }).resize(64, 64).png().toFile('app/icons/favicon.png');
  await sharp(svg, { density: 300 }).resize(512, 512).png().toFile('assets/icon.png');
  console.log('png icons done');
})().catch(e => { console.error(e); process.exit(1); });
