'use strict';

const { app, BrowserWindow, Tray, Menu, nativeImage, dialog, shell, ipcMain, clipboard, nativeTheme, Notification } = require('electron');
const path = require('path');
const fs = require('fs');
const fsp = fs.promises;
const net = require('net');
const { spawn } = require('child_process');

const { Store } = require('../server/store');
const { Library } = require('../server/library');
const { MediaService } = require('../server/media');
const { CloudManager } = require('../server/clouds');
const { createAppServer } = require('../server/index');
const { localAddresses, ensureDirSync } = require('../server/util');

const APP_NAME = 'xphoto';
const VERSION = '1.6.6';

// Portable / test override: keep config, thumbnails and downloads next to a chosen folder.
if (process.env.XPHOTO_DATA_DIR) {
  try {
    const customDataDir = path.resolve(process.env.XPHOTO_DATA_DIR);
    fs.mkdirSync(customDataDir, { recursive: true });
    app.setPath('userData', customDataDir);
  } catch (error) {
    console.error('[xphoto] 无法使用 XPHOTO_DATA_DIR', error);
  }
}
const ICON_DIR = path.join(__dirname, '..', 'assets');
const TITLE_BAR_LIGHT = { color: '#f7f9ff', symbolColor: '#1b2336', height: 46 };
const TITLE_BAR_DARK = { color: '#0d1220', symbolColor: '#eef3ff', height: 46 };

let mainWindow = null;
let tray = null;
let quitting = false;
let store = null;
let media = null;
let library = null;
let clouds = null;
let server = null;
let currentPort = 0;
let serverContext = null;
let firstHideNotice = false;

function logError(...args) {
  try {
    const line = `[${new Date().toISOString()}] ${args.map((item) => (item && item.stack) || String(item)).join(' ')}\n`;
    ensureDirSync(path.join(app.getPath('userData'), 'logs'));
    fs.appendFileSync(path.join(app.getPath('userData'), 'logs', 'main.log'), line);
  } catch {}
  console.error(...args);
}

function cleanEnv() {
  const env = { ...process.env };
  delete env.ELECTRON_RUN_AS_NODE;
  return env;
}

function iconPng(size = 256) {
  const candidates = [
    path.join(ICON_DIR, `icon-${size}.png`),
    path.join(ICON_DIR, 'icon-256.png'),
    path.join(ICON_DIR, 'icon-192.png'),
    path.join(ICON_DIR, 'icon-1024.png')
  ];
  for (const file of candidates) {
    if (fs.existsSync(file)) {
      const image = nativeImage.createFromPath(file);
      if (!image.isEmpty()) return image;
    }
  }
  return nativeImage.createEmpty();
}

function tryListen(port) {
  return new Promise((resolve) => {
    const probe = net.createServer();
    probe.once('error', () => resolve(false));
    probe.once('listening', () => probe.close(() => resolve(true)));
    probe.listen(port, '0.0.0.0');
  });
}

async function pickPort(start) {
  let port = Math.max(1024, Number(start) || 18573);
  for (let i = 0; i < 40; i += 1) {
    if (await tryListen(port)) return port;
    port += 1;
  }
  throw new Error('找不到可用端口');
}

function listenServer(httpServer, port) {
  return new Promise((resolve, reject) => {
    httpServer.once('error', reject);
    httpServer.listen(port, '0.0.0.0', () => resolve());
  });
}

function primaryUrl(port) {
  if (!store.share.enabled) return '';
  const addresses = localAddresses();
  const host = addresses.length ? addresses[0].address : '127.0.0.1';
  return `http://${host}:${port}/?t=${encodeURIComponent(store.share.token)}`;
}

function writeLastUrl() {
  try {
    const target = path.join(app.getPath('userData'), 'last-url.txt');
    const value = store.share.enabled
      ? `${primaryUrl(currentPort)}\n（同一 Wi-Fi 下，用手机浏览器打开上面的地址；地址含访问口令，请勿外传）\n`
      : '局域网访问尚未开启。请在 xphoto 的「手机连接」中开启。\n';
    fs.writeFileSync(target, value, 'utf8');
  } catch (error) {
    logError('[xphoto] 写入地址失败', error);
  }
}

function updateTitleBarTheme() {
  if (!mainWindow || process.platform !== 'win32') return;
  try {
    const dark = nativeTheme.shouldUseDarkColors;
    mainWindow.setTitleBarOverlay(dark ? TITLE_BAR_DARK : TITLE_BAR_LIGHT);
    mainWindow.setBackgroundColor(dark ? '#0b1020' : '#f7f9ff');
  } catch {}
}

function buildTrayMenu() {
  if (!store) return;
  const url = primaryUrl(currentPort);
  const items = [
    {
      label: '打开 xphoto',
      click: () => showWindow()
    },
    {
      label: store.share.enabled ? `手机访问：${url}` : '手机访问：已关闭',
      enabled: false
    },
    {
      label: '复制手机访问地址',
      enabled: store.share.enabled,
      click: () => {
        clipboard.writeText(url);
        if (Notification.isSupported()) {
          new Notification({ title: 'xphoto', body: '手机访问地址已复制，去手机浏览器打开吧' }).show();
        }
      }
    },
    {
      label: store.share.enabled ? '关闭局域网访问' : '开启局域网访问',
      click: async () => {
        store.setShareEnabled(!store.share.enabled);
        writeLastUrl();
        buildTrayMenu();
        if (mainWindow && !mainWindow.isDestroyed()) {
          mainWindow.webContents.send('xphoto:share-changed');
        }
      }
    },
    { type: 'separator' },
    {
      label: '打开下载文件夹',
      click: () => shell.openPath(store.downloadDir)
    },
    {
      label: '在浏览器中打开界面',
      click: () => shell.openExternal(`http://127.0.0.1:${currentPort}/`)
    },
    { type: 'separator' },
    {
      label: '退出 xphoto',
      click: () => {
        quitting = true;
        app.quit();
      }
    }
  ];
  tray.setContextMenu(Menu.buildFromTemplate(items));
  tray.setToolTip(store.share.enabled ? `xphoto · 手机访问 ${url}` : 'xphoto · 局域网访问已关闭');
}

function createTray() {
  try {
    const image = iconPng(32);
    tray = new Tray(image);
    tray.on('double-click', () => showWindow());
    buildTrayMenu();
  } catch (error) {
    logError('[xphoto] 托盘创建失败', error);
  }
}

function showWindow() {
  if (!mainWindow || mainWindow.isDestroyed()) {
    createWindow();
    return;
  }
  if (mainWindow.isMinimized()) mainWindow.restore();
  mainWindow.show();
  mainWindow.focus();
}

function createWindow() {
  const dark = nativeTheme.shouldUseDarkColors;
  mainWindow = new BrowserWindow({
    width: 1460,
    height: 920,
    minWidth: 980,
    minHeight: 620,
    show: false,
    title: 'xphoto',
    icon: iconPng(256),
    backgroundColor: dark ? '#0b1020' : '#f7f9ff',
    titleBarStyle: process.platform === 'darwin' ? 'hiddenInset' : 'hidden',
    titleBarOverlay: process.platform === 'win32' ? (dark ? TITLE_BAR_DARK : TITLE_BAR_LIGHT) : undefined,
    trafficLightPosition: process.platform === 'darwin' ? { x: 16, y: 16 } : undefined,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: false,
      spellcheck: false,
      backgroundThrottling: false
    }
  });

  mainWindow.loadURL(`http://127.0.0.1:${currentPort}/?desktop=1`);

  mainWindow.once('ready-to-show', () => {
    mainWindow.show();
    if (process.env.XPHOTO_DEVTOOLS === '1') mainWindow.webContents.openDevTools({ mode: 'detach' });
  });

  mainWindow.on('close', (event) => {
    if (quitting) return;
    if (store.config.settings.closeToTray !== false) {
      event.preventDefault();
      mainWindow.hide();
      if (!firstHideNotice) {
        firstHideNotice = true;
        if (Notification.isSupported()) {
          new Notification({
            title: 'xphoto 还在后台运行',
            body: '手机仍然可以访问相册。想完全退出请右键任务栏托盘图标。'
          }).show();
        }
      }
    }
  });

  mainWindow.on('closed', () => {
    mainWindow = null;
  });

  mainWindow.webContents.setWindowOpenHandler(({ url }) => {
    if (/^https?:/i.test(url)) shell.openExternal(url);
    return { action: 'deny' };
  });

  mainWindow.webContents.on('will-navigate', (event, url) => {
    if (!url.startsWith(`http://127.0.0.1:${currentPort}`)) {
      event.preventDefault();
    }
  });

  mainWindow.webContents.on('did-fail-load', (event, code, desc) => {
    logError('[xphoto] 页面加载失败', code, desc);
  });
}

function setupIpc() {
  ipcMain.handle('xphoto:info', () => ({
    version: VERSION,
    port: currentPort,
    dataDir: app.getPath('userData'),
    packaged: app.isPackaged,
    platform: process.platform,
    downloadDir: store.downloadDir,
    url: primaryUrl(currentPort)
  }));

  ipcMain.handle('xphoto:pick-folders', async () => {
    const result = await dialog.showOpenDialog(mainWindow, {
      title: '选择要加入 xphoto 的文件夹',
      buttonLabel: '添加文件夹',
      properties: ['openDirectory', 'multiSelections', 'dontAddToRecent']
    });
    return result.canceled ? [] : result.filePaths;
  });

  ipcMain.handle('xphoto:pick-folder', async () => {
    const result = await dialog.showOpenDialog(mainWindow, {
      title: '选择文件夹',
      buttonLabel: '选择',
      properties: ['openDirectory', 'dontAddToRecent']
    });
    return result.canceled ? '' : result.filePaths[0];
  });

  ipcMain.handle('xphoto:open-downloads', async () => {
    await shell.openPath(store.downloadDir);
    return true;
  });

  ipcMain.handle('xphoto:open-path', async (event, target) => {
    if (!target) return false;
    await shell.openPath(target);
    return true;
  });

  ipcMain.handle('xphoto:reveal', async (event, target) => {
    if (!target) return false;
    shell.showItemInFolder(target);
    return true;
  });

  ipcMain.handle('xphoto:copy', (event, text) => {
    clipboard.writeText(String(text || ''));
    return true;
  });

  ipcMain.handle('xphoto:open-external', async (event, target) => {
    if (/^https?:/i.test(target)) await shell.openExternal(target);
    return true;
  });

  ipcMain.handle('xphoto:open-firewall', async () => {
    return openFirewall(currentPort);
  });

  ipcMain.handle('xphoto:set-theme', (event, theme) => {
    nativeTheme.themeSource = theme === 'dark' ? 'dark' : theme === 'light' ? 'light' : 'system';
    updateTitleBarTheme();
    return true;
  });

  ipcMain.handle('xphoto:share-changed', () => {
    writeLastUrl();
    buildTrayMenu();
    return true;
  });

  ipcMain.handle('xphoto:quit', () => {
    quitting = true;
    app.quit();
  });

  ipcMain.handle('xphoto:show-window', () => {
    showWindow();
    return true;
  });
}

function openFirewall(port) {
  return new Promise((resolve) => {
    const scriptPath = path.join(app.getPath('userData'), 'open-firewall.ps1');
    const script = [
      `$name = 'xphoto 相册 (TCP ${port})'`,
      `$existing = Get-NetFirewallRule -DisplayName $name -ErrorAction SilentlyContinue`,
      `if (-not $existing) {`,
      `  New-NetFirewallRule -DisplayName $name -Direction Inbound -Action Allow -Protocol TCP -LocalPort ${port} -Profile Private,Domain,Public -Description 'xphoto 局域网相册访问' | Out-Null`,
      `}`,
      `Write-Output 'ok'`
    ].join('\r\n');
    try {
      fs.writeFileSync(scriptPath, script, 'utf8');
      const inner = `Start-Process -FilePath 'powershell.exe' -Verb RunAs -ArgumentList @('-NoProfile','-ExecutionPolicy','Bypass','-File','${scriptPath.replace(/'/g, "''")}')`;
      const child = spawn('powershell.exe', ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-Command', inner], {
        detached: true,
        stdio: 'ignore',
        windowsHide: true,
        env: cleanEnv()
      });
      child.unref();
      resolve({
        started: true,
        message: '已弹出 Windows 授权窗口，请点击“是”完成放行。完成后手机即可访问。'
      });
    } catch (error) {
      resolve({ started: false, message: `自动放行失败：${error.message}。请手动允许防火墙访问。` });
    }
  });
}

async function start() {
  app.setName(APP_NAME);
  if (process.platform === 'win32') app.setAppUserModelId('com.xphoto.album');

  const gotLock = app.requestSingleInstanceLock();
  if (!gotLock) {
    app.quit();
    return;
  }
  app.on('second-instance', () => showWindow());

  await app.whenReady();
  nativeTheme.themeSource = 'light';

  const dataDir = app.getPath('userData');
  store = new Store(dataDir);
  nativeTheme.themeSource = store.config.settings.theme === 'dark' ? 'dark' : store.config.settings.theme === 'auto' ? 'system' : 'light';
  media = new MediaService(store);
  library = new Library(store);
  clouds = new CloudManager(store, media);

  currentPort = await pickPort(store.port);
  store.setPort(currentPort);

  serverContext = {
    store,
    library,
    media,
    clouds,
    port: currentPort,
    version: VERSION,
    hooks: {
      pickFolders: async () => {
        const result = await dialog.showOpenDialog(mainWindow, {
          title: '选择要加入 xphoto 的文件夹',
          buttonLabel: '添加文件夹',
          properties: ['openDirectory', 'multiSelections', 'dontAddToRecent']
        });
        return result.canceled ? [] : result.filePaths;
      },
      reveal: (target) => {
        if (fs.existsSync(target)) {
          const stat = fs.statSync(target);
          if (stat.isDirectory()) shell.openPath(target);
          else shell.showItemInFolder(target);
        }
      },
      openPath: (target) => shell.openPath(target),
      openFirewall: (port) => openFirewall(port),
      onShareChanged: () => {
        writeLastUrl();
        buildTrayMenu();
        if (mainWindow && !mainWindow.isDestroyed()) mainWindow.webContents.send('xphoto:share-changed');
      },
      onSettingsChanged: (settings) => {
        if (settings.theme) {
          nativeTheme.themeSource = settings.theme === 'dark' ? 'dark' : settings.theme === 'auto' ? 'system' : 'light';
          updateTitleBarTheme();
          if (mainWindow && !mainWindow.isDestroyed()) {
            mainWindow.webContents.send('xphoto:theme-changed', nativeTheme.shouldUseDarkColors ? 'dark' : 'light');
          }
        }
      }
    }
  };

  const created = createAppServer(serverContext);
  server = created.server;
  await listenServer(server, currentPort);
  writeLastUrl();

  setupIpc();
  createWindow();
  createTray();
  nativeTheme.on('updated', updateTitleBarTheme);

  app.on('activate', () => showWindow());
  app.on('window-all-closed', () => {
    if (process.platform === 'darwin') return;
    // 保持后台运行，手机仍可访问；退出请使用托盘菜单。
  });
  app.on('before-quit', () => {
    quitting = true;
    try { server && server.close(); } catch {}
  });
}

app.whenReady().then(start).catch((error) => {
  logError('[xphoto] 启动失败', error);
  dialog.showErrorBox('xphoto 启动失败', String(error && error.stack ? error.stack : error));
  app.quit();
});

process.on('uncaughtException', (error) => logError('[xphoto] uncaughtException', error));
process.on('unhandledRejection', (error) => logError('[xphoto] unhandledRejection', error));
