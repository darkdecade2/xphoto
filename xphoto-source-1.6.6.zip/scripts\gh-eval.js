// Minimal Chrome DevTools evaluator for the already-running GitHub tab.
// usage: node scripts/gh-eval.js <urlSubstring> <expressionFile> [screenshotPath]
const fs = require('fs');
const http = require('http');

const [needle, exprFile, shot] = process.argv.slice(2);
const port = 9223;

function getJson(path) {
  return new Promise((resolve, reject) => {
    http.get({ host: '127.0.0.1', port, path }, (res) => {
      let data = '';
      res.on('data', (c) => (data += c));
      res.on('end', () => {
        try { resolve(JSON.parse(data)); } catch (e) { reject(e); }
      });
    }).on('error', reject);
  });
}

(async () => {
  const targets = await getJson('/json/list');
  const target = targets.find((t) => t.type === 'page' && t.url.includes(needle));
  if (!target) {
    console.log('NO_TARGET', targets.filter((t) => t.type === 'page').map((t) => t.url));
    process.exit(2);
  }
  const ws = new WebSocket(target.webSocketDebuggerUrl);
  let seq = 0;
  const pending = new Map();
  ws.addEventListener('message', (event) => {
    const msg = JSON.parse(event.data);
    if (msg.id && pending.has(msg.id)) {
      pending.get(msg.id)(msg);
      pending.delete(msg.id);
    }
  });
  await new Promise((resolve, reject) => {
    ws.addEventListener('open', resolve);
    ws.addEventListener('error', reject);
  });
  const send = (method, params = {}) => new Promise((resolve) => {
    const id = ++seq;
    pending.set(id, resolve);
    ws.send(JSON.stringify({ id, method, params }));
  });
  const expression = fs.readFileSync(exprFile, 'utf8');
  const result = await send('Runtime.evaluate', {
    expression,
    awaitPromise: true,
    returnByValue: true,
    userGesture: true,
  });
  console.log(JSON.stringify(result.result, null, 2));
  if (shot) {
    const png = await send('Page.captureScreenshot', { format: 'png' });
    fs.writeFileSync(shot, Buffer.from(png.result.data, 'base64'));
    console.log('SHOT', shot);
  }
  ws.close();
})().catch((error) => { console.error('FATAL', error); process.exit(1); });
