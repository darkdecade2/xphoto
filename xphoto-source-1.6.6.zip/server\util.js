'use strict';

const fs = require('fs');
const fsp = fs.promises;
const path = require('path');
const crypto = require('crypto');
const os = require('os');

const IMAGE_EXT = new Set([
  '.jpg', '.jpeg', '.png', '.gif', '.webp', '.bmp', '.avif', '.heic', '.heif',
  '.jfif', '.jpe', '.tif', '.tiff', '.ico'
]);

const VIDEO_EXT = new Set([
  '.mp4', '.m4v', '.mov', '.webm', '.mkv', '.avi', '.wmv', '.flv',
  '.3gp', '.3g2', '.mpeg', '.mpg', '.ts', '.mts', '.m2ts', '.ogv'
]);

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'application/javascript; charset=utf-8',
  '.mjs': 'application/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.webmanifest': 'application/manifest+json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.gif': 'image/gif',
  '.webp': 'image/webp',
  '.bmp': 'image/bmp',
  '.avif': 'image/avif',
  '.heic': 'image/heic',
  '.heif': 'image/heif',
  '.ico': 'image/x-icon',
  '.mp4': 'video/mp4',
  '.m4v': 'video/mp4',
  '.mov': 'video/quicktime',
  '.webm': 'video/webm',
  '.mkv': 'video/x-matroska',
  '.avi': 'video/x-msvideo',
  '.wmv': 'video/x-ms-wmv',
  '.flv': 'video/x-flv',
  '.3gp': 'video/3gpp',
  '.3g2': 'video/3gpp2',
  '.mpeg': 'video/mpeg',
  '.mpg': 'video/mpeg',
  '.ts': 'video/mp2t',
  '.mts': 'video/mp2t',
  '.m2ts': 'video/mp2t',
  '.ogv': 'video/ogg',
  '.woff2': 'font/woff2',
  '.txt': 'text/plain; charset=utf-8',
  '.map': 'application/json; charset=utf-8'
};

function mimeFor(file) {
  return MIME[path.extname(String(file)).toLowerCase()] || 'application/octet-stream';
}

function isImageName(name) {
  return IMAGE_EXT.has(path.extname(String(name)).toLowerCase());
}

function isVideoName(name) {
  return VIDEO_EXT.has(path.extname(String(name)).toLowerCase());
}

function isMediaName(name) {
  return isImageName(name) || isVideoName(name);
}

function base64url(value) {
  return Buffer.from(String(value), 'utf8').toString('base64url');
}

function fromBase64url(value) {
  try {
    return Buffer.from(String(value), 'base64url').toString('utf8');
  } catch {
    return '';
  }
}

function sha1(value) {
  return crypto.createHash('sha1').update(value).digest('hex');
}

function randomToken(bytes = 18) {
  return crypto.randomBytes(bytes).toString('base64url');
}

function json(res, status, payload, extraHeaders) {
  const body = Buffer.from(JSON.stringify(payload));
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Content-Length': body.length,
    'Cache-Control': 'no-store',
    ...(extraHeaders || {})
  });
  res.end(body);
}

function fail(res, status, message, extra) {
  return json(res, status, { ok: false, error: message, ...(extra || {}) });
}

function readBody(req, limit = 2 * 1024 * 1024) {
  return new Promise((resolve, reject) => {
    let size = 0;
    const chunks = [];
    req.on('data', (chunk) => {
      size += chunk.length;
      if (size > limit) {
        reject(new Error('请求内容过大'));
        req.destroy();
        return;
      }
      chunks.push(chunk);
    });
    req.on('end', () => {
      if (!chunks.length) return resolve({});
      const raw = Buffer.concat(chunks).toString('utf8');
      try {
        resolve(raw ? JSON.parse(raw) : {});
      } catch {
        reject(new Error('请求格式错误'));
      }
    });
    req.on('error', reject);
  });
}

function ensureDirSync(dir) {
  fs.mkdirSync(dir, { recursive: true });
  return dir;
}

async function ensureDir(dir) {
  await fsp.mkdir(dir, { recursive: true });
  return dir;
}

function writeJsonAtomic(file, value) {
  ensureDirSync(path.dirname(file));
  const tmp = `${file}.${process.pid}.${Date.now()}.tmp`;
  fs.writeFileSync(tmp, JSON.stringify(value, null, 2), 'utf8');
  fs.renameSync(tmp, file);
}

function isInside(child, parent) {
  const rel = path.relative(path.resolve(parent), path.resolve(child));
  return rel === '' || (!rel.startsWith('..') && !path.isAbsolute(rel));
}

function normalizePath(input) {
  let value = String(input || '').trim();
  if (!value) return '';
  value = value.replace(/^"|"$/g, '');
  if (process.platform === 'win32') {
    value = value.replace(/\//g, '\\');
  }
  return path.normalize(path.resolve(value));
}

function safeName(name, fallback = 'image') {
  let value = String(name || fallback)
    .replace(/[<>:"/\\|?*\u0000-\u001f]/g, '_')
    .replace(/\.+$/g, '')
    .trim();
  if (!value) value = fallback;
  if (value.length > 160) {
    const ext = path.extname(value);
    value = value.slice(0, 160 - ext.length) + ext;
  }
  return value;
}

function uniqueFile(dir, name) {
  ensureDirSync(dir);
  const ext = path.extname(name);
  const stem = path.basename(name, ext);
  let candidate = path.join(dir, name);
  let index = 1;
  while (fs.existsSync(candidate)) {
    candidate = path.join(dir, `${stem} (${index})${ext}`);
    index += 1;
  }
  return candidate;
}

function formatBytes(bytes) {
  if (!Number.isFinite(bytes) || bytes < 0) return '0 B';
  const units = ['B', 'KB', 'MB', 'GB', 'TB'];
  let value = bytes;
  let unit = 0;
  while (value >= 1024 && unit < units.length - 1) {
    value /= 1024;
    unit += 1;
  }
  return `${value >= 10 || unit === 0 ? Math.round(value) : value.toFixed(1)} ${units[unit]}`;
}

function localAddresses() {
  const out = [];
  const nets = os.networkInterfaces();
  for (const [name, list] of Object.entries(nets)) {
    for (const net of list || []) {
      if (net.family !== 'IPv4' || net.internal) continue;
      const [a, b] = net.address.split('.').map(Number);
      let score = 10;
      if (a === 192 && b === 168) score = 100;
      else if (a === 10) score = 90;
      else if (a === 172 && b >= 16 && b <= 31) score = 80;
      else if (a === 26) score = 20;
      const label = String(name);
      if (/wi-?fi|wlan|无线/i.test(label)) score += 20;
      else if (/ethernet|以太网/i.test(label)) score += 15;
      if (/radmin|vpn|tailscale|zerotier|vmware|virtualbox|vethernet|loopback|hyper-v/i.test(label)) score -= 35;
      out.push({ address: net.address, interface: label, netmask: net.netmask, score });
    }
  }
  out.sort((x, y) => y.score - x.score || x.address.localeCompare(y.address));
  return out;
}

function getClientIp(req) {
  let ip = req.socket.remoteAddress || '';
  if (ip.startsWith('::ffff:')) ip = ip.slice(7);
  return ip;
}

function isLocalRequest(req) {
  const ip = getClientIp(req);
  return ip === '127.0.0.1' || ip === '::1' || ip === 'localhost' || ip === '';
}

function parseDate(value) {
  if (!value) return Date.now();
  if (typeof value === 'number') return value;
  const t = Date.parse(value);
  return Number.isFinite(t) ? t : Date.now();
}

function decodeEntities(text) {
  return String(text || '')
    .replace(/&#x([0-9a-f]+);/gi, (_, hex) => String.fromCodePoint(parseInt(hex, 16)))
    .replace(/&#([0-9]+);/g, (_, dec) => String.fromCodePoint(parseInt(dec, 10)))
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/&apos;/g, "'")
    .replace(/&amp;/g, '&');
}

function escapeXml(text) {
  return String(text || '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&apos;');
}

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

module.exports = {
  IMAGE_EXT,
  VIDEO_EXT,
  MIME,
  mimeFor,
  isImageName,
  isVideoName,
  isMediaName,
  base64url,
  fromBase64url,
  sha1,
  randomToken,
  json,
  fail,
  readBody,
  ensureDir,
  ensureDirSync,
  writeJsonAtomic,
  isInside,
  normalizePath,
  safeName,
  uniqueFile,
  formatBytes,
  localAddresses,
  getClientIp,
  isLocalRequest,
  parseDate,
  decodeEntities,
  escapeXml,
  sleep
};
