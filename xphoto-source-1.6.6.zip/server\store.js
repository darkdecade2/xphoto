'use strict';

const crypto = require('crypto');
const fs = require('fs');
const os = require('os');
const path = require('path');
const {
  ensureDirSync,
  writeJsonAtomic,
  normalizePath,
  randomToken,
  base64url,
  isInside
} = require('./util');

const CONFIG_VERSION = 1;

function defaultDownloadDir() {
  return path.join(os.homedir(), 'Pictures', 'xphoto下载');
}

function defaultConfig() {
  const downloadDir = defaultDownloadDir();
  return {
    version: CONFIG_VERSION,
    createdAt: Date.now(),
    deviceName: os.hostname() || '我的电脑',
    port: 18573,
    roots: [],
    favorites: [],
    clouds: [],
    downloads: [],
    share: {
      enabled: true,
      token: randomToken(18),
      allowCloud: true,
      remoteAccess: false,
      passwordSalt: '',
      passwordHash: ''
    },
    settings: {
      theme: 'light',
      gridSize: 5,
      sort: 'desc',
      autoBackup: true,
      closeToTray: true,
      downloadDir,
      lastView: 'photos'
    },
    meta: {
      lastRunAt: 0,
      lastUrl: ''
    }
  };
}

function mergeConfig(base, incoming) {
  const out = { ...base, ...(incoming || {}) };
  out.share = { ...base.share, ...(incoming && incoming.share) };
  out.settings = { ...base.settings, ...(incoming && incoming.settings) };
  out.meta = { ...base.meta, ...(incoming && incoming.meta) };
  out.roots = Array.isArray(incoming && incoming.roots) ? incoming.roots : [];
  out.favorites = Array.isArray(incoming && incoming.favorites) ? incoming.favorites : [];
  out.clouds = Array.isArray(incoming && incoming.clouds) ? incoming.clouds : [];
  out.downloads = Array.isArray(incoming && incoming.downloads) ? incoming.downloads : [];
  return out;
}

class Store {
  constructor(dataDir) {
    this.dataDir = dataDir;
    this.configPath = path.join(dataDir, 'config.json');
    this.thumbDir = path.join(dataDir, 'thumbnails');
    this.logDir = path.join(dataDir, 'logs');
    ensureDirSync(this.dataDir);
    ensureDirSync(this.thumbDir);
    ensureDirSync(this.logDir);
    this.config = this.load();
    this.ensureEssentials();
    this.save();
    this.config.meta.lastRunAt = Date.now();
    this.save();
  }

  load() {
    const base = defaultConfig();
    if (!fs.existsSync(this.configPath)) return base;
    try {
      const raw = JSON.parse(fs.readFileSync(this.configPath, 'utf8'));
      return mergeConfig(base, raw);
    } catch (error) {
      try {
        fs.copyFileSync(this.configPath, `${this.configPath}.broken-${Date.now()}`);
      } catch {}
      return base;
    }
  }

  save() {
    writeJsonAtomic(this.configPath, this.config);
  }

  ensureEssentials() {
    const settings = this.config.settings;
    if (!settings.downloadDir) settings.downloadDir = defaultDownloadDir();
    try {
      ensureDirSync(settings.downloadDir);
      ensureDirSync(path.join(settings.downloadDir, '手机下载'));
      ensureDirSync(path.join(settings.downloadDir, '电脑下载'));
      ensureDirSync(path.join(settings.downloadDir, '云盘'));
    } catch {}
    if (!this.config.share.token) this.config.share.token = randomToken(18);
    if (!Number.isInteger(Number(this.config.port)) || Number(this.config.port) < 1024) {
      this.config.port = 18573;
    }
    // 下载目录始终作为「系统相册」存在，电脑端可按子文件夹分类浏览。
    const downloadDir = settings.downloadDir;
    const exists = this.config.roots.some((root) => path.resolve(root.path).toLowerCase() === path.resolve(downloadDir).toLowerCase());
    if (!exists) {
      this.config.roots.push({
        id: base64url(downloadDir),
        path: downloadDir,
        name: 'xphoto下载',
        auto: true,
        system: true,
        addedAt: Date.now()
      });
    }
  }

  get deviceName() {
    return this.config.deviceName || os.hostname() || '我的电脑';
  }

  get port() {
    return Number(this.config.port) || 18573;
  }

  setPort(port) {
    this.config.port = Number(port);
    this.save();
  }

  setDeviceName(name) {
    const value = String(name || '').trim().slice(0, 60);
    if (value) this.config.deviceName = value;
    this.save();
  }

  get share() {
    return this.config.share;
  }

  setShareEnabled(enabled) {
    this.config.share.enabled = Boolean(enabled);
    this.save();
    return this.config.share;
  }

  rotateShareToken() {
    this.config.share.token = randomToken(18);
    this.save();
    return this.config.share.token;
  }

  get remoteAccess() {
    return Boolean(this.config.share.remoteAccess);
  }

  setRemoteAccess(enabled) {
    this.config.share.remoteAccess = Boolean(enabled);
    this.save();
    return this.remoteAccess;
  }

  get passwordSet() {
    return Boolean(this.config.share.passwordHash && this.config.share.passwordSalt);
  }

  setPassword(password) {
    const value = String(password || '');
    if (!value) {
      this.config.share.passwordHash = '';
      this.config.share.passwordSalt = '';
    } else {
      if (value.length < 6) throw new Error('密码至少 6 位');
      if (value.length > 64) throw new Error('密码最多 64 位');
      const salt = randomToken(18);
      const hash = crypto.scryptSync(value, salt, 32).toString('hex');
      this.config.share.passwordSalt = salt;
      this.config.share.passwordHash = hash;
    }
    this.save();
  }

  checkPassword(password) {
    if (!this.passwordSet) return false;
    const hash = crypto.scryptSync(String(password || ''), this.config.share.passwordSalt, 32);
    const saved = Buffer.from(this.config.share.passwordHash, 'hex');
    return saved.length === hash.length && crypto.timingSafeEqual(saved, hash);
  }

  get roots() {
    return this.config.roots;
  }

  addRoot(input, options = {}) {
    const target = normalizePath(input);
    if (!target) throw new Error('请填写文件夹路径');
    let stat;
    try {
      stat = fs.statSync(target);
    } catch {
      throw new Error('文件夹不存在或无权限访问');
    }
    if (!stat.isDirectory()) throw new Error('请选择一个文件夹');
    const existing = this.config.roots.find((root) => path.resolve(root.path).toLowerCase() === target.toLowerCase());
    if (existing) {
      if (options.select !== false) existing.disabled = false;
      this.save();
      return existing;
    }
    const root = {
      id: base64url(target),
      path: target,
      name: options.name || path.basename(target) || target,
      auto: Boolean(options.auto),
      system: Boolean(options.system),
      addedAt: Date.now()
    };
    this.config.roots.push(root);
    this.save();
    return root;
  }

  removeRoot(id) {
    const index = this.config.roots.findIndex((root) => root.id === id);
    if (index < 0) throw new Error('文件夹不存在');
    const root = this.config.roots[index];
    if (root.system) throw new Error('“xphoto下载”是系统相册，不能移除');
    this.config.roots.splice(index, 1);
    this.save();
    return root;
  }

  renameRoot(id, name) {
    const root = this.config.roots.find((item) => item.id === id);
    if (!root) throw new Error('文件夹不存在');
    const value = String(name || '').trim().slice(0, 80);
    if (value) root.name = value;
    this.save();
    return root;
  }

  isFavorite(id) {
    return this.config.favorites.includes(id);
  }

  setFavorite(id, value) {
    const set = new Set(this.config.favorites);
    if (value) set.add(id);
    else set.delete(id);
    this.config.favorites = Array.from(set);
    this.save();
    return value;
  }

  addDownload(entry) {
    this.config.downloads.unshift({
      at: Date.now(),
      ...entry
    });
    if (this.config.downloads.length > 800) this.config.downloads.length = 800;
    this.save();
  }

  get downloads() {
    return this.config.downloads;
  }

  get clouds() {
    return this.config.clouds;
  }

  getCloud(id) {
    return this.config.clouds.find((cloud) => cloud.id === id) || null;
  }

  addCloud(cloud) {
    this.config.clouds.push(cloud);
    this.save();
    return cloud;
  }

  updateCloud(id, patch) {
    const cloud = this.getCloud(id);
    if (!cloud) throw new Error('云盘不存在');
    Object.assign(cloud, patch, { updatedAt: Date.now() });
    this.save();
    return cloud;
  }

  removeCloud(id) {
    const index = this.config.clouds.findIndex((cloud) => cloud.id === id);
    if (index < 0) throw new Error('云盘不存在');
    const [cloud] = this.config.clouds.splice(index, 1);
    this.save();
    return cloud;
  }

  updateSettings(patch = {}) {
    const allowed = ['theme', 'gridSize', 'sort', 'autoBackup', 'closeToTray', 'downloadDir', 'lastView'];
    for (const key of allowed) {
      if (Object.prototype.hasOwnProperty.call(patch, key)) {
        if (key === 'downloadDir') {
          const dir = normalizePath(patch[key]);
          if (!dir) continue;
          ensureDirSync(dir);
          this.config.settings.downloadDir = dir;
          const hasRoot = this.config.roots.some((root) => path.resolve(root.path).toLowerCase() === dir.toLowerCase());
          if (!hasRoot) {
            this.config.roots.push({
              id: base64url(dir),
              path: dir,
              name: 'xphoto下载',
              auto: true,
              system: true,
              addedAt: Date.now()
            });
          }
        } else if (key === 'gridSize') {
          this.config.settings.gridSize = Math.max(3, Math.min(8, Number(patch[key]) || 5));
        } else if (key === 'theme') {
          this.config.settings.theme = ['light', 'dark', 'auto'].includes(patch[key]) ? patch[key] : 'light';
        } else {
          this.config.settings[key] = patch[key];
        }
      }
    }
    this.save();
    return this.config.settings;
  }

  get downloadDir() {
    return this.config.settings.downloadDir;
  }

  subDir(...parts) {
    const base = this.downloadDir;
    const target = path.join(base, ...parts);
    if (!isInside(target, base)) throw new Error('路径不合法');
    ensureDirSync(target);
    return target;
  }

  setMeta(key, value) {
    this.config.meta[key] = value;
    this.save();
  }
}

module.exports = { Store, defaultConfig, defaultDownloadDir };
