package com.xphoto.app;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.os.ParcelFileDescriptor;

import java.io.File;
import java.io.FileNotFoundException;

/**
 * Minimal read-only provider for files prepared in the app cache.
 * WeChat / QQ can read these URIs with the temporary grant, and no files
 * are added to the phone's public gallery.
 */
public class ShareProvider extends ContentProvider {
    public static final String AUTHORITY = "com.xphoto.app.share";

    public static Uri uriFor(Context context, File file) {
        return Uri.parse("content://" + AUTHORITY + "/" + Uri.encode(file.getName()));
    }

    @Override
    public boolean onCreate() {
        return true;
    }

    @Override
    public ParcelFileDescriptor openFile(Uri uri, String mode) throws FileNotFoundException {
        Context context = getContext();
        if (context == null) throw new FileNotFoundException("no context");
        File dir = new File(context.getCacheDir(), "share");
        String name = uri.getLastPathSegment();
        if (name == null || name.contains("/") || name.contains("\\")) {
            throw new FileNotFoundException("bad name");
        }
        File file;
        try {
            file = new File(dir, name).getCanonicalFile();
            if (!dir.getCanonicalFile().equals(file.getParentFile())) {
                throw new FileNotFoundException("outside share dir");
            }
        } catch (Exception error) {
            throw new FileNotFoundException("bad path");
        }
        if (!file.isFile()) throw new FileNotFoundException("not found");
        return ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY);
    }

    @Override
    public String getType(Uri uri) {
        String name = uri.getLastPathSegment();
        if (name == null) return "application/octet-stream";
        String lower = name.toLowerCase();
        if (lower.endsWith(".mp4") || lower.endsWith(".m4v") || lower.endsWith(".mov")
                || lower.endsWith(".webm") || lower.endsWith(".mkv") || lower.endsWith(".3gp")) {
            return "video/*";
        }
        if (lower.endsWith(".png")) return "image/png";
        if (lower.endsWith(".webp")) return "image/webp";
        if (lower.endsWith(".gif")) return "image/gif";
        return "image/jpeg";
    }

    @Override
    public Cursor query(Uri uri, String[] projection, String selection,
                        String[] selectionArgs, String sortOrder) {
        return null;
    }

    @Override
    public Uri insert(Uri uri, ContentValues values) {
        return null;
    }

    @Override
    public int delete(Uri uri, String selection, String[] selectionArgs) {
        return 0;
    }

    @Override
    public int update(Uri uri, ContentValues values, String selection, String[] selectionArgs) {
        return 0;
    }
}
