'use strict';

// Tiny WebDAV fixture used only for local end-to-end tests.
const http = require('http');
const fs = require('fs');
const path = require('path');

const PORT = Number(process.env.MOCK_DAV_PORT || 19090);
const ROOT = path.join(__dirname, '..', '.test-photos');
const SAMPLES = {
  '/dav/风景.jpg': path.join(ROOT, '壁纸', 'IMG_20261305_20.jpg'),
  '/dav/旅行/照片.jpg': path.join(ROOT, '旅行', '杭州', 'IMG_20261005_05.jpg')
};

function entry(href, name, folder, size, modified) {
  return `<d:response>
  <d:href>${href}</d:href>
  <d:propstat><d:prop>
    <d:displayname>${name}</d:displayname>
    <d:resourcetype>${folder ? '<d:collection/>' : ''}</d:resourcetype>
    ${folder ? '' : `<d:getcontentlength>${size}</d:getcontentlength><d:getcontenttype>image/jpeg</d:getcontenttype>`}
    <d:getlastmodified>${modified}</d:getlastmodified>
  </d:prop><d:status>HTTP/1.1 200 OK</d:status></d:propstat>
</d:response>`;
}

const server = http.createServer((req, res) => {
  const pathname = decodeURIComponent(new URL(req.url, `http://${req.headers.host}`).pathname);
  if (req.method === 'PROPFIND') {
    if (pathname === '/dav' || pathname === '/dav/') {
      res.writeHead(207, { 'Content-Type': 'application/xml; charset=utf-8' });
      return res.end(`<?xml version="1.0" encoding="utf-8"?><d:multistatus xmlns:d="DAV:">
        ${entry('/dav/', 'dav', true, 0, 'Wed, 25 Nov 2026 02:00:00 GMT')}
        ${entry('/dav/%E6%97%85%E8%A1%8C/', '旅行', true, 0, 'Wed, 25 Nov 2026 02:00:00 GMT')}
        ${entry('/dav/%E9%A3%8E%E6%99%AF.jpg', '风景.jpg', false, 49563, 'Wed, 25 Nov 2026 02:00:00 GMT')}
      </d:multistatus>`);
    }
    if (pathname === '/dav/旅行' || pathname === '/dav/旅行/') {
      res.writeHead(207, { 'Content-Type': 'application/xml; charset=utf-8' });
      return res.end(`<?xml version="1.0" encoding="utf-8"?><d:multistatus xmlns:d="DAV:">
        ${entry('/dav/%E6%97%85%E8%A1%8C/', '旅行', true, 0, 'Wed, 25 Nov 2026 02:00:00 GMT')}
        ${entry('/dav/%E6%97%85%E8%A1%8C/%E7%85%A7%E7%89%87.jpg', '照片.jpg', false, 45879, 'Wed, 25 Nov 2026 02:00:00 GMT')}
      </d:multistatus>`);
    }
    res.writeHead(404); return res.end('not found');
  }
  if (req.method === 'GET' || req.method === 'HEAD') {
    const file = SAMPLES[pathname.replace(/\/+$/, '')] || SAMPLES[pathname];
    if (!file || !fs.existsSync(file)) { res.writeHead(404); return res.end('not found'); }
    const stat = fs.statSync(file);
    res.writeHead(200, { 'Content-Type': 'image/jpeg', 'Content-Length': stat.size });
    if (req.method === 'HEAD') return res.end();
    return fs.createReadStream(file).pipe(res);
  }
  res.writeHead(405); res.end('method not allowed');
});

server.listen(PORT, '127.0.0.1', () => {
  console.log(`mock webdav http://127.0.0.1:${PORT}/dav/ (user: demo, pass: demo)`);
});
