'use strict';

const http = require('http');
const fs = require('fs');
const fsp = fs.promises;
const path = require('path');
const url = require('url');
const QRCode = require('qrcode');
const {
  json,
  fail,
  readBody,
  mimeFor,
  isImageName,
  isInside,
  isLocalRequest,
  getClientIp,
  localAddresses,
  randomToken,
  ensureDir,
  safeName,
  uniqueFile,
  formatBytes
} = require('./util');
const { CloudError } = require('./clouds');
const { Tailscale, isTailscaleAddress } = require('./tailscale');

const APP_DIR = path.join(__dirname, '..', 'app');

function corsHeaders(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET,POST,PATCH,DELETE,OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, X-Xphoto-Token');
  res.setHeader('Access-Control-Allow-Private-Network', 'true');
  res.setHeader('Access-Control-Expose-Headers', 'Content-Disposition, X-Xphoto-Saved, X-Xphoto-Archive');
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('Referrer-Policy', 'no-referrer');
}

function sendJson(res, status, payload, extra) {
  json(res, status, payload, extra);
}

function parseRange(header, size) {
  if (!header) return null;
  const match = /^bytes=(\d*)-(\d*)$/i.exec(header.trim());
  if (!match) return null;
  let start = match[1] ? Number(match[1]) : null;
  let end = match[2] ? Number(match[2]) : null;
  if (start === null && end === null) return null;
  if (start === null) {
    start = Math.max(0, size - end);
    end = size - 1;
  } else {
    if (end === null || end >= size) end = size - 1;
  }
  if (start > end || start >= size) return { invalid: true };
  return { start, end };
}

async function sendFile(req, res, file, options = {}) {
  let stat;
  try {
    stat = await fsp.stat(file);
  } catch {
    return fail(res, 404, '文件不存在');
  }
  if (!stat.isFile()) return fail(res, 404, '文件不存在');
  const etag = options.etag || `"${stat.size.toString(16)}-${Math.round(stat.mtimeMs).toString(16)}"`;
  if (options.etagCheck !== false && req.headers['if-none-match'] === etag) {
    res.writeHead(304, { ETag: etag });
    return res.end();
  }
  const range = parseRange(req.headers.range, stat.size);
  if (range && range.invalid) {
    res.writeHead(416, { 'Content-Range': `bytes */${stat.size}` });
    return res.end();
  }
  const contentType = options.contentType || mimeFor(file);
  const disposition = options.downloadName
    ? `attachment; filename*=UTF-8''${encodeURIComponent(options.downloadName)}`
    : options.inlineName
      ? `inline; filename*=UTF-8''${encodeURIComponent(options.inlineName)}`
      : null;
  const headers = {
    'Content-Type': contentType,
    'Accept-Ranges': 'bytes',
    ETag: etag,
    'Last-Modified': new Date(stat.mtimeMs).toUTCString(),
    'Cache-Control': options.cache || 'private, max-age=86400',
    ...(disposition ? { 'Content-Disposition': disposition } : {}),
    ...(options.headers || {})
  };
  if (range) {
    headers['Content-Range'] = `bytes ${range.start}-${range.end}/${stat.size}`;
    headers['Content-Length'] = range.end - range.start + 1;
    res.writeHead(206, headers);
    if (req.method === 'HEAD') return res.end();
    fs.createReadStream(file, { start: range.start, end: range.end }).pipe(res);
    return;
  }
  headers['Content-Length'] = stat.size;
  res.writeHead(200, headers);
  if (req.method === 'HEAD') return res.end();
  fs.createReadStream(file).pipe(res);
}

async function serveStatic(req, res, pathname) {
  let rel = decodeURIComponent(pathname);
  if (rel === '/' || rel === '') rel = '/index.html';
  if (rel === '/sw.js') {
    res.setHeader('Service-Worker-Allowed', '/');
    res.setHeader('Cache-Control', 'no-cache');
  }
  const target = path.join(APP_DIR, rel.replace(/^\/+/, ''));
  if (!isInside(target, APP_DIR)) return fail(res, 403, '禁止访问');
  let stat;
  try {
    stat = await fsp.stat(target);
  } catch {
    return fail(res, 404, 'Not found');
  }
  if (stat.isDirectory()) return fail(res, 404, 'Not found');
  const ext = path.extname(target).toLowerCase();
  const cache = ext === '.html' ? 'no-cache' : ext === '.js' || ext === '.css' ? 'no-cache' : 'public, max-age=604800';
  res.writeHead(200, {
    'Content-Type': mimeFor(target),
    'Content-Length': stat.size,
    'Cache-Control': cache
  });
  if (req.method === 'HEAD') return res.end();
  fs.createReadStream(target).pipe(res);
}

function createAppServer(context) {
  const { store, library, media, clouds, hooks = {} } = context;
  const tailscale = context.tailscale || new Tailscale();
  const sessions = new Map();
  const loginAttempts = new Map();
  let qrCache = { key: '', value: '' };

  function sessionFrom(req) {
    const cookie = String(req.headers.cookie || '');
    const match = /(?:^|;\s*)xphoto_session=([^;]+)/.exec(cookie);
    const value = match ? decodeURIComponent(match[1]) : String(req.headers['x-xphoto-session'] || '');
    if (!value) return '';
    const expires = sessions.get(value);
    if (!expires || expires < Date.now()) {
      sessions.delete(value);
      return '';
    }
    return value;
  }

  function createSession() {
    const value = randomToken(30);
    sessions.set(value, Date.now() + 30 * 24 * 3600 * 1000);
    return value;
  }

  function tooManyAttempts(ip) {
    const now = Date.now();
    const recent = (loginAttempts.get(ip) || []).filter((at) => now - at < 60000);
    if (recent.length >= 8) {
      loginAttempts.set(ip, recent);
      return true;
    }
    recent.push(now);
    loginAttempts.set(ip, recent);
    return false;
  }

  async function shareInfo(req, { local } = {}) {
    const port = req.socket.localPort || context.port || store.port;
    const token = store.share.token;
    const addresses = localAddresses();
    const urls = addresses.map((item) => ({
      ...item,
      url: `http://${item.address}:${port}/?t=${encodeURIComponent(token)}`
    }));
    const primary = urls[0] ? urls[0].url : `http://127.0.0.1:${port}/`;
    const ts = local ? await tailscale.info() : null;
    const tailscaleUrl = local && store.remoteAccess && ts && ts.ip
      ? `http://${ts.ip}:${port}/`
      : '';
    return {
      enabled: store.share.enabled,
      port,
      token: local ? token : undefined,
      primaryUrl: local ? primary : '',
      urls: local ? urls : [],
      remoteAccess: store.remoteAccess,
      passwordSet: store.passwordSet,
      tailscale: local ? ts : undefined,
      tailscaleUrl,
      addresses: local ? addresses.map(({ address, interface: iface, score }) => ({ address, interface: iface, score })) : []
    };
  }

  async function qrFor(value) {
    if (qrCache.key === value && qrCache.value) return qrCache.value;
    const dataUrl = await QRCode.toDataURL(value, {
      width: 440,
      margin: 1,
      errorCorrectionLevel: 'M',
      color: { dark: '#0d1628', light: '#ffffff' }
    });
    qrCache = { key: value, value: dataUrl };
    return dataUrl;
  }

  function checkAuth(req, res) {
    const local = isLocalRequest(req);
    if (local) return { ok: true, local: true };
    if (!store.share.enabled) {
      fail(res, 403, '这台电脑尚未开启局域网访问');
      return { ok: false };
    }
    const tailnet = isTailscaleAddress(getClientIp(req)) || isTailscaleAddress(req.socket.localAddress);
    if (tailnet && !store.remoteAccess) {
      fail(res, 403, 'Tailscale 远程访问未开启，请先在电脑上打开开关');
      return { ok: false };
    }
    if (tailnet && !store.passwordSet) {
      fail(res, 403, '请先在电脑上设置访问密码，再使用 Tailscale', { needPasswordSetup: true });
      return { ok: false };
    }
    if (tailnet) {
      if (sessionFrom(req)) return { ok: true, local: false, tailnet: true };
      fail(res, 401, '请输入 xphoto 访问密码', { needPassword: true });
      return { ok: false };
    }
    const parsed = new URL(req.url, 'http://localhost');
    const token = parsed.searchParams.get('token') || parsed.searchParams.get('t') || req.headers['x-xphoto-token'];
    if (!token || token !== store.share.token) {
      fail(res, 401, '访问口令不正确，请重新扫描电脑上显示的二维码');
      return { ok: false };
    }
    return { ok: true, local: false };
  }

  function requireLocal(res, auth) {
    if (!auth.local) {
      fail(res, 403, '该操作只能在这台电脑上进行');
      return false;
    }
    return true;
  }

  function publicClouds() {
    return clouds.publicList();
  }

  async function buildState(req, auth) {
    const data = await library.getState();
    const share = await shareInfo(req, { local: auth.local });
    const settings = { ...store.config.settings };
    if (!auth.local) delete settings.downloadDir;
    const desktop = /Electron/i.test(req.headers['user-agent'] || '');
    return {
      ok: true,
      version: context.version || '1.6.6',
      desktop,
      isLocal: auth.local,
      deviceName: store.deviceName,
      downloadDir: auth.local ? store.downloadDir : undefined,
      share,
      clouds: publicClouds(),
      settings,
      downloads: store.downloads.slice(0, 80).map((item) => ({
        ...item,
        path: auth.local ? item.path : undefined
      })),
      ...data
    };
  }

  const server = http.createServer(async (req, res) => {
    corsHeaders(req, res);
    if (req.method === 'OPTIONS') {
      res.writeHead(204);
      return res.end();
    }
    const parsed = new URL(req.url, 'http://localhost');
    const pathname = parsed.pathname;
    try {
      if (!pathname.startsWith('/api/')) {
        if (req.method !== 'GET' && req.method !== 'HEAD') return fail(res, 405, 'Method not allowed');
        return await serveStatic(req, res, pathname);
      }

      if (pathname === '/api/auth/status' && req.method === 'GET') {
        const tailnet = isTailscaleAddress(getClientIp(req)) || isTailscaleAddress(req.socket.localAddress);
        return sendJson(res, 200, {
          ok: true,
          shareEnabled: store.share.enabled,
          passwordSet: store.passwordSet,
          remoteAccess: store.remoteAccess,
          tailnet,
          authenticated: Boolean(sessionFrom(req) || isLocalRequest(req))
        });
      }

      if (pathname === '/api/auth/login' && req.method === 'POST') {
        const ip = getClientIp(req) || 'unknown';
        if (tooManyAttempts(ip)) return fail(res, 429, '尝试次数过多，请 1 分钟后再试');
        if (!store.share.enabled) return fail(res, 403, '这台电脑尚未开启访问');
        if (!store.passwordSet) return fail(res, 400, '电脑上还没有设置访问密码', { needPasswordSetup: true });
        let body;
        try { body = await readBody(req); } catch { return fail(res, 400, '请求格式不正确'); }
        if (!store.checkPassword(body.password)) return fail(res, 401, '密码不正确');
        const session = createSession();
        return sendJson(res, 200, { ok: true }, {
          'Set-Cookie': `xphoto_session=${encodeURIComponent(session)}; Path=/; HttpOnly; SameSite=Lax; Max-Age=2592000`
        });
      }

      if (pathname === '/api/security/password' && req.method === 'POST') {
        const auth = checkAuth(req, res);
        if (!auth.ok) return;
        if (!requireLocal(res, auth)) return;
        let body;
        try { body = await readBody(req); } catch { return fail(res, 400, '请求格式不正确'); }
        try {
          store.setPassword(body.password);
          sessions.clear();
          return sendJson(res, 200, { ok: true, passwordSet: store.passwordSet });
        } catch (error) {
          return fail(res, 400, error.message);
        }
      }

      const auth = checkAuth(req, res);
      if (!auth.ok) return;

      if (pathname === '/api/health') {
        return sendJson(res, 200, { ok: true, name: 'xphoto', version: context.version });
      }

      if (pathname === '/api/state' && req.method === 'GET') {
        const state = await buildState(req, auth);
        return sendJson(res, 200, state);
      }

      if (pathname === '/api/network' && req.method === 'GET') {
        if (!requireLocal(res, auth)) return;
        const info = await shareInfo(req, { local: true });
        return sendJson(res, 200, { ok: true, ...info });
      }

      if (pathname === '/api/share/qr' && req.method === 'GET') {
        const info = await shareInfo(req, { local: true });
        if (!auth.local) {
          const phoneInfo = await shareInfo(req, { local: false });
          return sendJson(res, 200, {
            ok: true,
            enabled: store.share.enabled,
            url: phoneInfo.primaryUrl || '',
            dataUrl: ''
          });
        }
        const target = parsed.searchParams.get('url') || info.primaryUrl;
        const dataUrl = await qrFor(target);
        return sendJson(res, 200, { ok: true, enabled: store.share.enabled, url: target, dataUrl });
      }

      if (pathname === '/api/photos' && req.method === 'GET') {
        const result = await library.query({
          albumId: parsed.searchParams.get('albumId') || '',
          rootId: parsed.searchParams.get('rootId') || '',
          q: parsed.searchParams.get('q') || '',
          sort: parsed.searchParams.get('sort') || 'desc',
          offset: Number(parsed.searchParams.get('offset') || 0),
          limit: Number(parsed.searchParams.get('limit') || 240),
          favorites: parsed.searchParams.get('favorites') === '1',
          recent: parsed.searchParams.get('recent') === '1'
        });
        return sendJson(res, 200, { ok: true, ...result });
      }

      if (pathname === '/api/albums' && req.method === 'GET') {
        const state = await library.getState();
        return sendJson(res, 200, { ok: true, albums: state.albums, roots: state.roots });
      }

      if (pathname === '/api/thumb' && req.method === 'GET') {
        const id = parsed.searchParams.get('id') || '';
        const size = Number(parsed.searchParams.get('size') || 400);
        const photo = library.getPhoto(id);
        if (!photo) return fail(res, 404, '照片不存在');
        const thumb = await media.getLocalThumb(photo, size);
        if (!thumb && photo.mediaType === 'video') {
          const svg = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 320 320"><defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop stop-color="#20304f"/><stop offset="1" stop-color="#0b1020"/></linearGradient></defs><rect width="320" height="320" fill="url(#g)"/><circle cx="160" cy="160" r="54" fill="#ffffff" fill-opacity=".16"/><path d="M147 132l52 28-52 28z" fill="#fff"/></svg>';
          res.writeHead(200, {
            'Content-Type': 'image/svg+xml; charset=utf-8',
            'Content-Length': Buffer.byteLength(svg),
            'Cache-Control': 'private, max-age=3600'
          });
          return res.end(svg);
        }
        if (!thumb) {
          return sendFile(req, res, photo.path, {
            cache: 'private, max-age=3600',
            contentType: mimeFor(photo.path)
          });
        }
        if (thumb.buffer) {
          res.writeHead(200, {
            'Content-Type': 'image/webp',
            'Content-Length': thumb.buffer.length,
            'Cache-Control': 'private, max-age=2592000'
          });
          return res.end(thumb.buffer);
        }
        return sendFile(req, res, thumb.file, {
          cache: 'private, max-age=2592000',
          contentType: 'image/webp'
        });
      }

      if (pathname === '/api/image' && req.method === 'GET') {
        const id = parsed.searchParams.get('id') || '';
        const photo = library.getPhoto(id);
        if (!photo) return fail(res, 404, '照片不存在');
        if (parsed.searchParams.get('info') === '1') {
          const meta = await media.metadata(photo.path);
          return sendJson(res, 200, {
            ok: true,
            ...photo,
            ...meta,
            sizeText: formatBytes(photo.size),
            path: auth.local ? photo.path : undefined
          });
        }
        const wantsOriginal = parsed.searchParams.get('original') === '1';
        if (!wantsOriginal) {
          const converted = await media.convertForWeb(photo.path, photo.ext);
          if (converted) {
            res.writeHead(200, {
              'Content-Type': 'image/jpeg',
              'Content-Length': converted.length,
              'Cache-Control': 'private, max-age=86400'
            });
            return res.end(converted);
          }
        }
        return sendFile(req, res, photo.path, {
          inlineName: photo.name,
          cache: 'private, max-age=86400'
        });
      }

      if (pathname === '/api/download' && req.method === 'GET') {
        const id = parsed.searchParams.get('id') || '';
        const photo = library.getPhoto(id);
        if (!photo) return fail(res, 404, '照片不存在');
        const archive = parsed.searchParams.get('archive') === '1';
        let archiveName = '';
        if (archive) {
          try {
            const target = parsed.searchParams.get('target') === 'desktop' ? '电脑下载' : '手机下载';
            const device = safeName(parsed.searchParams.get('device') || '手机', '手机');
            const dir = store.subDir(target, device);
            const dest = uniqueFile(dir, safeName(photo.name));
            await fsp.copyFile(photo.path, dest);
            archiveName = path.basename(dest);
            store.addDownload({
              source: 'local',
              name: photo.name,
              path: dest,
              size: photo.size,
              device
            });
            library.invalidate();
          } catch (error) {
            console.error('[xphoto] 归档下载失败:', error.message);
          }
        }
        return sendFile(req, res, photo.path, {
          downloadName: photo.name,
          headers: archiveName ? { 'X-Xphoto-Archive': encodeURIComponent(archiveName) } : {},
          cache: 'no-store'
        });
      }

      if (pathname === '/api/export' && req.method === 'POST') {
        const body = await readBody(req);
        const ids = Array.isArray(body.ids) ? body.ids.slice(0, 500) : [];
        if (!ids.length) return fail(res, 400, '没有选择照片');
        const targetName = body.target === 'phone' ? '手机下载' : '电脑下载';
        const device = safeName(body.device || '电脑', '电脑');
        const dir = store.subDir(targetName, device);
        const saved = [];
        for (const id of ids) {
          const photo = library.getPhoto(id);
          if (!photo) continue;
          try {
            const dest = uniqueFile(dir, safeName(photo.name));
            await fsp.copyFile(photo.path, dest);
            saved.push({ name: path.basename(dest), path: dest });
            store.addDownload({
              source: 'local',
              name: photo.name,
              path: dest,
              size: photo.size,
              device
            });
          } catch (error) {
            console.error('[xphoto] 导出失败:', error.message);
          }
        }
        if (saved.length) library.invalidate();
        if (saved.length && auth.local && hooks.reveal) {
          try { hooks.reveal(dir); } catch {}
        }
        return sendJson(res, 200, {
          ok: true,
          saved,
          dir: auth.local ? dir : undefined,
          total: saved.length
        });
      }

      if (pathname === '/api/favorite' && req.method === 'POST') {
        const body = await readBody(req);
        if (!body.id) return fail(res, 400, '缺少照片 id');
        const value = library.setFavorite(body.id, Boolean(body.value));
        return sendJson(res, 200, { ok: true, value });
      }

      if (pathname === '/api/move' && req.method === 'POST') {
        const body = await readBody(req);
        const ids = Array.isArray(body.ids) ? body.ids.slice(0, 500) : [];
        if (!ids.length) return fail(res, 400, '没有选择照片');
        if (!body.targetAlbumId) return fail(res, 400, '没有选择目标相册');
        const result = await library.move(ids, String(body.targetAlbumId));
        if (result.error) return fail(res, 400, result.error);
        return sendJson(res, 200, { ok: true, ...result });
      }

      if (pathname === '/api/trash' && req.method === 'GET') {
        const items = library.trashList();
        return sendJson(res, 200, {
          ok: true,
          dir: library.trashDir,
          count: items.length,
          bytes: items.reduce((sum, item) => sum + item.size, 0),
          items
        });
      }

      if (pathname === '/api/trash' && req.method === 'POST') {
        const body = await readBody(req);
        const ids = Array.isArray(body.ids) ? body.ids.slice(0, 500) : [];
        if (!ids.length) return fail(res, 400, '没有选择照片');
        const count = await library.trash(ids);
        return sendJson(res, 200, { ok: true, count });
      }

      if (pathname === '/api/trash/empty' && req.method === 'POST') {
        const ok = library.emptyTrash();
        return sendJson(res, 200, { ok });
      }

      if (pathname === '/api/cache' && req.method === 'GET') {
        if (!requireLocal(res, auth)) return;
        let bytes = 0;
        let files = 0;
        try {
          const names = await fsp.readdir(store.thumbDir);
          for (const name of names) {
            try {
              const stat = await fsp.stat(path.join(store.thumbDir, name));
              if (stat.isFile()) { bytes += stat.size; files += 1; }
            } catch {}
          }
        } catch {}
        return sendJson(res, 200, { ok: true, bytes, files, text: formatBytes(bytes) });
      }

      if (pathname === '/api/cache/clear' && req.method === 'POST') {
        if (!requireLocal(res, auth)) return;
        let removed = 0;
        try {
          const names = await fsp.readdir(store.thumbDir);
          for (const name of names) {
            try {
              await fsp.unlink(path.join(store.thumbDir, name));
              removed += 1;
            } catch {}
          }
        } catch {}
        return sendJson(res, 200, { ok: true, removed });
      }

      if (pathname === '/api/info' && req.method === 'GET') {
        const id = parsed.searchParams.get('id') || '';
        const photo = library.getPhoto(id);
        if (!photo) return fail(res, 404, '照片不存在');
        const meta = await media.metadata(photo.path);
        return sendJson(res, 200, {
          ok: true,
          ...library.publicPhoto(photo),
          ...meta,
          sizeText: formatBytes(photo.size),
          path: photo.path
        });
      }

      if (pathname === '/api/roots' && req.method === 'POST') {
        if (!requireLocal(res, auth)) return;
        const body = await readBody(req);
        const root = store.addRoot(body.path, { name: body.name });
        library.invalidate(root.id);
        return sendJson(res, 200, { ok: true, root });
      }

      if (pathname === '/api/roots/browse' && req.method === 'POST') {
        if (!requireLocal(res, auth)) return;
        if (!hooks.pickFolders) return fail(res, 501, '当前环境不支持文件夹选择');
        const folders = await hooks.pickFolders();
        const added = [];
        for (const folder of folders || []) {
          try {
            const root = store.addRoot(folder);
            library.invalidate(root.id);
            added.push(root);
          } catch (error) {
            console.error('[xphoto] 添加文件夹失败:', error.message);
          }
        }
        return sendJson(res, 200, { ok: true, folders: folders || [], added });
      }

      if (pathname.startsWith('/api/roots/') && req.method === 'DELETE') {
        if (!requireLocal(res, auth)) return;
        const id = decodeURIComponent(pathname.slice('/api/roots/'.length));
        const root = store.removeRoot(id);
        library.invalidate(id);
        return sendJson(res, 200, { ok: true, root });
      }

      if (pathname === '/api/roots/rescan' && req.method === 'POST') {
        library.invalidate();
        const state = await buildState(req, auth);
        return sendJson(res, 200, state);
      }

      if (pathname === '/api/settings' && req.method === 'PATCH') {
        const body = await readBody(req);
        if (Object.prototype.hasOwnProperty.call(body, 'downloadDir') && !auth.local) {
          return fail(res, 403, '修改下载目录只能在这台电脑上进行');
        }
        if (Object.prototype.hasOwnProperty.call(body, 'closeToTray') && !auth.local) {
          delete body.closeToTray;
        }
        const settings = store.updateSettings(body);
        context.onSettingsChanged && context.onSettingsChanged(settings);
        return sendJson(res, 200, { ok: true, settings });
      }

      if (pathname === '/api/share' && req.method === 'POST') {
        if (!requireLocal(res, auth)) return;
        const body = await readBody(req);
        if (typeof body.enabled === 'boolean') store.setShareEnabled(body.enabled);
        if (body.rotate) store.rotateShareToken();
        if (typeof body.remoteAccess === 'boolean') {
          if (body.remoteAccess && !store.passwordSet) {
            return fail(res, 400, '请先设置访问密码，再开启 Tailscale 远程访问');
          }
          store.setRemoteAccess(body.remoteAccess);
        }
        const info = await shareInfo(req, { local: true });
        if (hooks.onShareChanged) {
          try { hooks.onShareChanged(info); } catch {}
        }
        return sendJson(res, 200, { ok: true, ...info });
      }

      if (pathname === '/api/network/firewall' && req.method === 'POST') {
        if (!requireLocal(res, auth)) return;
        if (!hooks.openFirewall) return fail(res, 501, '当前环境不支持自动放行');
        const result = await hooks.openFirewall(Number(parsed.searchParams.get('port') || store.port));
        return sendJson(res, 200, { ok: true, ...result });
      }

      if (pathname === '/api/reveal' && req.method === 'POST') {
        if (!requireLocal(res, auth)) return;
        let body;
        try { body = await readBody(req); } catch { return fail(res, 400, '请求格式不正确'); }
        const ids = Array.isArray(body.ids) ? body.ids.slice(0, 50) : [];
        if (!ids.length) return fail(res, 400, '没有选择照片');
        const photo = library.getPhoto(ids[0]);
        if (!photo) return fail(res, 404, '照片不存在');
        if (hooks.reveal) hooks.reveal(photo.path);
        else if (hooks.openPath) hooks.openPath(path.dirname(photo.path));
        else return fail(res, 501, '当前环境不支持打开文件夹');
        return sendJson(res, 200, { ok: true, count: ids.length, name: photo.name });
      }

      if (pathname === '/api/open' && req.method === 'POST') {
        if (!requireLocal(res, auth)) return;
        const body = await readBody(req);
        if (body.kind === 'download') {
          await ensureDir(store.downloadDir);
          hooks.openPath && hooks.openPath(store.downloadDir);
          return sendJson(res, 200, { ok: true });
        }
        if (body.kind === 'path' && body.path) {
          const target = path.resolve(body.path);
          if (!isInside(target, store.downloadDir) && !library.findByPath(target)) {
            return fail(res, 403, '只能打开相册内的文件夹');
          }
          hooks.reveal ? hooks.reveal(target) : hooks.openPath && hooks.openPath(target);
          return sendJson(res, 200, { ok: true });
        }
        return fail(res, 400, '参数错误');
      }

      if (pathname === '/api/downloads' && req.method === 'GET') {
        return sendJson(res, 200, {
          ok: true,
          items: store.downloads.slice(0, 200).map((item) => ({
            ...item,
            path: auth.local ? item.path : undefined
          }))
        });
      }

      if (pathname === '/api/clouds' && req.method === 'GET') {
        return sendJson(res, 200, { ok: true, clouds: publicClouds() });
      }

      if (pathname === '/api/clouds/test' && req.method === 'POST') {
        const body = await readBody(req);
        const result = await clouds.test(body);
        return sendJson(res, 200, { ok: true, ...result });
      }

      if (pathname === '/api/clouds' && req.method === 'POST') {
        const body = await readBody(req);
        const cloud = await clouds.create(body);
        return sendJson(res, 200, { ok: true, cloud });
      }

      if (pathname.startsWith('/api/clouds/')) {
        const rest = pathname.slice('/api/clouds/'.length);
        const parts = rest.split('/');
        const cloudId = decodeURIComponent(parts[0] || '');
        const action = parts[1] || '';
        if (req.method === 'DELETE' && !action) {
          const cloud = store.removeCloud(cloudId);
          return sendJson(res, 200, { ok: true, cloud: { id: cloud.id, name: cloud.name } });
        }
        if (req.method === 'GET' && action === 'list') {
          const folder = parsed.searchParams.get('folder') || '';
          const result = await clouds.list(cloudId, folder);
          return sendJson(res, 200, { ok: true, ...result });
        }
        if (req.method === 'GET' && action === 'thumb') {
          const kind = parsed.searchParams.get('kind') || 'file';
          const value = parsed.searchParams.get('value') || '';
          const version = parsed.searchParams.get('v') || '';
          const size = Number(parsed.searchParams.get('size') || 420);
          return await clouds.thumb(cloudId, kind, value, version, res, size);
        }
        if (req.method === 'GET' && action === 'raw') {
          const kind = parsed.searchParams.get('kind') || 'file';
          const value = parsed.searchParams.get('value') || '';
          return await clouds.raw(cloudId, kind, value, res);
        }
        if (req.method === 'POST' && action === 'save') {
          const body = await readBody(req);
          const saved = await clouds.saveToLocal(cloudId, body);
          library.invalidate();
          return sendJson(res, 200, { ok: true, ...saved, path: auth.local ? saved.path : undefined });
        }
        if (req.method === 'GET' && action === 'download') {
          const kind = parsed.searchParams.get('kind') || 'file';
          const value = parsed.searchParams.get('value') || '';
          const name = parsed.searchParams.get('name') || 'image.jpg';
          const folder = parsed.searchParams.get('folder') || '根目录';
          const device = parsed.searchParams.get('device') || '手机';
          const archive = parsed.searchParams.get('archive') !== '0';
          const result = await clouds.downloadToResponse(cloudId, {
            kind,
            value,
            name,
            folder,
            deviceName: device,
            archive
          }, res);
          if (archive) library.invalidate();
          return result;
        }
        return fail(res, 404, '接口不存在');
      }

      return fail(res, 404, '接口不存在');
    } catch (error) {
      if (error instanceof CloudError) {
        return fail(res, error.status || 400, error.message);
      }
      console.error('[xphoto] 请求失败:', req.method, req.url, error);
      if (!res.headersSent) {
        return fail(res, 500, error.message || '服务器开小差了');
      }
      try { res.end(); } catch {}
    }
  });

  server.on('clientError', (err, socket) => {
    try { socket.end('HTTP/1.1 400 Bad Request\r\n\r\n'); } catch {}
  });

  return { server, shareInfo, qrFor };
}

module.exports = { createAppServer, APP_DIR };
