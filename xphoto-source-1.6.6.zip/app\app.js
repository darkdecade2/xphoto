'use strict';

/* ============================================================
   xphoto — 电脑 + 手机 局域网相册
   ============================================================ */

const $ = (selector, root = document) => root.querySelector(selector);
const $$ = (selector, root = document) => Array.from(root.querySelectorAll(selector));
const isMobile = () => window.matchMedia('(max-width: 900px)').matches;
const ANDROID = Boolean(window.XPhotoAndroid);

function formatBytes(value) {
  const n = Number(value) || 0;
  if (n < 1024) return `${n} B`;
  const units = ['KB', 'MB', 'GB', 'TB'];
  let size = n / 1024;
  let index = 0;
  while (size >= 1024 && index < units.length - 1) {
    size /= 1024;
    index += 1;
  }
  return `${size >= 10 ? Math.round(size) : size.toFixed(1)} ${units[index]}`;
}

const LS = {
  token: 'xphoto.token',
  theme: 'xphoto.theme',
  remotes: 'xphoto.remotes',
  grid: 'xphoto.grid',
  mobileGrid: 'xphoto.mobileGrid',
  localPinned: 'xphoto.localPinned',
  albumCollapsed: 'xphoto.albumCollapsed'
};

const params = new URLSearchParams(location.search);
const state = {
  token: params.get('t') || params.get('token') || localStorage.getItem(LS.token) || '',
  boot: null,
  bootError: '',
  loadingBoot: true,
  route: { name: 'photos', rootId: '', album: null, q: '', remote: null, remoteAlbum: null },
  history: [],
  photos: [],
  photoTotal: 0,
  photoHasMore: false,
  photoLoading: false,
  photoError: '',
  selecting: false,
  selected: new Set(),
  sort: 'desc',
  gridSize: 5,
  mobileGrid: 3,
  wheelAccum: 0,
  gridTimer: 0,
  theme: 'auto',
  clouds: [],
  cloudAccount: null,
  cloudPath: [],
  cloudData: null,
  cloudLoading: false,
  cloudError: '',
  remotes: [],
  remoteState: null,
  remotePhotos: [],
  remoteLoading: false,
  remoteError: '',
  downloads: [],
  trashItems: [],
  trashLoading: false,
  trashError: '',
  cacheBytes: 0,
  cacheFiles: 0,
  localFolders: [],
  localPhotos: [],
  localRecycleCount: 0,
  localFolderId: 'all',
  localLoading: false,
  localError: '',
  albumCollapsed: (() => {
    try {
      const saved = JSON.parse(localStorage.getItem(LS.albumCollapsed) || '[]');
      return Array.isArray(saved) ? saved : [];
    } catch { return []; }
  })(),
  localPinned: (() => {
    try {
      const value = JSON.parse(localStorage.getItem('xphoto.localPinned') || '[]');
      return Array.isArray(value) ? value : [];
    } catch (error) { return []; }
  })(),
  modal: '',
  modalData: null,
  confirm: null,
  cloudFormType: '123',
  viewer: null,
  qr: '',
  qrLoading: false,
  shareMode: 'lan',
  tailscaleBusy: false
};

// 版本规则：每次发布都必须在本数组最上方加入同版本条目（最新 → 最早），
// 写清电脑端和手机端的变化；不要把旧版本合并或删除。发布前运行 npm run check:release。
const CHANGELOG = [
  ['1.6.6', '当前', [
    '手机本机相册长按「查看位置」现在显示真实存储路径，例如 /storage/emulated/0/DCIM/Camera/xxx.jpg，并可复制。',
    '手机不连接电脑时，点开大图右上角也有「位置」按钮，随时查看本机真实路径。',
    '手机连接电脑时，在手机本机相册选中图片点「位置」，也会显示真实路径，不再只显示媒体库地址。',
    '电脑和手机版本同步到 1.6.6。'
  ]],
  ['1.6.5', '', [
    '长按图片或视频新增「查看位置」：电脑显示完整路径，可复制路径或打开所在文件夹；手机显示媒体库位置并可复制。',
    '电脑和手机本机多选栏都增加「位置」按钮，选中后可随时查看具体位置。',
    '电脑和手机版本同步到 1.6.5。'
  ]],
  ['1.6.4', '', [
    '手机连接电脑新增「局域网」和「Tailscale」两种方式，不在同一网络也能用 Tailscale 加密访问。',
    '新增访问密码：Tailscale 远程访问必须输入密码，登录状态保留 30 天，密码只保存在这台电脑。',
    '电脑端连接面板增加 Tailscale 开关、安装检测、100.x 网址和一键复制；手机端连接提示同时支持两种网址。',
    '电脑端分享失败时可「打开文件夹」直接定位并选中文件，拖到微信/QQ 发送。',
    '电脑和手机版本同步到 1.6.4。'
  ]],
  ['1.6.3', '', [
    '手机本机相册（连接电脑时的网页入口）也支持长按多选、日期全选和分享。',
    '分享本机照片直接使用手机 content:// 地址，不再走电脑图片地址，微信/QQ 可以正常发送。',
    '电脑和手机版本同步到 1.6.3。'
  ]],
  ['1.6.2', '', [
    '修复手机分享电脑照片时微信/QQ只显示 image、发送失败：先把电脑图片/视频下载到手机临时分享缓存，再以本地 content:// 分享。',
    '分享文件通过应用内置只读 ShareProvider 提供，会自动清理，不会混进手机相册。',
    '手机分享前会提示「正在准备分享…」；单张/多张、图片/视频都按实际类型发送。',
    '电脑和手机版本同步到 1.6.2。'
  ]],
  ['1.6.1', '', [
    '修复手机多选后分享到微信/QQ 失败：分享 Intent 增加 ClipData 读取授权，微信和 QQ 能真正拿到图片/视频。',
    '单张和多张分享都带读取权限；分享面板同样带上授权，减少部分手机 ROM 的拦截。',
    '电脑和手机版本同步到 1.6.1。'
  ]],
  ['1.6.0', '', [
    '电脑和手机长按图片进入多选，可批量收藏、移动、删除或分享。',
    '每个日期标题右侧增加「全选」，一次选中这一天的全部照片。',
    '电脑端新增移动到指定相册文件夹；手机端支持系统分享面板，可直接发到微信、QQ。',
    '手机端支持作为图片/视频的打开方式，并补充分享入口。'
  ]],
  ['1.5.9', '', [
    '相册页改为按左侧导入的文件夹分组：每个文件夹是一个明显的小标题，下面显示它自己的相册。',
    '小标题可以点开/折叠，折叠状态会记住；手机和电脑看到的分组一致。',
    '文件夹很多时不再是一整片平铺的相册，找起来更快。'
  ]],
  ['1.5.8', '', [
    '手机视频改为优先交给系统播放器打开（本机视频和连接电脑的视频都适用），解决内置播放器有进度、有声音但画面全黑的问题。',
    '系统播放器不可用时才退回内置播放器，不会再只剩封面。',
    '电脑和手机版本同步到 1.5.8。'
  ]],
  ['1.5.7', '', [
    '修复手机点视频仍停在封面/黑屏：视频对话框改为显示后再加载，避免 VideoView 还没有画面表面就开始准备。',
    '内置播放器失败时自动交给手机系统播放器再试一次，兼容更多编码。',
    '电脑和手机版本同步到 1.5.7。'
  ]],
  ['1.5.6', '', [
    '修复手机连接电脑后点视频只停在封面：原生桥接以前只接受本地文件，网络视频被直接忽略；现在允许 http/https，交给系统播放器。',
    '视频网格保留首帧封面，点开才是真正播放，不再把封面图当视频。',
    '电脑和手机版本同步到 1.5.6。'
  ]],
  ['1.5.5', '', [
    '视频网格不再直接挂播放器，改用电脑抽出的首帧封面；安卓不再因 HEVC/编码不支持而显示空白播放图标。',
    '手机连接电脑后点视频，优先交给系统播放器打开（APK），播放兼容性和本地视频一致。',
    '「清理手机缓存」现在所有手机端都能在「更多」菜单里找到；浏览器端会清理网页缓存。',
    '视频文件夹的封面加载更快，不用等播放器解码整个视频。'
  ]],
  ['1.5.4', '', [
    '手机打开图片不再写入磁盘缓存；连接电脑时的网页缓存也关闭，退出连接自动清掉。',
    '新增「清理手机缓存」，可在手机更多菜单里随手释放预览内存。',
    '手机本机视频封面改为优先用系统缩略图、缺失时直接抽本地首帧，加载更快。',
    '图片网格的缩略图缓存调整为 32MB 内存缓存，只占运行内存，不占手机存储。'
  ]],
  ['1.5.3', '', [
    '手机有了自己的「手机回收站」，连接或断开电脑都能打开。',
    '手机本机顶部保留「回收站」分类；左侧「手机本机」下也有入口。',
    '在手机回收站点「清空回收站」才会真正删除本机照片和视频；电脑回收站单独显示。'
  ]],
  ['1.5.2', '', [
    '手机连接电脑后，可以直接把电脑照片删除到电脑回收站。',
    '手机选择栏新增「删除」；电脑和手机都有自己的回收站。',
    '手机删除本机照片进手机回收站，删除电脑照片进电脑回收站，互不混用。'
  ]],
  ['1.5.1', '', [
    '电脑和手机都支持视频：视频文件夹会显示出来，网格有播放标记，点开即可播放。',
    '电脑新增回收站；删除先移入回收站，清空才真正删除。',
    '设置里新增缩略图缓存大小显示和「清理」按钮。',
    '图片查看器支持鼠标滚轮、双指缩放和拖动，手机可自由放大。'
  ]],
  ['1.5.0', '', [
    '修复手机连接电脑后网页无法滑动的问题。',
    '右侧快速滚动条固定在屏幕边缘，长相册可以直接拖到最新或最早。'
  ]],
  ['1.4', '', [
    '手机本机相册改为按日期分组的时间线，和连接电脑后的排版一致。',
    '手机和电脑都增加右侧快速拖动条，照片多时不用一直滑。',
    '保留顶部文件夹分类，并支持双指调整网格列数。'
  ]],
  ['1.3', '', [
    '手机和电脑的相册、云盘、设备等页面左上角增加返回键。',
    '设置、设备、下载记录保持无返回键，避免误退。',
    '电脑端版本号与手机端同步到 1.3。'
  ]],
  ['1.2', '', [
    '手机连接电脑后仍能查看自己的本机照片：左侧新增「手机本机」区域。',
    '手机可以添加/选择本机相册文件夹，并在「相册」页看到这些文件夹。',
    '手机侧边栏增加「电脑连接」开关，关闭后直接回到本机相册。'
  ]],
  ['1.1', '', [
    'APK 打开直接进入本机相册，不再强制先填电脑网址。',
    '右下角保留「连接电脑」，想连局域网时再连。',
    '电脑支持 Ctrl + 滚轮缩放网格，手机支持双指缩放。',
    '手机下载的图片留在手机「手机下载」，不再默认复制到电脑。'
  ]],
  ['1.0', '初版', [
    'Windows 电脑端 + 手机网页/局域网相册，参考 Microsoft Photos 与小米相册。',
    '电脑左侧添加本地文件夹，按文件夹分类浏览；支持收藏、最近、下载记录。',
    '手机浏览电脑相册，选择图片下载到电脑的「手机下载」文件夹。',
    '支持 123 云盘 Open API 和 WebDAV（坚果云、Nextcloud、AList、群晖等）。',
    '电脑显示局域网网址和二维码，可开关局域网、放行防火墙。',
    '手机可添加其他电脑的网址，浏览对方电脑上的照片。'
  ]]
];

/* ---------------- icons ---------------- */
const ICON_PATHS = {
  photos: '<rect x="3" y="3" width="18" height="18" rx="3"/><circle cx="8.5" cy="8.5" r="1.6"/><path d="m21 15-4.7-4.7a1.6 1.6 0 0 0-2.3 0L5 19.3"/>',
  heart: '<path d="M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.7l-1-1.1a5.5 5.5 0 0 0-7.8 7.8l1.1 1L12 21l7.8-7.6 1-1a5.5 5.5 0 0 0 0-7.8z"/>',
  'heart-fill': '<path d="M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.7l-1-1.1a5.5 5.5 0 0 0-7.8 7.8l1.1 1L12 21l7.8-7.6 1-1a5.5 5.5 0 0 0 0-7.8z" fill="currentColor" stroke="none"/>',
  clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3.2 2"/>',
  albums: '<rect x="7" y="3" width="14" height="14" rx="2.5"/><path d="M17 21H5a2 2 0 0 1-2-2V7"/>',
  folder: '<path d="M3 7.2A2.2 2.2 0 0 1 5.2 5h3.6l2 2.2h7.9A2.2 2.2 0 0 1 21 9.4v8.4A2.2 2.2 0 0 1 18.8 20H5.2A2.2 2.2 0 0 1 3 17.8z"/>',
  'folder-open': '<path d="M3 8V6.5A2.5 2.5 0 0 1 5.5 4h3.2l2 2.2h7.6A2.5 2.5 0 0 1 20.8 8.7V10"/><path d="M3.5 10h17.2a1 1 0 0 1 1 1.2l-1.5 6.6a2 2 0 0 1-2 1.6H5.3a2 2 0 0 1-2-1.7L2 11.6A1 1 0 0 1 3 10Z"/>',
  plus: '<path d="M12 5v14M5 12h14"/>',
  cloud: '<path d="M7.2 18.2a5.2 5.2 0 0 1-.8-10.3A6.2 6.2 0 0 1 18.4 9a4.6 4.6 0 0 1-.6 9.2z"/>',
  'cloud-plus': '<path d="M7.2 17.4a5.2 5.2 0 0 1-.8-10.3A6.2 6.2 0 0 1 18.4 8.2a4.6 4.6 0 0 1 .4 9.1"/><path d="M12 12.5v6M9 15.5h6"/>',
  monitor: '<rect x="2.5" y="3.5" width="19" height="13.5" rx="2.2"/><path d="M8 21h8M12 17v4"/>',
  smartphone: '<rect x="7" y="2" width="10" height="20" rx="2.4"/><path d="M10.8 18.2h2.4"/>',
  devices: '<rect x="2" y="5" width="13" height="10" rx="2"/><path d="M6.5 19h5M9 15v4"/><rect x="17" y="9" width="5" height="11" rx="1.6"/>',
  search: '<circle cx="11" cy="11" r="7"/><path d="m20 20-3.2-3.2"/>',
  more: '<circle cx="5" cy="12" r="1.6" fill="currentColor" stroke="none"/><circle cx="12" cy="12" r="1.6" fill="currentColor" stroke="none"/><circle cx="19" cy="12" r="1.6" fill="currentColor" stroke="none"/>',
  'chevron-down': '<path d="m6 9 6 6 6-6"/>',
  'chevron-right': '<path d="m9 6 6 6-6 6"/>',
  'chevron-left': '<path d="m15 6-6 6 6 6"/>',
  'arrow-left': '<path d="M19 12H5m6-6-6 6 6 6"/>',
  download: '<path d="M12 3v12m-4.5-4.5L12 15l4.5-4.5"/><path d="M4 20h16"/>',
  'download-cloud': '<path d="M7 16.5a4.5 4.5 0 0 1-.7-8.9A5.5 5.5 0 0 1 17 7.4a4 4 0 0 1 .2 8"/><path d="M12 11v9m-3.2-3.2L12 20l3.2-3.2"/>',
  check: '<path d="m20 6-11 11-5-5"/>',
  'check-circle': '<circle cx="12" cy="12" r="9"/><path d="m8.4 12.2 2.4 2.4 4.8-5"/>',
  x: '<path d="M6 6l12 12M18 6 6 18"/>',
  grid: '<rect x="3" y="3" width="7" height="7" rx="1.6"/><rect x="14" y="3" width="7" height="7" rx="1.6"/><rect x="3" y="14" width="7" height="7" rx="1.6"/><rect x="14" y="14" width="7" height="7" rx="1.6"/>',
  sort: '<path d="M4 7h12M4 12h9M4 17h6"/><path d="M18 8v10m-3.2-3.2L18 18l3.2-3.2"/>',
  settings: '<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .34 1.87l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06A1.7 1.7 0 0 0 15 19.4a1.7 1.7 0 0 0-1 1.55V21a2 2 0 1 1-4 0v-.09a1.7 1.7 0 0 0-1.11-1.55 1.7 1.7 0 0 0-1.87.34l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06A1.7 1.7 0 0 0 4.6 15a1.7 1.7 0 0 0-1.55-1H3a2 2 0 1 1 0-4h.09A1.7 1.7 0 0 0 4.64 8.9a1.7 1.7 0 0 0-.34-1.87l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06A1.7 1.7 0 0 0 9 4.6h.05A1.7 1.7 0 0 0 10.1 3.05V3a2 2 0 1 1 4 0v.09a1.7 1.7 0 0 0 1 1.55 1.7 1.7 0 0 0 1.87-.34l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06A1.7 1.7 0 0 0 19.4 9v.05A1.7 1.7 0 0 0 20.95 10H21a2 2 0 1 1 0 4h-.09A1.7 1.7 0 0 0 19.4 15Z"/>',
  share: '<circle cx="18" cy="5" r="2.6"/><circle cx="6" cy="12" r="2.6"/><circle cx="18" cy="19" r="2.6"/><path d="m8.4 10.8 7.2-4.2M8.4 13.2l7.2 4.2"/>',
  qr: '<rect x="3" y="3" width="7" height="7" rx="1.4"/><rect x="14" y="3" width="7" height="7" rx="1.4"/><rect x="3" y="14" width="7" height="7" rx="1.4"/><path d="M14 14h3v3h-3zM20 14v.01M14 20v.01M20 20v.01M20 17.5v.01M17.5 20v.01"/>',
  copy: '<rect x="9" y="9" width="11" height="11" rx="2.2"/><path d="M5 15V5a2 2 0 0 1 2-2h10"/>',
  trash: '<path d="M4 7h16M9.5 7V5.2A1.2 1.2 0 0 1 10.7 4h2.6a1.2 1.2 0 0 1 1.2 1.2V7M6.5 7l.8 12.1a1.9 1.9 0 0 0 1.9 1.8h5.6a1.9 1.9 0 0 0 1.9-1.8L17.5 7"/><path d="M10 11v6M14 11v6"/>',
  wifi: '<path d="M4.5 12.5a10.5 10.5 0 0 1 15 0M7.8 16a5.6 5.6 0 0 1 8.4 0"/><circle cx="12" cy="19.2" r="1.2" fill="currentColor" stroke="none"/>',
  link: '<path d="M10 13.5a4 4 0 0 0 5.7 0l2.8-2.8a4 4 0 0 0-5.7-5.7l-1.6 1.6"/><path d="M14 10.5a4 4 0 0 0-5.7 0l-2.8 2.8a4 4 0 0 0 5.7 5.7l1.6-1.6"/>',
  sun: '<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/>',
  moon: '<path d="M20.5 14.4A8.5 8.5 0 0 1 9.6 3.5a8.5 8.5 0 1 0 10.9 10.9Z"/>',
  info: '<circle cx="12" cy="12" r="9"/><path d="M12 11v5M12 7.6v.01"/>',
  external: '<path d="M14 4h6v6M20 4l-8.5 8.5"/><path d="M18 14v4.5A2.5 2.5 0 0 1 15.5 21h-9A2.5 2.5 0 0 1 4 18.5v-9A2.5 2.5 0 0 1 6.5 7H11"/>',
  image: '<rect x="3" y="4" width="18" height="16" rx="2.5"/><circle cx="8.5" cy="9.5" r="1.6"/><path d="m21 15-4.5-4.5a1.6 1.6 0 0 0-2.3 0L5.5 19"/>',
  refresh: '<path d="M20 11a8 8 0 1 0-2.3 6.3"/><path d="M20 4v7h-7"/>',
  play: '<path d="M8 5.5v13l11-6.5z"/>',
  video: '<rect x="3" y="5" width="13" height="14" rx="2"/><path d="m16 10 5-3v10l-5-3z"/>',
  shield: '<path d="M12 3 5 6v5.2c0 4.4 2.9 8.2 7 9.8 4.1-1.6 7-5.4 7-9.8V6z"/><path d="m9 12 2 2 4-4"/>',
  disk: '<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="2.6"/><path d="M12 3v6.4M4.2 16.5l5.5-3.2M19.8 16.5l-5.5-3.2"/>',
  power: '<path d="M12 3v9"/><path d="M6.2 6.2a8 8 0 1 0 11.6 0"/>',
  lock: '<rect x="4" y="10" width="16" height="11" rx="2.4"/><path d="M8 10V7.5a4 4 0 0 1 8 0V10"/>',
  keyboard: '<rect x="2.5" y="6" width="19" height="12" rx="2.2"/><path d="M6 10h.01M9.5 10h.01M13 10h.01M16.5 10h.01M6 13.5h.01M9.5 13.5h.01M13 13.5h.01M16.5 13.5h.01M8 16.5h8"/>',
  sparkles: '<path d="M12 3l1.9 4.6L18.5 9.5l-4.6 1.9L12 16l-1.9-4.6L5.5 9.5l4.6-1.9z"/><path d="M19 15l.9 2.1L22 18l-2.1.9L19 21l-.9-2.1L16 18l2.1-.9z"/>'
};

function ico(name, cls = '') {
  const path = ICON_PATHS[name] || ICON_PATHS.image;
  return `<span class="ico ${cls}"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${path}</svg></span>`;
}

function paintIcons(root = document) {
  $$('[data-icon]', root).forEach((el) => {
    el.innerHTML = ICON_PATHS[el.dataset.icon] ? `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${ICON_PATHS[el.dataset.icon]}</svg>` : '';
    el.classList.add('ico');
  });
}

/* ---------------- utils ---------------- */
function esc(value) {
  return String(value == null ? '' : value)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

function fmtBytes(bytes) {
  const n = Number(bytes) || 0;
  if (n < 1024) return `${n} B`;
  const units = ['KB', 'MB', 'GB', 'TB'];
  let value = n / 1024;
  let i = 0;
  while (value >= 1024 && i < units.length - 1) { value /= 1024; i += 1; }
  return `${value >= 100 ? value.toFixed(0) : value >= 10 ? value.toFixed(1) : value.toFixed(2)} ${units[i]}`;
}

const WEEK = ['星期日', '星期一', '星期二', '星期三', '星期四', '星期五', '星期六'];
const pad2 = (n) => String(n).padStart(2, '0');

function dateParts(ms) {
  const d = new Date(Number(ms) || Date.now());
  return { y: d.getFullYear(), m: d.getMonth() + 1, d: d.getDate(), h: pad2(d.getHours()), mi: pad2(d.getMinutes()), w: d.getDay() };
}

function dayKey(ms) {
  const p = dateParts(ms);
  return `${p.y}-${p.m}-${p.d}`;
}

function dayTitle(ms) {
  const p = dateParts(ms);
  const now = new Date();
  const today = `${now.getFullYear()}-${now.getMonth() + 1}-${now.getDate()}`;
  const yesterdayDate = new Date(now.getFullYear(), now.getMonth(), now.getDate() - 1);
  const yesterday = `${yesterdayDate.getFullYear()}-${yesterdayDate.getMonth() + 1}-${yesterdayDate.getDate()}`;
  const key = `${p.y}-${p.m}-${p.d}`;
  if (key === today) return '今天';
  if (key === yesterday) return '昨天';
  if (p.y === now.getFullYear()) return `${p.m}月${p.d}日`;
  return `${p.y}年${p.m}月${p.d}日`;
}

function daySub(ms) {
  return WEEK[dateParts(ms).w];
}

function fmtDate(ms) {
  const p = dateParts(ms);
  return `${p.y}年${p.m}月${p.d}日 ${p.h}:${p.mi}`;
}

function fmtShort(ms) {
  const p = dateParts(ms);
  const now = new Date();
  if (p.y === now.getFullYear()) return `${p.m}月${p.d}日 ${p.h}:${p.mi}`;
  return `${p.y}年${p.m}月${p.d}日`;
}

function tokenQuery() {
  return state.token ? `t=${encodeURIComponent(state.token)}` : '';
}

function withToken(url) {
  if (!url) return '';
  if (/^(data|blob):/i.test(url)) return url;
  if (/^https?:\/\//i.test(url)) {
    try {
      const u = new URL(url);
      if (state.token && (u.hostname === location.hostname)) u.searchParams.set('t', state.token);
      return u.toString();
    } catch { return url; }
  }
  const join = url.includes('?') ? '&' : '?';
  return state.token ? `${url}${join}t=${encodeURIComponent(state.token)}` : url;
}

const VIDEO_RE = /\.(mp4|m4v|mov|webm|mkv|avi|wmv|flv|3gp|3g2|mpeg|mpg|ts|mts|m2ts|ogv)$/i;
function isVideoItem(item) {
  return Boolean(item && (item.mediaType === 'video' || VIDEO_RE.test(item.name || '') || VIDEO_RE.test(item.ext || '')));
}

function localThumb(id, size = 420) {
  return withToken(`/api/thumb?id=${encodeURIComponent(id)}&size=${size}`);
}

function localImage(id, original = false) {
  return withToken(`/api/image?id=${encodeURIComponent(id)}${original ? '&original=1' : ''}`);
}

function absoluteUrl(url) {
  try { return new URL(url, location.href).href; } catch (error) { return url; }
}

function remoteThumb(device, id, size = 420) {
  return `${device.base}/api/thumb?id=${encodeURIComponent(id)}&size=${size}&t=${encodeURIComponent(device.token || '')}`;
}

function remoteImage(device, id) {
  return `${device.base}/api/image?id=${encodeURIComponent(id)}&t=${encodeURIComponent(device.token || '')}`;
}

function cloudThumb(cloud, item, size = 420) {
  return withToken(`/api/clouds/${encodeURIComponent(cloud.id)}/thumb?kind=file&value=${encodeURIComponent(item.id)}&v=${encodeURIComponent(item.t || item.etag || '')}&size=${size}`);
}

function cloudRaw(cloud, item) {
  return withToken(`/api/clouds/${encodeURIComponent(cloud.id)}/raw?kind=file&value=${encodeURIComponent(item.id)}`);
}

function deviceLabel() {
  return isMobile() ? '手机' : '电脑';
}

function debounce(fn, wait) {
  let timer = null;
  return (...args) => {
    clearTimeout(timer);
    timer = setTimeout(() => fn(...args), wait);
  };
}

function parseRemoteUrl(input) {
  let value = String(input || '').trim();
  if (!value) throw new Error('请输入对方电脑上显示的网址');
  if (!/^https?:\/\//i.test(value)) value = `http://${value}`;
  const u = new URL(value);
  const token = u.searchParams.get('t') || u.searchParams.get('token') || '';
  const base = `${u.origin}${u.pathname.replace(/\/+$/, '')}`.replace(/\/+$/, '');
  return { base, token, url: value };
}

function loadRemotes() {
  try {
    const list = JSON.parse(localStorage.getItem(LS.remotes) || '[]');
    return Array.isArray(list) ? list : [];
  } catch { return []; }
}

function saveRemotes() {
  localStorage.setItem(LS.remotes, JSON.stringify(state.remotes));
}

/* ---------------- API ---------------- */
async function api(path, options = {}) {
  const url = new URL(path, location.origin);
  if (state.token) url.searchParams.set('t', state.token);
  const init = { method: options.method || 'GET', headers: {} };
  if (options.body !== undefined) {
    init.headers['Content-Type'] = 'application/json';
    init.body = JSON.stringify(options.body);
  }
  let response;
  for (let attempt = 0; ; attempt += 1) {
    try {
      response = await fetch(url.toString(), init);
      break;
    } catch (error) {
      if (attempt === 0 && init.method === 'GET') {
        await new Promise((resolve) => setTimeout(resolve, 450));
        continue;
      }
      throw new Error('无法连接 xphoto 服务，请确认电脑上的程序仍在运行');
    }
  }
  let data = null;
  try { data = await response.json(); } catch {}
  if (response.status === 401 || (data && data.needPasswordSetup)) {
    showGate((data && data.error) || '访问口令不正确', Boolean(data && data.needPassword));
    throw new Error((data && data.error) || '访问口令不正确');
  }
  if (!response.ok || (data && data.ok === false)) {
    throw new Error((data && data.error) || `请求失败 (${response.status})`);
  }
  return data || {};
}

async function remoteApi(device, path) {
  const url = new URL(path, device.base);
  if (device.token) url.searchParams.set('t', device.token);
  let response;
  try {
    response = await fetch(url.toString());
  } catch {
    throw new Error('连不上这台电脑，请检查它是否在线、网址是否正确');
  }
  let data = null;
  try { data = await response.json(); } catch {}
  if (!response.ok || (data && data.ok === false)) {
    throw new Error((data && data.error) || `对方电脑返回错误 (${response.status})`);
  }
  return data || {};
}

/* ---------------- toast ---------------- */
function toast(message, type = '') {
  const root = $('#toastRoot');
  if (!root) return;
  const el = document.createElement('div');
  el.className = `toast ${type}`;
  el.innerHTML = `${ico(type === 'err' ? 'info' : type === 'ok' ? 'check-circle' : 'sparkles')}<span>${esc(message)}</span>`;
  root.appendChild(el);
  setTimeout(() => {
    el.classList.add('out');
    setTimeout(() => el.remove(), 260);
  }, 3200);
}

/* ---------------- clipboard ---------------- */
async function copyText(text) {
  try {
    await navigator.clipboard.writeText(text);
    return true;
  } catch {
    try {
      const area = document.createElement('textarea');
      area.value = text;
      area.style.position = 'fixed';
      area.style.opacity = '0';
      document.body.appendChild(area);
      area.select();
      const ok = document.execCommand('copy');
      area.remove();
      return ok;
    } catch { return false; }
  }
}

/* ---------------- theme ---------------- */
function mediaDark() {
  return window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
}

function applyTheme() {
  const actual = state.theme === 'auto' ? (mediaDark() ? 'dark' : 'light') : state.theme;
  document.documentElement.dataset.theme = actual;
  const meta = $('meta[name="theme-color"]');
  if (meta) meta.setAttribute('content', actual === 'dark' ? '#0b1020' : '#f6f8fd');
  if (window.xphoto && window.xphoto.setTheme) {
    window.xphoto.setTheme(state.theme === 'auto' ? 'system' : state.theme).catch(() => {});
  }
  const btn = $('#themeBtn');
  if (btn) btn.innerHTML = ico(actual === 'dark' ? 'sun' : 'moon');
}

function cycleTheme() {
  state.theme = state.theme === 'light' ? 'dark' : state.theme === 'dark' ? 'auto' : 'light';
  localStorage.setItem(LS.theme, state.theme);
  applyTheme();
  toast(state.theme === 'light' ? '浅色模式' : state.theme === 'dark' ? '深色模式' : '跟随系统');
  api('/api/settings', { method: 'PATCH', body: { theme: state.theme } }).then(() => {
    if (state.boot) state.boot.settings.theme = state.theme;
    if (state.route.name === 'mine') renderContent();
  }).catch(() => {});
}

function setTheme(value) {
  state.theme = value;
  localStorage.setItem(LS.theme, value);
  applyTheme();
  api('/api/settings', { method: 'PATCH', body: { theme: value } }).then(() => {
    if (state.boot) state.boot.settings.theme = value;
    renderContent();
  }).catch((error) => toast(error.message, 'err'));
}

window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', () => {
  if (state.theme === 'auto') { applyTheme(); if (state.viewer) renderViewer(); }
});

/* ---------------- boot ---------------- */
async function boot() {
  state.loadingBoot = true;
  state.bootError = '';
  renderContent();
  try {
    const data = await api('/api/state');
    state.boot = data;
    state.clouds = data.clouds || [];
    state.downloads = data.downloads || [];
    state.gridSize = Number(data.settings.gridSize) || 5;
    state.sort = data.settings.sort === 'name' ? 'name' : data.settings.sort === 'asc' ? 'asc' : 'desc';
    if (!localStorage.getItem(LS.theme) && data.settings.theme) state.theme = data.settings.theme;
    state.remotes = loadRemotes();
    applyTheme();
    document.documentElement.style.setProperty('--grid-cols', String(state.gridSize));
    state.mobileGrid = Math.min(8, Math.max(2, Number(localStorage.getItem(LS.mobileGrid)) || 3));
    document.documentElement.style.setProperty('--mobile-cols', String(state.mobileGrid));
    if (ANDROID) { loadAndroidFolders(); refreshAndroidRecycleCount(); }
    state.loadingBoot = false;
    await navigate('photos', {}, { replace: true, noLoad: false });
    registerServiceWorker();
  } catch (error) {
    state.loadingBoot = false;
    state.bootError = error.message;
    renderContent();
  }
}

async function refreshBoot(silent = true) {
  try {
    const data = await api('/api/state');
    state.boot = data;
    state.clouds = data.clouds || [];
    state.downloads = data.downloads || state.downloads;
    if (data.settings) {
      state.gridSize = Number(data.settings.gridSize) || state.gridSize;
      state.sort = data.settings.sort || state.sort;
    }
    renderShell();
    return data;
  } catch (error) {
    if (!silent) toast(error.message, 'err');
    return null;
  }
}

/* ---------------- navigation ---------------- */
function titleForRoute() {
  const r = state.route;
  if (r.q) return `搜索“${r.q}”`;
  if (r.name === 'favorites') return '收藏';
  if (r.name === 'recent') return '最近';
  if (r.name === 'local') return '手机相册';
  if (r.name === 'localFolder') return localFolderName(r.folderId);
  if (r.name === 'localTrash') return '手机回收站';
  if (r.name === 'albums') return '相册';
  if (r.name === 'album') return r.album ? r.album.name : '相册';
  if (r.name === 'root') {
    const root = rootById(r.rootId);
    return root ? root.name : '文件夹';
  }
  if (r.name === 'cloud') return '云盘';
  if (r.name === 'cloudBrowse') return state.cloudAccount ? state.cloudAccount.name : '云盘';
  if (r.name === 'devices') return '设备';
  if (r.name === 'remote') return r.remote ? r.remote.name : '其他电脑';
  if (r.name === 'remoteAlbum') return r.remoteAlbum ? r.remoteAlbum.name : '其他电脑';
  if (r.name === 'downloads') return '下载记录';
  if (r.name === 'trash') return ANDROID ? '电脑回收站' : '回收站';
  if (r.name === 'mine') return isMobile() ? '我的' : '设置';
  return '照片';
}

function subtitleForRoute() {
  const r = state.route;
  if (!state.boot) return '';
  if (r.q) return `找到 ${state.photoTotal} 个结果`;
  if (r.name === 'favorites') return `${state.boot.favoritesCount || 0} 张喜欢的照片`;
  if (r.name === 'recent') return `最近 30 天 · ${state.boot.recentCount || 0} 张`;
  if (r.name === 'local' || r.name === 'localFolder') {
    const total = state.localFolders.reduce((sum, folder) => sum + (Number(folder.count) || 0), 0);
    return `${total} 张手机照片 · 不上传`;
  }
  if (r.name === 'localTrash') return `${state.localRecycleCount} 个文件 · 清空后才会真正删除`;
  if (r.name === 'albums') return `${state.boot.albums.length + (ANDROID ? state.localFolders.length : 0)} 个相册 · 按文件夹自动整理`;
  if (r.name === 'album' && r.album) return `${r.album.count} 张 · ${r.album.rel || '根目录'}`;
  if (r.name === 'root') {
    const root = rootById(r.rootId);
    return root ? `${root.count} 张 · ${root.path}` : '';
  }
  if (r.name === 'cloud') return `${state.clouds.length} 个已连接云盘`;
  if (r.name === 'cloudBrowse' && state.cloudData) return `${state.cloudData.folders.length} 个文件夹 · ${state.cloudData.files.length} 张图片`;
  if (r.name === 'devices') return state.boot.share.enabled ? '局域网访问已开启' : '局域网访问已关闭';
  if (r.name === 'remote' && state.remoteState) return `${state.remoteState.totalPhotos} 张照片 · 来自局域网`;
  if (r.name === 'remoteAlbum' && state.remoteAlbum) return `${state.remoteAlbum.count} 张`;
  if (r.name === 'downloads') return `${state.downloads.length} 条下载记录`;
  if (r.name === 'trash') return `${state.trashItems.length} 个文件 · 清空后才会真正删除`;
  if (r.name === 'mine') return '外观、连接与存储';
  return `${state.boot.totalPhotos} 张照片 · ${fmtBytes(state.boot.totalBytes)}`;
}

function navigate(name, patch = {}, options = {}) {
  if (!options.replace) {
    state.history.push({ ...state.route });
    if (state.history.length > 30) state.history.shift();
  }
  state.route = { name, rootId: '', album: null, q: '', remote: null, remoteAlbum: null, ...patch };
  state.selecting = false;
  state.selected.clear();
  closeViewer();
  renderShell();
  renderContent({ keepScroll: false });
  if (!options.noLoad) loadRoute();
}

function canBackRoute(name = state.route.name) {
  return !['photos', 'devices', 'downloads', 'mine'].includes(name);
}

function pageBack() {
  if (!canBackRoute()) return '';
  return `<button class="icon-btn page-back" data-action="back" aria-label="返回" title="返回">${ico('arrow-left')}</button>`;
}

function back() {
  const previous = state.history.pop();
  if (previous) {
    state.route = previous;
    state.selecting = false;
    state.selected.clear();
    renderShell();
    renderContent({ keepScroll: false });
    loadRoute();
  } else {
    navigate('photos', {}, { replace: true });
  }
}

function rootById(id) {
  return (state.boot && state.boot.roots || []).find((root) => root.id === id);
}

function activeNav() {
  const r = state.route;
  if (r.q) return '';
  if (r.name === 'root') return '';
  if (r.name === 'album') return 'albums';
  if (r.name === 'local' || r.name === 'localFolder' || r.name === 'localTrash') return 'local';
  if (r.name === 'cloudBrowse') return 'cloud';
  if (r.name === 'remote' || r.name === 'remoteAlbum') return 'devices';
  return r.name;
}

function loadRoute() {
  const r = state.route;
  if (['photos', 'favorites', 'recent', 'album', 'root'].includes(r.name)) {
    state.photos = [];
    state.photoTotal = 0;
    state.photoHasMore = false;
    state.photoError = '';
    loadPhotos(false);
  } else if (r.name === 'local' || r.name === 'localFolder') {
    loadAndroidPhotos(r.name === 'localFolder' ? (r.folderId || 'all') : 'all');
  } else if (r.name === 'localTrash') {
    loadAndroidRecycle();
  } else if (r.name === 'cloud') {
    loadClouds();
  } else if (r.name === 'cloudBrowse') {
    loadCloud();
  } else if (r.name === 'downloads') {
    loadDownloads();
  } else if (r.name === 'trash') {
    loadTrash();
  } else if (r.name === 'mine') {
    loadCacheInfo();
  } else if (r.name === 'remote') {
    loadRemote(r.remote);
  } else if (r.name === 'remoteAlbum') {
    loadRemoteAlbum();
  }
}

/* ---------------- photos ---------------- */
function photosQuery(offset) {
  const r = state.route;
  const query = new URLSearchParams();
  query.set('offset', String(offset || 0));
  query.set('limit', '150');
  query.set('sort', state.sort === 'name' ? 'name' : state.sort === 'asc' ? 'asc' : 'desc');
  if (r.name === 'favorites') query.set('favorites', '1');
  if (r.name === 'recent') query.set('recent', '1');
  if (r.name === 'album' && r.album) query.set('albumId', r.album.id);
  if (r.rootId) query.set('rootId', r.rootId);
  if (r.q) query.set('q', r.q);
  return query;
}

async function loadPhotos(append = false) {
  if (state.photoLoading) return;
  state.photoLoading = true;
  if (!append) { state.photoError = ''; state.photos = []; }
  renderContent();
  try {
    const data = await api(`/api/photos?${photosQuery(append ? state.photos.length : 0).toString()}`);
    state.photos = append ? state.photos.concat(data.items || []) : (data.items || []);
    state.photoTotal = data.total || 0;
    state.photoHasMore = Boolean(data.hasMore);
    state.photoError = '';
  } catch (error) {
    state.photoError = error.message;
    if (append) toast(error.message, 'err');
  } finally {
    state.photoLoading = false;
    renderContent();
  }
}

function groupPhotos(items) {
  if (state.sort === 'name') return [{ key: 'all', title: '全部照片', sub: '', items }];
  const groups = [];
  const map = new Map();
  for (const item of items) {
    const key = dayKey(item.mtimeMs || item.t);
    let group = map.get(key);
    if (!group) {
      group = { key, title: dayTitle(item.mtimeMs || item.t), sub: daySub(item.mtimeMs || item.t), items: [] };
      map.set(key, group);
      groups.push(group);
    }
    group.items.push(item);
  }
  return groups;
}

/* ---------------- phone-local gallery (Android WebView) ---------------- */
function androidMedia(uri, width = 420) {
  if (/^(data:|https?:)/i.test(uri || '')) return uri;
  return `https://xphoto.local/media?u=${encodeURIComponent(uri || '')}&w=${width}`;
}

function androidFolders() {
  if (!ANDROID || !window.XPhotoAndroid || typeof window.XPhotoAndroid.localFolders !== 'function') return [];
  try {
    const value = JSON.parse(window.XPhotoAndroid.localFolders() || '[]');
    return Array.isArray(value) ? value.filter((item) => item && item.id) : [];
  } catch (error) { return []; }
}

function loadAndroidFolders() {
  if (!ANDROID) return;
  state.localFolders = androidFolders();
  const valid = new Set(state.localFolders.map((folder) => folder.id));
  state.localPinned = state.localPinned.filter((id) => valid.has(id));
  try { localStorage.setItem(LS.localPinned, JSON.stringify(state.localPinned)); } catch (error) {}
}

function androidPhoto(item, folderName) {
  return {
    id: item.uri || item.id,
    uri: item.uri || item.id,
    name: item.name || '照片',
    size: Number(item.size) || 0,
    mtimeMs: (Number(item.date) || 0) * 1000,
    album: item.folder || folderName || '手机相册',
    location: item.location || '',
    _thumb: androidMedia(item.uri || item.id, 420)
  };
}

function loadAndroidPhotos(folderId = 'all') {
  if (!ANDROID || !window.XPhotoAndroid || typeof window.XPhotoAndroid.localPhotos !== 'function') return;
  state.localFolderId = folderId || 'all';
  state.localLoading = true;
  state.localError = '';
  state.localPhotos = [];
  renderContent();
  try {
    const folder = state.localFolders.find((item) => item.id === state.localFolderId);
    const list = JSON.parse(window.XPhotoAndroid.localPhotos(state.localFolderId) || '[]');
    state.localPhotos = (Array.isArray(list) ? list : []).map((item) => androidPhoto(item, folder && folder.name));
  } catch (error) {
    state.localError = error.message || '读取手机相册失败';
  } finally {
    state.localLoading = false;
    renderContent();
  }
}

function refreshAndroidRecycleCount() {
  if (!ANDROID || !window.XPhotoAndroid || typeof window.XPhotoAndroid.localRecycle !== 'function') {
    state.localRecycleCount = 0;
    return;
  }
  try {
    const list = JSON.parse(window.XPhotoAndroid.localRecycle() || '[]');
    state.localRecycleCount = Array.isArray(list) ? list.length : 0;
  } catch (error) { state.localRecycleCount = 0; }
}

function loadAndroidRecycle() {
  if (!ANDROID || !window.XPhotoAndroid || typeof window.XPhotoAndroid.localRecycle !== 'function') {
    state.localPhotos = [];
    state.localRecycleCount = 0;
    return;
  }
  state.localLoading = true;
  state.localError = '';
  renderContent();
  try {
    const list = JSON.parse(window.XPhotoAndroid.localRecycle() || '[]');
    const items = Array.isArray(list) ? list : [];
    state.localRecycleCount = items.length;
    state.localPhotos = items.map((item) => androidPhoto(item, '手机回收站'));
  } catch (error) {
    state.localError = error.message || '读取手机回收站失败';
  } finally {
    state.localLoading = false;
    renderContent();
  }
}

function localFolderName(folderId) {
  if (!folderId || folderId === 'all') return '手机相册';
  const folder = state.localFolders.find((item) => item.id === folderId);
  return folder ? folder.name : '手机相册';
}

function renderLocalPage() {
  const r = state.route;
  const isTrash = r.name === 'localTrash';
  const folderId = r.name === 'localFolder' ? (r.folderId || 'all') : 'all';
  const title = isTrash ? '手机回收站' : folderId === 'all' ? '手机相册' : localFolderName(folderId);
  const total = isTrash
    ? state.localRecycleCount
    : state.localFolders.reduce((sum, folder) => sum + (Number(folder.count) || 0), 0);
  let body = '';
  if (state.localLoading) body = skeletonGrid(18);
  else if (state.localError) body = emptyState('info', isTrash ? '手机回收站读取失败' : '手机相册读取失败', esc(state.localError), `<button class="btn primary" data-action="${isTrash ? 'android-local-trash' : 'android-local'}" data-id="${esc(folderId)}">重试</button>`);
  else if (!state.localPhotos.length) {
    body = isTrash
      ? emptyState('trash', '手机回收站是空的', '在手机相册里长按照片或视频，选择「移到回收站」，删除的文件会先放在这里。')
      : emptyState('photos', '这个手机相册还没有照片', '手机拍的照片会自动出现在这里。也可以在「添加手机文件夹」里选择其他相册。', `<button class="btn primary" data-action="android-add-folder">${ico('plus')} 添加手机文件夹</button>`);
  } else body = renderPhotoGrid(state.localPhotos, 'android');
  const actions = isTrash
    ? `<button class="btn ghost sm" data-action="android-local-trash">${ico('refresh')} 刷新</button><button class="btn danger sm" data-action="empty-local-trash" ${state.localRecycleCount ? '' : 'disabled'}>${ico('trash')} 清空回收站</button>`
    : `<button class="btn soft sm" data-action="android-add-folder">${ico('plus')} 添加手机文件夹</button><button class="btn ghost sm" data-action="android-local" data-id="${esc(folderId)}">${ico('refresh')} 刷新</button>`;
  return `<div class="content-inner photos-page">
    <div class="page-head"><div><h1>${pageBack()}${esc(title)}</h1><div class="page-sub">${isTrash ? `${total} 个文件 · 清空后才会真正删除` : folderId === 'all' ? `${total} 张照片 · 来自这台手机` : `${state.localPhotos.length} 张 · 只在这台手机上查看`}</div></div>
      <div class="head-actions">${actions}</div>
    </div>
    <div class="local-mobile-tools">${actions}</div>
    ${body}
  </div>`;
}

function photoTile(item, context = 'local') {
  const selected = state.selected.has(item.id);
  const video = isVideoItem(item);
  const thumb = context === 'local' ? localThumb(item.id, 420) : item._thumb || '';
  let media = `<img src="${esc(thumb)}" alt="${esc(item.name)}" loading="lazy" decoding="async">`;
  if (video) {
    // Never mount <video> in the grid: Android WebView often refuses to paint a
    // poster for H.265/HEVC and would show a generic play icon. Use the server /
    // native poster image instead; playback stays in the viewer.
    media = `<img src="${esc(thumb)}" alt="${esc(item.name)}" loading="lazy" decoding="async"><span class="video-badge">${ico('play')}</span>`;
  }
  const cls = `photo-tile${selected ? ' selected' : ''}${video ? ' video-tile' : ''}`;
  if (context === 'android') {
    return `<div class="${cls}" role="button" tabindex="0" data-action="local-photo" data-id="${esc(item.id)}" aria-label="${esc(item.name)}">
      ${media}
      <button class="tile-check" data-action="local-photo" data-id="${esc(item.id)}" aria-label="选择">${ico('check')}</button>
      <div class="tile-meta">${esc(item.name)}</div>
    </div>`;
  }
  return `<div class="${cls}" role="button" tabindex="0" data-action="photo" data-id="${esc(item.id)}" aria-label="${esc(item.name)}">
    ${media}
    <button class="tile-check" data-action="photo" data-id="${esc(item.id)}" aria-label="选择">${ico('check')}</button>
    ${context === 'local' ? `<button class="tile-fav ${item.fav ? 'fav' : ''}" data-action="fav-tile" data-id="${esc(item.id)}" aria-label="收藏">${ico(item.fav ? 'heart-fill' : 'heart')}</button>` : ''}
    <div class="tile-meta">${esc(item.name)}</div>
  </div>`;
}

function renderPhotoGrid(items, context = 'local') {
  if (!items.length) return '';
  const groups = groupPhotos(items);
  return `<div class="photo-groups">${groups.map((group, index) => `<section class="photo-group" data-group="${index}">
    <div class="date-head"><h2>${esc(group.title)}</h2>${group.sub ? `<span>${esc(group.sub)}</span>` : ''}<span>${group.items.length} 张</span>${['photos','favorites','recent','album','root','local','localFolder'].includes(state.route.name) ? `<button class="date-select-all" data-action="select-date" data-group="${index}" title="选择这一天的全部照片">全选</button>` : ''}</div>
    <div class="photo-grid">${group.items.map((item) => photoTile(item, context)).join('')}</div>
  </section>`).join('')}</div>`;
}

function setupTimeScroller() {
  if (state.timeAbort) {
    state.timeAbort.abort();
    state.timeAbort = null;
  }
  const host = document.querySelector('#content .photos-page');
  if (!host) return;
  const groups = Array.from(host.querySelectorAll('.photo-group'));
  if (groups.length < 3) return;

  const bar = document.createElement('div');
  bar.className = 'time-scroller';
  bar.setAttribute('aria-label', '时间快速定位');
  bar.innerHTML = '<span class="ts-track"></span><span class="ts-thumb"></span><span class="ts-label"></span>';
  host.appendChild(bar);

  const content = $('#content');
  const docScroller = document.scrollingElement || document.documentElement;
  const thumb = bar.querySelector('.ts-thumb');
  const label = bar.querySelector('.ts-label');
  const controller = new AbortController();
  const mobileScroll = () => window.matchMedia('(max-width: 900px)').matches;
  const currentTop = () => (mobileScroll() ? window.scrollY : content.scrollTop);
  state.timeAbort = controller;
  let dragging = false;
  let hideTimer = 0;

  const groupLabel = (group) => {
    const title = group.querySelector('.date-head h2')?.textContent || '';
    const parts = Array.from(group.querySelectorAll('.date-head span')).map((el) => el.textContent).filter(Boolean);
    return [title, ...parts].join(' · ');
  };
  const maxScroll = () => Math.max(1, mobileScroll()
    ? docScroller.scrollHeight - window.innerHeight
    : content.scrollHeight - content.clientHeight);
  const updateThumb = () => {
    const usable = Math.max(1, bar.clientHeight - thumb.offsetHeight);
    const fraction = Math.max(0, Math.min(1, currentTop() / maxScroll()));
    thumb.style.transform = `translateY(${Math.round(fraction * usable)}px)`;
  };
  const showLabel = (group, clientY) => {
    clearTimeout(hideTimer);
    const rect = bar.getBoundingClientRect();
    label.textContent = groupLabel(group);
    label.style.top = `${Math.max(16, Math.min(rect.height - 16, clientY - rect.top))}px`;
    bar.classList.add('show-label');
  };
  const hideLabel = (delay = 0) => {
    clearTimeout(hideTimer);
    hideTimer = setTimeout(() => bar.classList.remove('show-label'), delay);
  };
  const jump = (clientY) => {
    const rect = bar.getBoundingClientRect();
    const fraction = Math.max(0, Math.min(1, (clientY - rect.top) / Math.max(1, rect.height)));
    const index = Math.min(groups.length - 1, Math.max(0, Math.round(fraction * (groups.length - 1))));
    if (mobileScroll()) {
      const y = groups[index].getBoundingClientRect().top + window.scrollY - 52;
      window.scrollTo({ top: Math.max(0, y), behavior: 'auto' });
    } else {
      content.scrollTo({ top: Math.max(0, groups[index].offsetTop - 6), behavior: 'auto' });
    }
    showLabel(groups[index], clientY);
    updateThumb();
  };

  bar.addEventListener('pointerdown', (event) => {
    dragging = true;
    try { bar.setPointerCapture(event.pointerId); } catch {}
    jump(event.clientY);
    event.preventDefault();
  }, { signal: controller.signal });
  bar.addEventListener('pointermove', (event) => {
    if (!dragging) return;
    jump(event.clientY);
    event.preventDefault();
  }, { signal: controller.signal });
  const endDrag = () => {
    if (!dragging) return;
    dragging = false;
    hideLabel(650);
  };
  bar.addEventListener('pointerup', endDrag, { signal: controller.signal });
  bar.addEventListener('pointercancel', endDrag, { signal: controller.signal });
  content.addEventListener('scroll', updateThumb, { passive: true, signal: controller.signal });
  window.addEventListener('scroll', updateThumb, { passive: true, signal: controller.signal });
  requestAnimationFrame(updateThumb);
}

function skeletonGrid(count = 15) {
  return `<div class="skeleton-grid">${Array.from({ length: count }, () => '<div class="skel"></div>').join('')}</div>`;
}

function emptyState(icon, title, text, actions = '') {
  return `<div class="empty">
    <div class="empty-art">${ico(icon)}</div>
    <h2>${esc(title)}</h2>
    <p>${text}</p>
    ${actions ? `<div class="empty-actions">${actions}</div>` : ''}
  </div>`;
}

function renderPhotosPage() {
  const r = state.route;
  const title = titleForRoute();
  const subtitle = subtitleForRoute();
  let actions = '';
  if (state.boot) {
    actions = `<div class="head-actions">
      <button class="btn ghost sm" data-action="cycle-grid" title="切换网格密度（Ctrl + 滚轮缩放）">${ico('grid')} <span class="grid-count">${state.gridSize} 列</span></button>
      <div class="seg" role="group" aria-label="排序">
        <button class="${state.sort === 'desc' ? 'active' : ''}" data-action="sort" data-sort="desc">最新</button>
        <button class="${state.sort === 'name' ? 'active' : ''}" data-action="sort" data-sort="name">名称</button>
        <button class="${state.sort === 'asc' ? 'active' : ''}" data-action="sort" data-sort="asc">最早</button>
      </div>
      ${r.name !== 'favorites' ? `<button class="btn primary" data-action="select-mode">${ico('check-circle')} 选择</button>` : `<button class="btn soft" data-action="select-mode">${ico('check-circle')} 选择</button>`}
    </div>`;
  }

  let body = '';
  if (state.photoLoading && !state.photos.length) {
    body = skeletonGrid(18);
  } else if (state.photoError) {
    body = emptyState('info', '照片加载失败', esc(state.photoError), `<button class="btn primary" data-action="retry-photos">重试</button>`);
  } else if (!state.photos.length) {
    if (r.q) {
      body = emptyState('search', '没有找到匹配的照片', `换个关键词试试，或者检查是否选错了文件夹。`, `<button class="btn soft" data-action="clear-search">清除搜索</button>`);
    } else if (r.name === 'favorites') {
      body = emptyState('heart', '还没有收藏', '在照片上点一下心形按钮，喜欢的照片会出现在这里。', `<button class="btn primary" data-action="nav" data-nav="photos">去看照片</button>`);
    } else if (r.name === 'recent') {
      body = emptyState('clock', '最近 30 天没有新照片', '导入新照片后，这里会自动出现最近的内容。', `<button class="btn soft" data-action="nav" data-nav="photos">查看全部</button>`);
    } else if (r.name === 'album' || r.name === 'root') {
      body = emptyState('folder-open', '这个文件夹是空的', '把图片放进这个文件夹，再点一下刷新即可。', `<button class="btn soft" data-action="nav" data-nav="photos">返回照片</button>`);
    } else {
      body = emptyState('photos', '还没有照片', '添加一个存放照片的文件夹，xphoto 会自动扫描并按文件夹整理。手机也能通过局域网查看。', `<button class="btn primary" data-action="add-folder">${ico('plus')} 添加文件夹</button><button class="btn soft" data-action="open-share">${ico('smartphone')} 手机连接</button>`);
    }
  } else {
    body = renderPhotoGrid(state.photos, 'local');
    if (state.photoLoading) body += `<div class="load-more"><div class="spinner"></div></div>`;
    else if (state.photoHasMore) body += `<div class="load-more"><button class="btn soft" data-action="load-more">加载更多</button></div>`;
  }

  return `<div class="content-inner photos-page">
    <div class="page-head"><div><h1>${pageBack()}${esc(title)}</h1><div class="page-sub">${esc(subtitle)}</div></div>${actions}</div>
    ${body}
  </div>`;
}

/* ---------------- albums ---------------- */
function albumCard(album) {
  const cover = album.cover ? withToken(album.cover) : '';
  return `<div class="album-card" role="button" tabindex="0" data-action="open-album" data-id="${esc(album.id)}">
    ${cover ? `<img src="${esc(cover)}" alt="" loading="lazy" decoding="async">` : `<div class="album-empty-cover">${ico('folder')}</div>`}
    <div class="album-overlay"></div>
    <div class="album-info">
      <div class="album-name">${esc(album.name)}</div>
      <div class="album-meta">${album.count} 张</div>
    </div>
  </div>`;
}

function albumGroup(key, name, cards, count, hint = '') {
  const collapsed = state.albumCollapsed.includes(key);
  return `<section class="album-group" data-group="${esc(key)}">
    <button class="album-group-head" data-action="toggle-album-group" data-key="${esc(key)}" aria-expanded="${collapsed ? 'false' : 'true'}">
      <span class="ag-caret ${collapsed ? 'collapsed' : ''}">${ico('chevron-down')}</span>
      <span class="ag-folder">${ico('folder')}</span>
      <span class="ag-text">
        <span class="ag-title">${esc(name)}</span>
        <span class="ag-sub">${count} 个相册${hint ? ` · ${esc(hint)}` : ''}</span>
      </span>
    </button>
    <div class="album-group-body" ${collapsed ? 'hidden' : ''}>
      <div class="albums-grid">${cards}</div>
    </div>
  </section>`;
}

function renderAlbumsPage() {
  const albums = state.boot ? state.boot.albums : [];
  const roots = (state.boot && state.boot.roots) || [];
  const order = new Map(roots.map((root, index) => [root.id, index]));
  const groups = new Map();
  for (const album of albums) {
    const key = album.rootId || 'root';
    if (!groups.has(key)) groups.set(key, { name: album.rootName || '相册文件夹', albums: [] });
    groups.get(key).albums.push(album);
  }
  const rootGroups = Array.from(groups.entries())
    .sort((a, b) => (order.get(a[0]) ?? 999) - (order.get(b[0]) ?? 999))
    .map(([key, group]) => albumGroup(key, group.name, group.albums.map(albumCard).join(''), group.albums.length))
    .join('');

  const canAdd = state.boot && state.boot.isLocal && !ANDROID;
  const localCards = ANDROID ? state.localFolders.map((folder) => `<div class="album-card" role="button" tabindex="0" data-action="android-local-folder" data-id="${esc(folder.id)}" data-name="${esc(folder.name)}">
      ${folder.cover ? `<img src="${esc(androidMedia(folder.cover, 560))}" alt="" loading="lazy" decoding="async">` : `<div class="album-empty-cover">${ico('folder')}</div>`}
      <div class="album-overlay"></div>
      <div class="album-info">
        <div class="album-name">${esc(folder.name)}</div>
        <div class="album-meta">${folder.count} 张</div>
      </div>
    </div>`).join('') : '';
  const localGroup = ANDROID && localCards
    ? albumGroup('android-local', '手机本机', localCards, state.localFolders.length, '不上传 · 只在这台手机上查看')
    : '';
  const totalAlbums = albums.length + (ANDROID ? state.localFolders.length : 0);
  return `<div class="content-inner">
    <div class="page-head"><div><h1>${pageBack()}相册</h1><div class="page-sub">${totalAlbums} 个相册 · 按导入的文件夹分组</div></div>
      <div class="head-actions">${ANDROID ? `<button class="btn soft" data-action="android-add-folder">${ico('plus')} 添加手机文件夹</button>` : ''}${canAdd ? `<button class="btn soft" data-action="add-folder">${ico('plus')} 添加电脑文件夹</button>` : ''}<button class="btn ghost sm" data-action="refresh">${ico('refresh')} 刷新</button></div>
    </div>
    ${rootGroups}${localGroup}
    ${!albums.length && !localCards ? emptyState('albums', '还没有相册', '每个包含图片的文件夹都会变成一个相册。添加文件夹后自动出现。', canAdd ? `<button class="btn primary" data-action="add-folder">${ico('plus')} 添加文件夹</button>` : '') : ''}
  </div>`;
}

/* ---------------- cloud ---------------- */
function renderCloudPage() {
  const cards = state.clouds.map((cloud) => `<div class="cloud-card">
    <div class="cloud-top">
      <div class="cloud-logo ${cloud.type === 'webdav' ? 'webdav' : ''}">${ico(cloud.type === 'webdav' ? 'disk' : 'cloud')}</div>
      <div style="min-width:0"><div class="cloud-name">${esc(cloud.name)}</div><div class="cloud-type"><span class="status-dot"></span>${cloud.type === '123' ? '123云盘 Open API' : 'WebDAV 云盘'}</div></div>
    </div>
    <div class="cloud-actions">
      <button class="btn primary sm" data-action="open-cloud" data-id="${esc(cloud.id)}">${ico('folder-open')} 浏览图片</button>
      <button class="del" data-action="delete-cloud" data-id="${esc(cloud.id)}" aria-label="移除云盘">${ico('trash')}</button>
    </div>
  </div>`).join('');

  return `<div class="content-inner">
    <div class="page-head"><div><h1>${pageBack()}云盘</h1><div class="page-sub">连接 123云盘、坚果云、Nextcloud、AList 等</div></div>
      <div class="head-actions"><button class="btn primary" data-action="add-cloud">${ico('plus')} 连接云盘</button></div>
    </div>
    ${state.clouds.length ? `<div class="cloud-grid">${cards}</div>` : emptyState('cloud', '把云盘里的照片也放进来', '支持 123云盘开放平台 API，以及通用 WebDAV（坚果云、Nextcloud、AList、群晖等）。连接后可以直接浏览云盘文件夹里的图片。', `<button class="btn primary" data-action="add-cloud">${ico('cloud-plus')} 连接云盘</button>`)}
    <div class="section-note" style="margin-top:22px">${ico('shield')} 云盘密钥只保存在这台电脑上，不会显示在手机页面上。手机通过局域网访问时，由电脑代为连接云盘。</div>
  </div>`;
}

function cloudRootValue(cloud) {
  return cloud && cloud.type === '123' ? '0' : '';
}

function renderCloudBrowsePage() {
  const cloud = state.cloudAccount;
  if (!cloud) return renderCloudPage();
  const path = state.cloudPath;
  const crumbs = path.map((item, index) => `<button class="${index === path.length - 1 ? 'current' : ''}" data-action="cloud-crumb" data-index="${index}">${esc(item.name)}</button>${index < path.length - 1 ? '<span class="sep">/</span>' : ''}`).join('');

  let body = '';
  if (state.cloudError) {
    body = emptyState('info', '云盘读取失败', esc(state.cloudError), `<button class="btn soft" data-action="cloud-refresh">重试</button><button class="btn ghost" data-action="nav" data-nav="cloud">返回云盘</button>`);
  } else if (state.cloudLoading || !state.cloudData) {
    body = skeletonGrid(12);
  } else {
    const folders = (state.cloudData.folders || []).map((folder) => `<button class="folder-tile" data-action="cloud-folder" data-id="${esc(folder.id)}" data-name="${esc(folder.name)}">
      <span class="folder-icon">${ico('folder')}</span>
      <span style="min-width:0"><span class="folder-name">${esc(folder.name)}</span><span class="folder-sub">文件夹</span></span>
    </button>`).join('');
    const files = state.cloudData.files || [];
    body = `${folders ? `<div class="folder-grid">${folders}</div>` : ''}
      ${files.length ? `<div class="photo-grid">${files.map((file) => `<div class="photo-tile" role="button" tabindex="0" data-action="cloud-photo" data-id="${esc(file.id)}"><img src="${esc(cloudThumb(cloud, file, 420))}" alt="${esc(file.name)}" loading="lazy" decoding="async"><div class="tile-meta">${esc(file.name)}</div></div>`).join('')}</div>` : ''}
      ${!folders && !files.length ? emptyState('folder-open', '这个文件夹没有图片', '换个文件夹看看，或把图片放进云盘的这个目录。') : ''}`;
  }

  return `<div class="content-inner">
    <div class="page-head"><div>
      <h1 style="font-size:24px">${pageBack()}${esc(cloud.name)}</h1>
      <div class="breadcrumb" style="margin-top:8px">${crumbs}</div>
    </div><div class="head-actions">
      <button class="btn soft sm" data-action="cloud-refresh">${ico('refresh')} 刷新</button>
      <button class="btn ghost sm" data-action="nav" data-nav="cloud">返回云盘</button>
    </div></div>
    ${body}
  </div>`;
}

/* ---------------- devices ---------------- */
function renderDevicesPage() {
  const boot = state.boot;
  const share = boot ? boot.share : { enabled: false, primaryUrl: '' };
  const localCard = `<div class="device-card this">
    <div class="device-icon">${ico('monitor')}</div>
    <div style="min-width:0"><div class="device-name">${esc(boot ? boot.deviceName : '这台电脑')} <span class="root-sys">本机</span></div>
      <div class="device-sub">${share.enabled ? `局域网已开启 · ${esc(share.primaryUrl || '')}` : '局域网访问已关闭，手机暂时连不上'}</div></div>
    <div class="device-actions">
      <button class="btn soft sm" data-action="open-share">${ico('qr')} 手机连接</button>
      ${share.enabled ? `<button class="btn ghost sm" data-action="copy-share">${ico('copy')} 复制网址</button>` : ''}
    </div>
  </div>`;

  const remotes = state.remotes.map((device) => `<div class="device-card">
    <div class="device-icon">${ico('monitor')}</div>
    <div style="min-width:0"><div class="device-name">${esc(device.name || '其他电脑')} <span class="status-dot" style="margin-left:2px"></span></div>
      <div class="device-sub">${esc(device.base)}</div></div>
    <div class="device-actions">
      <button class="btn primary sm" data-action="open-remote" data-id="${esc(device.id)}">${ico('photos')} 查看</button>
      <button class="btn ghost sm" data-action="remove-remote" data-id="${esc(device.id)}" aria-label="移除">${ico('trash')}</button>
    </div>
  </div>`).join('');

  return `<div class="content-inner">
    <div class="page-head"><div><h1>设备</h1><div class="page-sub">${share.enabled ? '同一 Wi-Fi 下，手机和其他电脑都能看这台电脑的相册' : '开启局域网访问后，手机和其他电脑才能连接'}</div></div>
      <div class="head-actions"><button class="btn primary" data-action="add-remote">${ico('plus')} 添加其他电脑</button></div>
    </div>
    <div class="settings-grid" style="grid-template-columns:1fr">
      <div class="panel">
        <div class="panel-head">${ico('monitor')}<h3>这台电脑</h3></div>
        ${localCard}
      </div>
      <div class="panel">
        <div class="panel-head">${ico('devices')}<h3>其他电脑</h3><span class="subtle" style="font-size:10.5px;margin-left:auto">${state.remotes.length} 台</span></div>
        ${state.remotes.length ? remotes : `<div class="empty" style="margin:8px auto 0;padding:14px"><div class="empty-art" style="width:64px;height:64px;border-radius:20px;margin-bottom:10px">${ico('link')}</div><h2 style="font-size:15px">还没有添加其他电脑</h2><p style="font-size:11.5px">在对方电脑上打开「手机连接」，复制带口令的网址，然后点右上角添加。</p><button class="btn soft sm" style="margin-top:12px" data-action="add-remote">${ico('plus')} 添加网址</button></div>`}
      </div>
    </div>
  </div>`;
}

function remoteAlbumCards() {
  const device = state.route.remote;
  const albums = state.remoteState ? state.remoteState.albums || [] : [];
  if (!albums.length) return emptyState('albums', '对方还没有相册', '对方电脑添加照片文件夹后，这里就会出现。');
  return `<div class="albums-grid" style="padding:0">${albums.map((album) => {
    const cover = album.cover ? `${device.base}${album.cover}${album.cover.includes('?') ? '&' : '?'}t=${encodeURIComponent(device.token || '')}` : '';
    return `<div class="album-card" role="button" tabindex="0" data-action="remote-album" data-id="${esc(album.id)}">
      ${cover ? `<img src="${esc(cover)}" alt="" loading="lazy">` : `<div class="album-empty-cover">${ico('folder')}</div>`}
      <div class="album-overlay"></div><div class="album-info"><div class="album-name">${esc(album.name)}</div><div class="album-meta">${album.count} 张</div></div>
    </div>`;
  }).join('')}</div>`;
}

function renderRemotePage() {
  const device = state.route.remote;
  if (!device) return renderDevicesPage();
  let body = '';
  if (state.remoteError) body = emptyState('info', '连接失败', esc(state.remoteError), `<button class="btn soft" data-action="remote-refresh">重试</button><button class="btn ghost" data-action="back">返回设备</button>`);
  else if (state.remoteLoading || !state.remoteState) body = skeletonGrid(9);
  else body = `${remoteAlbumCards()}
    <div class="section-note" style="margin-top:22px">${ico('wifi')} 正在通过局域网读取 <b>${esc(device.name)}</b> 的相册。图片由对方电脑提供，不会上传到互联网。</div>`;
  return `<div class="content-inner">
    <div class="page-head"><div><h1>${pageBack()}${esc(device.name || '其他电脑')}</h1><div class="page-sub">${state.remoteState ? `${state.remoteState.totalPhotos} 张照片 · ${state.remoteState.albums.length} 个相册` : '正在连接…'}</div></div>
      <div class="head-actions"><button class="btn soft sm" data-action="remote-all">${ico('photos')} 全部照片</button><button class="btn ghost sm" data-action="remote-refresh">${ico('refresh')} 刷新</button></div>
    </div>${body}
  </div>`;
}

function renderRemoteAlbumPage() {
  const device = state.route.remote;
  const album = state.route.remoteAlbum;
  let body = '';
  if (state.remoteLoading) body = skeletonGrid(12);
  else if (state.remoteError) body = emptyState('info', '读取失败', esc(state.remoteError), `<button class="btn soft" data-action="remote-refresh">重试</button>`);
  else if (!state.remotePhotos.length) body = emptyState('folder-open', '这个相册没有照片', '换一个相册看看。');
  else body = `<div class="photo-grid">${state.remotePhotos.map((item) => `<div class="photo-tile" role="button" tabindex="0" data-action="remote-photo" data-id="${esc(item.id)}"><img src="${esc(remoteThumb(device, item.id, 420))}" alt="${esc(item.name)}" loading="lazy"><div class="tile-meta">${esc(item.name)}</div></div>`).join('')}</div>`;
  return `<div class="content-inner">
    <div class="page-head"><div><h1>${pageBack()}${esc(album ? album.name : '照片')}</h1><div class="page-sub">${album ? `${album.count} 张 · ` : ''}${esc(device.name)}</div></div>
      <div class="head-actions"><button class="btn soft sm" data-action="remote-refresh">${ico('refresh')} 刷新</button></div>
    </div>${body}
  </div>`;
}

/* ---------------- downloads ---------------- */
async function loadTrash() {
  state.trashLoading = true;
  state.trashError = '';
  renderContent();
  try {
    const data = await api('/api/trash');
    state.trashItems = Array.isArray(data.items) ? data.items : [];
  } catch (error) {
    state.trashError = error.message;
  } finally {
    state.trashLoading = false;
    renderContent();
  }
}

function renderTrashPage() {
  const rows = state.trashItems.map((item) => `<div class="dl-row">
    <div class="dl-icon">${ico(item.mediaType === 'video' ? 'video' : 'image')}</div>
    <div style="min-width:0"><div class="dl-name">${esc(item.name)}</div><div class="dl-sub">${item.mediaType === 'video' ? '视频' : '图片'} · ${fmtBytes(item.size || 0)} · ${fmtShort(item.t || Date.now())}</div></div>
  </div>`).join('');
  return `<div class="content-inner">
    <div class="page-head"><div><h1>${pageBack()}${ANDROID ? '电脑回收站' : '回收站'}</h1><div class="page-sub">${state.trashItems.length} 个文件 · 清空后才会真正删除</div></div>
      <div class="head-actions"><button class="btn ghost sm" data-action="refresh-trash">${ico('refresh')} 刷新</button><button class="btn danger sm" data-action="empty-trash" ${state.trashItems.length ? '' : 'disabled'}>${ico('trash')} 清空回收站</button></div>
    </div>
    ${state.trashLoading ? skeletonGrid(6) : state.trashError ? emptyState('info', '回收站打不开', esc(state.trashError)) : state.trashItems.length ? `<div class="list-wrap" style="background:var(--surface-solid);border:1px solid var(--line);border-radius:14px;overflow:hidden">${rows}</div>` : emptyState('trash', '回收站是空的', '删除的照片和视频会先放在这里，清空回收站才会真正从电脑上删除。')}
  </div>`;
}

function renderDownloadsPage() {
  const rows = state.downloads.map((item) => `<div class="dl-row">
    <div class="dl-icon">${ico(item.source === 'cloud' ? 'cloud' : 'image')}</div>
    <div style="min-width:0"><div class="dl-name">${esc(item.name)}</div><div class="dl-sub">${item.source === 'cloud' ? `来自 ${esc(item.cloud || '云盘')}` : '本地照片'}${item.device ? ` · ${esc(item.device)}` : ''} · ${fmtShort(item.time || item.at || Date.now())}${item.size ? ` · ${fmtBytes(item.size)}` : ''}</div></div>
    <div class="dl-actions">${item.path && state.boot && state.boot.isLocal ? `<button class="icon-btn" data-action="reveal-path" data-path="${esc(item.path)}" title="在文件夹中显示">${ico('folder-open')}</button>` : ''}</div>
  </div>`).join('');
  return `<div class="content-inner">
    <div class="page-head"><div><h1>下载记录</h1><div class="page-sub">${state.downloads.length} 条 · 手机保存的照片会按设备分文件夹存放</div></div>
      <div class="head-actions">${state.boot && state.boot.isLocal ? `<button class="btn soft" data-action="open-downloads">${ico('folder-open')} 打开下载文件夹</button>` : ''}<button class="btn ghost" data-action="refresh-downloads">${ico('refresh')} 刷新</button></div>
    </div>
    ${state.downloads.length ? `<div class="list-wrap" style="background:var(--surface-solid);border:1px solid var(--line);border-radius:14px;overflow:hidden">${rows}</div>` : emptyState('download-cloud', '还没有下载记录', '在手机相册里选择照片，点「存到电脑」，就会出现在这里。')}
  </div>`;
}

/* ---------------- mine / settings ---------------- */
function themeOptions() {
  return `<div class="theme-options">
    ${[['light', '浅色'], ['dark', '深色'], ['auto', '跟随系统']].map(([value, label]) => `<button class="theme-opt ${state.theme === value ? 'active' : ''}" data-action="set-theme" data-theme="${value}"><span class="theme-swatch ${value}"></span>${label}</button>`).join('')}
  </div>`;
}

function renderMinePage() {
  const boot = state.boot;
  const share = boot.share;
  const local = boot.isLocal;
  const settings = boot.settings;
  return `<div class="content-inner">
    <div class="page-head"><div><h1>${isMobile() ? '我的' : '设置'}</h1><div class="page-sub">xphoto ${esc(boot.version)} · ${esc(boot.deviceName)}</div></div></div>
    <div class="profile-card">
      <img src="/icons/icon-192.png" alt="">
      <div><div class="profile-name">${esc(boot.deviceName)}</div><div class="profile-sub">${share.enabled ? '手机可访问 · 局域网已开启' : '局域网访问已关闭'} · ${esc(boot.downloadDir || '电脑端下载目录')}</div>
        <div class="profile-stats"><span><b>${boot.totalPhotos}</b>照片</span><span><b>${boot.stats.albums}</b>相册</span><span><b>${boot.favoritesCount}</b>收藏</span><span><b>${fmtBytes(boot.totalBytes)}</b>占用</span></div>
      </div>
    </div>
    <div class="settings-grid">
      <div class="panel">
        <div class="panel-head">${ico('sun')}<h3>外观</h3></div>
        ${themeOptions()}
        <div class="field" style="margin-top:12px">
          <div><div class="field-label">网格密度</div><div class="field-desc">桌面端每行显示的照片数量</div></div>
          <div style="display:flex;align-items:center;gap:9px;min-width:130px"><input id="gridRange" type="range" min="3" max="8" value="${state.gridSize}" style="accent-color:var(--accent);width:100%"><span class="field-value" id="gridValue">${state.gridSize}</span></div>
        </div>
        <div class="field">
          <div><div class="field-label">默认排序</div><div class="field-desc">打开相册时照片的排列方式</div></div>
          <div class="seg"><button class="${state.sort === 'desc' ? 'active' : ''}" data-action="setting-sort" data-sort="desc">最新</button><button class="${state.sort === 'name' ? 'active' : ''}" data-action="setting-sort" data-sort="name">名称</button><button class="${state.sort === 'asc' ? 'active' : ''}" data-action="setting-sort" data-sort="asc">最早</button></div>
        </div>
      </div>

      <div class="panel">
        <div class="panel-head">${ico('smartphone')}<h3>手机连接</h3><button class="btn soft sm" data-action="open-share">${ico('qr')} 二维码</button></div>
        <div class="field">
          <div><div class="field-label">局域网访问</div><div class="field-desc">同一 Wi-Fi 下，手机浏览器可以打开这台电脑的相册</div></div>
          <label class="switch"><input type="checkbox" id="shareSwitch" ${share.enabled ? 'checked' : ''} ${local ? '' : 'disabled'}><span></span></label>
        </div>
        ${share.enabled && local ? `<div class="share-url" style="margin:10px 0 8px">${esc(share.primaryUrl)}</div><div class="share-actions"><button class="btn primary sm" data-action="copy-share">${ico('copy')} 复制网址</button><button class="btn soft sm" data-action="firewall">${ico('shield')} 一键放行防火墙</button></div>` : ''}
        <div class="field" style="margin-top:12px;border-top:1px solid var(--line);padding-top:12px">
          <div><div class="field-label">Tailscale 远程访问</div><div class="field-desc">${share.tailscale && share.tailscale.installed ? (share.tailscale.online ? `已连接 · ${esc(share.tailscale.ip || '')}` : '已安装，未登录') : '未检测到 Tailscale'}</div></div>
          <label class="switch"><input type="checkbox" id="tailscaleSwitch" ${share.remoteAccess ? 'checked' : ''} ${local && share.passwordSet ? '' : 'disabled'}><span></span></label>
        </div>
        ${local ? `<div class="share-actions" style="margin-top:2px"><button class="btn soft sm" data-action="open-password">${ico('shield')} ${share.passwordSet ? '修改访问密码' : '设置访问密码'}</button><button class="btn ghost sm" data-action="open-share">${ico('link')} Tailscale 设置</button></div>` : ''}
        ${share.remoteAccess && share.tailscaleUrl ? `<div class="share-url" style="margin:8px 0 4px">${esc(share.tailscaleUrl)}</div><button class="btn ghost sm" data-action="copy-tailscale">${ico('copy')} 复制 Tailscale 网址</button>` : ''}
        ${local && !share.passwordSet ? '<div class="form-hint danger-text">先设置访问密码，才能开启 Tailscale 远程访问。</div>' : ''}
        ${!local ? '<div class="form-hint">手机端只能查看。要修改连接设置，请在电脑上操作。</div>' : ''}
      </div>

      <div class="panel">
        <div class="panel-head">${ico('disk')}<h3>存储</h3>${local ? `<button class="btn soft sm" data-action="open-downloads">${ico('folder-open')} 打开</button>` : ''}</div>
        <div class="field">
          <div style="min-width:0"><div class="field-label">下载文件夹</div><div class="field-desc" style="word-break:break-all">${esc(boot.downloadDir || '仅电脑端可见')}</div></div>
        </div>
        <div class="field">
          <div><div class="field-label">手机保存位置</div><div class="field-desc">手机选择「存到电脑」后，会按设备名放进 手机下载/设备名</div></div>
          <span class="field-value">自动分类</span>
        </div>
        ${local ? `<div class="field">
          <div><div class="field-label">缩略图缓存</div><div class="field-desc">打开图片时生成的预览缓存，清理后会自动重建</div></div>
          <div style="display:flex;align-items:center;gap:8px"><span class="field-value">${fmtBytes(state.cacheBytes || 0)}</span><button class="btn ghost sm" data-action="clear-cache">清理</button></div>
        </div>` : ''}
        ${local ? `<div class="share-actions" style="margin-top:10px"><button class="btn soft sm" data-action="change-download-dir">${ico('folder')} 更改下载文件夹</button></div>` : ''}
      </div>

      <div class="panel">
        <div class="panel-head">${ico('settings')}<h3>应用</h3></div>
        <div class="field"><div><div class="field-label">关闭窗口时</div><div class="field-desc">${local ? '关闭后继续在托盘运行，手机还能访问' : '此设置只能在电脑端修改'}</div></div><label class="switch"><input type="checkbox" id="traySwitch" ${settings.closeToTray !== false ? 'checked' : ''} ${local ? '' : 'disabled'}><span></span></label></div>
        <div class="field"><div><div class="field-label">版本</div><div class="field-desc">Windows 桌面端 + 手机网页端</div></div><span class="field-value">${esc(boot.version)}</span></div>
        <div class="field"><div><div class="field-label">服务端口</div><div class="field-desc">手机网址中的端口号</div></div><span class="field-value">${boot.share.port}</span></div>
        <div class="field"><div><div class="field-label">更新公告</div><div class="field-desc">从 1.0 到 ${esc(boot.version)} 的全部变化</div></div><button class="btn ghost sm" data-action="changelog">查看</button></div>
        <div class="field"><div><div class="field-label">关于 xphoto</div><div class="field-desc">参考 Microsoft Photos 与小米相册设计</div></div><button class="btn ghost sm" data-action="about">查看</button></div>
        ${local && window.xphoto ? `<div class="share-actions" style="margin-top:12px"><button class="btn danger sm" data-action="quit-app">${ico('power')} 退出 xphoto</button></div>` : ''}
      </div>
    </div>
  </div>`;
}

/* ---------------- shell ---------------- */
function renderShell() {
  if (!state.boot) {
    renderMobileTopbar();
    return;
  }
  const boot = state.boot;
  const nav = activeNav();
  const share = boot.share;

  const side = $('#sideScroll');
  if (side) {
    const navItems = [
      ['photos', '照片', 'photos', boot.totalPhotos],
      ['favorites', '收藏', 'heart', boot.favoritesCount],
      ['recent', '最近', 'clock', boot.recentCount],
      ['albums', '相册', 'albums', boot.stats.albums + (ANDROID ? state.localFolders.length : 0)]
    ].map(([key, label, icon, count]) => `<button class="nav-item ${nav === key ? 'active' : ''}" data-action="nav" data-nav="${key}">${ico(icon)}<span>${label}</span><span class="nav-count">${count || ''}</span></button>`).join('');

    const rootItems = boot.roots.map((root) => `<div class="root-row">
      <button class="nav-item ${state.route.name === 'root' && state.route.rootId === root.id ? 'active' : ''}" data-action="open-root" data-id="${esc(root.id)}">
        ${ico('folder')}<span style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${esc(root.name)}</span>${root.system ? '<span class="root-sys">下载</span>' : ''}<span class="nav-count">${root.count}</span>
      </button>
      ${root.system ? '' : `<button class="root-remove" data-action="remove-root" data-id="${esc(root.id)}" data-name="${esc(root.name)}" title="移除此文件夹">${ico('x')}</button>`}
    </div>`).join('');

    const pinned = state.localPinned
      .map((id) => state.localFolders.find((folder) => folder.id === id))
      .filter(Boolean);
    const localTotal = state.localFolders.reduce((sum, folder) => sum + (Number(folder.count) || 0), 0);
    const localSection = ANDROID ? `
      <div class="side-label"><span>手机本机</span><button data-action="android-add-folder" title="选择手机文件夹">${ico('plus')}</button></div>
      <button class="nav-item ${nav === 'local' && state.route.name !== 'localTrash' ? 'active' : ''}" data-action="android-local" data-id="all">${ico('smartphone')}<span>手机相册</span><span class="nav-count">${localTotal || ''}</span></button>
      <button class="nav-item ${state.route.name === 'localTrash' ? 'active' : ''}" data-action="nav" data-nav="localTrash">${ico('trash')}<span>手机回收站</span><span class="nav-count">${state.localRecycleCount || ''}</span></button>
      ${pinned.map((folder) => `<button class="nav-item ${state.route.name === 'localFolder' && state.route.folderId === folder.id ? 'active' : ''}" data-action="android-local-folder" data-id="${esc(folder.id)}" data-name="${esc(folder.name)}">
        ${ico('folder')}<span style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${esc(folder.name)}</span><span class="nav-count">${folder.count}</span>
      </button>`).join('')}
      ${pinned.length ? '' : '<div class="root-empty">点 + 把手机相册文件夹放到这里。</div>'}
    ` : '';

    side.innerHTML = `
      <div class="side-label">资料库</div>
      ${navItems}
      <div class="side-label"><span>文件夹</span><button data-action="add-folder" title="添加文件夹">${ico('plus')}</button></div>
      ${rootItems || '<div class="root-empty">还没有文件夹，点 + 添加。</div>'}
      ${localSection}
      <div class="side-label">更多</div>
      <button class="nav-item ${nav === 'cloud' ? 'active' : ''}" data-action="nav" data-nav="cloud">${ico('cloud')}<span>云盘</span><span class="nav-count">${state.clouds.length || ''}</span></button>
      <button class="nav-item ${nav === 'devices' ? 'active' : ''}" data-action="nav" data-nav="devices">${ico('devices')}<span>设备</span></button>
      <button class="nav-item ${nav === 'downloads' ? 'active' : ''}" data-action="nav" data-nav="downloads">${ico('download-cloud')}<span>下载记录</span></button>
      <button class="nav-item ${nav === 'trash' ? 'active' : ''}" data-action="nav" data-nav="trash">${ico('trash')}<span>${ANDROID ? '电脑回收站' : '回收站'}</span></button>
      <div class="side-label">系统</div>
      <button class="nav-item ${nav === 'mine' ? 'active' : ''}" data-action="nav" data-nav="mine">${ico('settings')}<span>设置</span></button>
    `;

    const foot = $('#sideFoot');
    if (foot) {
      const url = share.primaryUrl || '';
      foot.innerHTML = `
        <div class="storage-card">
          <div class="storage-top"><span>照片占用</span><span>${boot.totalPhotos} 张</span></div>
          <div class="storage-num">${fmtBytes(boot.totalBytes)}</div>
          <div class="storage-bar"><i style="width:${Math.min(100, Math.max(4, Math.round((boot.totalBytes / (20 * 1024 ** 3)) * 100)))}%"></i></div>
          <div class="storage-note">${boot.stats.albums} 个相册 · ${boot.stats.roots} 个文件夹</div>
        </div>
        ${ANDROID ? `<div class="storage-card" style="padding:10px 12px">
          <div style="display:flex;align-items:center;justify-content:space-between;gap:12px">
            <div><div class="field-label">电脑连接</div><div class="field-desc">关闭后回到手机本机相册</div></div>
            <label class="switch"><input type="checkbox" id="androidRemoteSwitch" checked><span></span></label>
          </div>
        </div>` : `<button class="connect-card" data-action="open-share">
          <span class="connect-icon">${ico('smartphone')}</span>
          <span class="connect-body"><span class="connect-title">手机连接 <span style="width:5px;height:5px;border-radius:50%;background:${share.enabled ? '#9effd0' : '#ffd39e'};display:inline-block"></span></span>
          <span class="connect-sub">${share.enabled ? '局域网已开启 · 点击查看网址' : '点击开启，手机可访问'}</span></span>
          <span class="connect-arrow">${ico('chevron-right')}</span>
        </button>`}`;
    }
  }

  const pill = $('#lanPill');
  if (pill) {
    pill.classList.toggle('on', Boolean(share.enabled));
    const text = $('#lanPillText');
    if (text) text.textContent = share.enabled ? '手机可访问' : '局域网已关闭';
  }
  const themeBtn = $('#themeBtn');
  if (themeBtn) themeBtn.innerHTML = ico(document.documentElement.dataset.theme === 'dark' ? 'sun' : 'moon');
  const tbActions = $('.tb-actions');
  if (tbActions) {
    const refreshBtn = tbActions.querySelector('[data-action="refresh"]');
    if (refreshBtn) refreshBtn.innerHTML = ico('refresh');
    const mineBtn = tbActions.querySelector('[data-action="open-mine"]');
    if (mineBtn) mineBtn.innerHTML = ico('settings');
  }
  renderMobileTopbar();
  renderMobileNav();
  paintIcons(document);
}

function renderMobileTopbar() {
  const bar = $('#mobileTopbar');
  if (!bar) return;
  const r = state.route;
  const title = titleForRoute();
  const sub = subtitleForRoute();
  const canBack = canBackRoute(r.name);
  const canSelect = ['photos', 'favorites', 'recent', 'album', 'root'].includes(r.name) && r.name !== 'favorites';
  bar.innerHTML = `
    ${canBack ? `<button class="icon-btn" data-action="back" aria-label="返回">${ico('arrow-left')}</button>` : ''}
    <div class="mt-title">${esc(title)}<small>${esc(sub)}</small></div>
    <div class="mt-actions">
      ${canSelect ? `<button class="mt-text" data-action="select-mode">${state.selecting ? '取消' : '选择'}</button>` : ''}
      <button class="icon-btn" data-action="mobile-search" aria-label="搜索">${ico('search')}</button>
      <button class="icon-btn" data-action="mobile-more" aria-label="更多">${ico('more')}</button>
    </div>`;
}

function renderMobileNav() {
  const nav = $('#mobileNav');
  if (!nav) return;
  const active = activeNav();
  const items = [
    ['photos', '照片', 'photos'],
    ...(ANDROID ? [['local', '手机', 'smartphone']] : []),
    ['albums', '相册', 'albums'],
    ['cloud', '云盘', 'cloud'],
    ['devices', '设备', 'devices'],
    ['mine', '我的', 'settings']
  ];
  nav.innerHTML = items.map(([key, label, icon]) => `<button class="mnav ${active === key ? 'active' : ''}" data-action="nav" data-nav="${key}">${ico(icon)}<span>${label}</span></button>`).join('');
}

/* ---------------- content dispatcher ---------------- */
function renderContent({ keepScroll = true } = {}) {
  const content = $('#content');
  if (!content) return;
  const y = keepScroll ? content.scrollTop : 0;
  if (state.loadingBoot) {
    content.innerHTML = `<div class="content-inner"><div class="page-head"><div><h1>照片</h1><div class="page-sub">正在打开你的相册…</div></div></div>${skeletonGrid(18)}</div>`;
    paintIcons(content);
    return;
  }
  if (!state.boot) {
    content.innerHTML = emptyState('info', '暂时打不开相册', esc(state.bootError || '请确认 xphoto 正在运行，然后重试。'), `<button class="btn primary" data-action="retry-boot">重试</button>`);
    paintIcons(content);
    return;
  }
  const r = state.route;
  let html = '';
  if (['photos', 'favorites', 'recent', 'album', 'root'].includes(r.name)) html = renderPhotosPage();
  else if (r.name === 'local' || r.name === 'localFolder' || r.name === 'localTrash') html = renderLocalPage();
  else if (r.name === 'albums') html = renderAlbumsPage();
  else if (r.name === 'cloud') html = renderCloudPage();
  else if (r.name === 'cloudBrowse') html = renderCloudBrowsePage();
  else if (r.name === 'devices') html = renderDevicesPage();
  else if (r.name === 'remote') html = renderRemotePage();
  else if (r.name === 'remoteAlbum') html = renderRemoteAlbumPage();
  else if (r.name === 'downloads') html = renderDownloadsPage();
  else if (r.name === 'trash') html = renderTrashPage();
  else if (r.name === 'mine') html = renderMinePage();
  else html = renderPhotosPage();
  content.innerHTML = html;
  paintIcons(content);
  content.scrollTop = y;
  setupTimeScroller();
  updateSelectionBar();
  if (r.name === 'mine') bindMineControls();
}

function bindMineControls() {
  const range = $('#gridRange');
  if (range) {
    range.addEventListener('input', () => {
      const value = Number(range.value);
      state.gridSize = value;
      document.documentElement.style.setProperty('--grid-cols', String(value));
      const label = $('#gridValue');
      if (label) label.textContent = String(value);
    });
    range.addEventListener('change', () => {
      localStorage.setItem(LS.grid, String(state.gridSize));
      api('/api/settings', { method: 'PATCH', body: { gridSize: state.gridSize } }).catch(() => {});
    });
  }
  const shareSwitch = $('#shareSwitch');
  if (shareSwitch) shareSwitch.addEventListener('change', toggleShare);
  const tailscaleSwitch = $('#tailscaleSwitch');
  if (tailscaleSwitch) tailscaleSwitch.addEventListener('change', toggleRemoteAccess);
  const traySwitch = $('#traySwitch');
  if (traySwitch) traySwitch.addEventListener('change', () => {
    api('/api/settings', { method: 'PATCH', body: { closeToTray: traySwitch.checked } })
      .then(() => toast(traySwitch.checked ? '关闭窗口后继续在托盘运行' : '关闭窗口将退出 xphoto', 'ok'))
      .catch((error) => { toast(error.message, 'err'); traySwitch.checked = !traySwitch.checked; });
  });
}

/* ---------------- selection ---------------- */
function toggleSelectMode() {
  state.selecting = !state.selecting;
  if (!state.selecting) state.selected.clear();
  renderContent();
  renderMobileTopbar();
}

function toggleSelection(id) {
  if (state.selected.has(id)) state.selected.delete(id);
  else state.selected.add(id);
  const tile = $(`.photo-tile[data-id="${CSS.escape(id)}"]`);
  if (tile) tile.classList.toggle('selected', state.selected.has(id));
  updateSelectionBar();
  renderMobileTopbar();
}

function selectDateGroup(index) {
  const group = document.querySelectorAll('#content .photo-group')[index];
  if (!group) return;
  const tiles = Array.from(group.querySelectorAll('.photo-tile[data-id]'));
  const ids = tiles.map((tile) => tile.dataset.id).filter(Boolean);
  if (!ids.length) return;
  state.selecting = true;
  const allSelected = ids.every((id) => state.selected.has(id));
  ids.forEach((id) => {
    if (allSelected) state.selected.delete(id);
    else state.selected.add(id);
  });
  tiles.forEach((tile) => tile.classList.toggle('selected', state.selected.has(tile.dataset.id)));
  const button = group.querySelector('.date-select-all');
  if (button) button.textContent = allSelected ? '全选' : '取消';
  updateSelectionBar();
  renderMobileTopbar();
}

function setupLongPress() {
  let timer = 0;
  let startX = 0;
  let startY = 0;
  const cancel = () => {
    clearTimeout(timer);
    timer = 0;
  };
  const begin = (tile) => {
    const id = tile.dataset.id;
    if (!id) return;
    state.selecting = true;
    state.selected.add(id);
    tile.classList.add('selected');
    state.suppressClick = true;
    setTimeout(() => { state.suppressClick = false; }, 700);
    updateSelectionBar();
    renderMobileTopbar();
    if (navigator.vibrate) { try { navigator.vibrate(18); } catch {} }
  };
  document.addEventListener('pointerdown', (event) => {
    const tile = event.target.closest?.('.photo-tile[data-action="photo"], .photo-tile[data-action="local-photo"]');
    if (!tile || event.target.closest('button')) return;
    startX = event.clientX;
    startY = event.clientY;
    cancel();
    timer = setTimeout(() => { timer = 0; begin(tile); }, 520);
  }, { passive: true });
  document.addEventListener('pointermove', (event) => {
    if (!timer) return;
    if (Math.abs(event.clientX - startX) > 9 || Math.abs(event.clientY - startY) > 9) cancel();
  }, { passive: true });
  document.addEventListener('pointerup', cancel, { passive: true });
  document.addEventListener('pointercancel', cancel, { passive: true });
  document.addEventListener('contextmenu', (event) => {
    const tile = event.target.closest?.('.photo-tile[data-action="photo"], .photo-tile[data-action="local-photo"]');
    if (!tile) return;
    event.preventDefault();
    begin(tile);
  });
}

function updateSelectionBar() {
  const bar = $('#selectionBar');
  if (!bar) return;
  const r = state.route;
  const phoneLocal = isPhoneLocalRoute();
  const allowed = state.selecting && (['photos', 'favorites', 'recent', 'album', 'root'].includes(r.name) || phoneLocal);
  if (!allowed) { bar.hidden = true; bar.innerHTML = ''; return; }
  bar.hidden = false;
  const count = state.selected.size;
  if (phoneLocal) {
    const pool = state.localPhotos || [];
    bar.innerHTML = `
      <button class="btn ghost sm select-all" data-action="select-all">${count === pool.length && count > 0 ? '取消全选' : '全选'}</button>
      <span class="selection-count"><b>${count}</b> 张</span>
      <span class="divider"></span>
      <button class="btn ghost sm" data-action="location-selected" ${count ? '' : 'disabled'}>${ico('info')}<span class="lbl-full">位置</span><span class="lbl-short">位置</span></button>
      <button class="btn primary sm" data-action="share-selected" ${count ? '' : 'disabled'}>${ico('share')}<span class="lbl-full">分享</span><span class="lbl-short">分享</span></button>
      <button class="icon-btn" data-action="cancel-select" aria-label="取消">${ico('x')}</button>`;
    paintIcons(bar);
    return;
  }
  bar.innerHTML = `
    <button class="btn ghost sm select-all" data-action="select-all">${count === state.photos.length && count > 0 ? '取消全选' : '全选'}</button>
    <span class="selection-count"><b>${count}</b> 张</span>
    <span class="divider"></span>
    <button class="btn soft sm" data-action="download-selected" ${count ? '' : 'disabled'}>${ico('download')}<span class="lbl-full">下载到手机</span><span class="lbl-short">下载</span></button>
    <button class="btn primary sm" data-action="save-selected" ${count && state.boot && state.boot.isLocal ? '' : 'disabled'}>${ico('download-cloud')}<span class="lbl-full">存到电脑</span><span class="lbl-short">存电脑</span></button>
    <button class="btn ghost sm" data-action="fav-selected" ${count ? '' : 'disabled'}>${ico('heart')}<span class="lbl-full">收藏</span><span class="lbl-short">收藏</span></button>
    <button class="btn ghost sm" data-action="move-selected" ${count ? '' : 'disabled'}>${ico('folder')}<span class="lbl-full">移动</span><span class="lbl-short">移动</span></button>
    <button class="btn ghost sm" data-action="share-selected" ${count ? '' : 'disabled'}>${ico('share')}<span class="lbl-full">分享</span><span class="lbl-short">分享</span></button>
    ${!isMobile() && state.boot?.isLocal ? `<button class="btn ghost sm" data-action="reveal-selected" ${count ? '' : 'disabled'}>${ico('folder')}<span class="lbl-full">打开文件夹</span><span class="lbl-short">文件夹</span></button>` : ''}
    <button class="btn ghost sm" data-action="location-selected" ${count ? '' : 'disabled'}>${ico('info')}<span class="lbl-full">位置</span><span class="lbl-short">位置</span></button>
    <button class="btn ghost sm danger-text" data-action="trash-selected" ${count ? '' : 'disabled'}>${ico('trash')}<span class="lbl-full">删除</span><span class="lbl-short">删除</span></button>
    <button class="icon-btn" data-action="cancel-select" aria-label="取消">${ico('x')}</button>`;
  paintIcons(bar);
}

function isPhoneLocalRoute() {
  return state.route.name === 'local' || state.route.name === 'localFolder';
}

function selectedPhotos() {
  const pool = isPhoneLocalRoute() ? state.localPhotos : state.photos;
  return (pool || []).filter((item) => state.selected.has(item.id));
}

async function downloadSelected() {
  const items = selectedPhotos();
  if (!items.length) return toast('先选择照片', 'err');
  if (items.length > 50) return toast('一次最多下载 50 张，请分批选择', 'err');
  const archive = isMobile() || ANDROID ? 0 : 1;
  for (let i = 0; i < items.length; i += 1) {
    setTimeout(() => triggerDownload(withToken(`/api/download?id=${encodeURIComponent(items[i].id)}&archive=${archive}&target=phone&device=${encodeURIComponent(deviceLabel())}`)), i * 260);
  }
  toast(archive ? `开始下载 ${items.length} 张到电脑` : `开始下载 ${items.length} 张到手机${ANDROID ? '，完成后在「手机下载」查看' : ''}`, 'ok');
  state.selecting = false;
  state.selected.clear();
  renderContent();
  renderMobileTopbar();
}

async function saveSelectedToPC() {
  const items = selectedPhotos();
  if (!items.length) return toast('先选择照片', 'err');
  const ids = items.map((item) => item.id);
  try {
    const data = await api('/api/export', { method: 'POST', body: { ids, target: 'desktop', device: deviceLabel() } });
    toast(`已保存 ${data.total || ids.length} 张到电脑下载文件夹`, 'ok');
    state.selecting = false;
    state.selected.clear();
    renderContent();
    renderMobileTopbar();
    refreshBoot();
  } catch (error) { toast(error.message, 'err'); }
}

async function favoriteSelected() {
  const items = selectedPhotos();
  if (!items.length) return;
  try {
    for (const item of items) {
      await api('/api/favorite', { method: 'POST', body: { id: item.id, value: true } });
      item.fav = true;
    }
    toast(`已收藏 ${items.length} 张`, 'ok');
    state.selecting = false;
    state.selected.clear();
    await refreshBoot();
    renderContent();
  } catch (error) { toast(error.message, 'err'); }
}

function moveSelected() {
  const items = selectedPhotos();
  if (!items.length) return toast('先选择照片', 'err');
  const albums = (state.boot?.albums || []).filter((album) => album.count > 0);
  if (!albums.length) return toast('还没有可移动到的相册', 'err');
  openModal('move', { ids: items.map((item) => item.id), count: items.length });
}

function moveModal() {
  const data = state.modalData || {};
  const albums = (state.boot?.albums || []).filter((album) => album.count > 0);
  const body = `<div class="move-hint">已选 ${data.count || data.ids?.length || 0} 张，移动到：</div>
    <div class="move-list">${albums.map((album) => `<button class="move-row" data-action="move-to" data-id="${esc(album.id)}">
      <span class="move-ico">${ico('folder')}</span>
      <span class="move-text"><b>${esc(album.name)}</b><small>${esc(album.rootName || '')}${album.rel ? ` / ${esc(album.rel)}` : ''} · ${album.count} 张</small></span>
      ${ico('chevron-right')}
    </button>`).join('')}</div>`;
  return modalShell('移动照片', '文件会移动到电脑上的目标相册文件夹。', body);
}

async function moveToAlbum(albumId) {
  const ids = state.modalData?.ids || [];
  if (!ids.length) return;
  try {
    const data = await api('/api/move', { method: 'POST', body: { ids, targetAlbumId: albumId } });
    closeModal();
    state.selecting = false;
    state.selected.clear();
    toast(`已移动 ${data.moved || 0} 个文件${data.skipped ? `，跳过 ${data.skipped} 个` : ''}`, 'ok');
    await refreshBoot();
    renderContent();
    renderMobileTopbar();
  } catch (error) { toast(error.message, 'err'); }
}

function isLocalLibraryRoute() {
  return ['photos', 'favorites', 'recent', 'album', 'root'].includes(state.route.name);
}

async function revealSelected() {
  const items = selectedPhotos();
  if (!items.length) return toast('先选择照片', 'err');
  if (!isLocalLibraryRoute()) return toast('只能定位电脑本机的照片', 'err');
  try {
    const result = await api('/api/reveal', { method: 'POST', body: { ids: items.map((item) => item.id) } });
    toast(items.length > 1
      ? `已打开文件夹并定位「${result.name}」，可拖到微信/QQ 发送`
      : '已打开文件夹并选中文件，拖到微信/QQ 即可发送', 'ok');
  } catch (error) {
    toast(error.message || '打开文件夹失败', 'err');
  }
}

async function locationSelected() {
  const items = selectedPhotos();
  if (!items.length) return toast('先选择照片', 'err');
  const first = items[0];
  if (isPhoneLocalRoute()) {
    state.location = {
      name: first.name,
      path: first.location || first.uri || first.id,
      album: first.album || '手机本机',
      sizeText: first.size ? formatBytes(first.size) : '',
      count: items.length,
      phone: true
    };
    openModal('location');
    return;
  }
  if (!isLocalLibraryRoute()) return toast('只能查看电脑本机照片的位置', 'err');
  try {
    const info = await api(`/api/info?id=${encodeURIComponent(first.id)}`);
    state.location = {
      name: info.name || first.name,
      path: info.path || first.album || '',
      album: info.album || first.album,
      sizeText: info.sizeText || '',
      count: items.length
    };
    openModal('location');
  } catch (error) {
    toast(error.message || '读取位置失败', 'err');
  }
}

function locationModal() {
  const loc = state.location || {};
  const path = loc.path || '未知位置';
  return `<div class="modal-backdrop" data-action="modal-backdrop">
    <div class="modal" role="dialog" aria-modal="true" aria-label="图片位置">
      <div class="modal-head"><div><h2>${loc.count > 1 ? `已选 ${loc.count} 张` : (loc.phone ? '手机图片位置' : '图片位置')}</h2>
        <p>${loc.count > 1 ? '多选时显示第一张的位置；打开文件夹会定位所选第一张。' : '文件在磁盘或手机媒体库中的具体位置。'}</p></div>
        <button class="icon-btn" data-action="close-modal" aria-label="关闭">${ico('x')}</button></div>
      <div class="modal-body">
        <div class="location-name">${esc(loc.name || '')}</div>
        <div class="location-meta">${esc(loc.album || '')}${loc.sizeText ? ` · ${esc(loc.sizeText)}` : ''}</div>
        <div class="location-path">${esc(path)}</div>
        <div class="location-actions">
          <button class="btn soft sm" data-action="copy-location">${ico('copy')}复制路径</button>
          ${!loc.phone && isLocalLibraryRoute() ? `<button class="btn ghost sm" data-action="reveal-selected">${ico('folder')}打开文件夹</button>` : ''}
          <button class="btn ghost sm" data-action="close-modal">关闭</button>
        </div>
        ${loc.phone ? '<p class="muted">这是文件在手机存储中的实际路径，可到「文件管理」按此路径查找。</p>' : ''}
      </div>
    </div>
  </div>`;
}

async function copyLocation() {
  const path = state.location && state.location.path;
  if (!path) return toast('没有可复制的位置', 'err');
  const ok = await copyText(path);
  toast(ok ? '路径已复制' : '复制失败，请手动选择路径', ok ? 'ok' : 'err');
}

async function shareSelected() {
  const items = selectedPhotos();
  if (!items.length) return toast('先选择照片', 'err');
  if (ANDROID && window.XPhotoAndroid?.shareFiles) {
    const urls = isPhoneLocalRoute()
      ? items.map((item) => item.uri || item.id)
      : items.map((item) => absoluteUrl(localImage(item.id)));
    try {
      const ok = window.XPhotoAndroid.shareFiles(JSON.stringify(urls));
      if (ok) return;
    } catch {}
  }
  if (!navigator.share || !navigator.canShare) {
    if (!ANDROID && state.boot?.isLocal && isLocalLibraryRoute()) return revealSelected();
    return toast('这个浏览器不支持系统分享，请用手机 APK 分享到微信/QQ', 'err');
  }
  try {
    const files = [];
    for (const item of items.slice(0, 9)) {
      const response = await fetch(withToken(`/api/image?id=${encodeURIComponent(item.id)}&original=1`));
      if (!response.ok) continue;
      const blob = await response.blob();
      files.push(new File([blob], item.name || 'photo.jpg', { type: blob.type || 'image/jpeg' }));
    }
    if (!files.length) return toast('没有可分享的文件', 'err');
    if (!navigator.canShare({ files })) {
      if (!ANDROID && state.boot?.isLocal && isLocalLibraryRoute()) return revealSelected();
      return toast('当前浏览器不支持分享图片文件', 'err');
    }
    await navigator.share({ files, title: 'xphoto 照片' });
  } catch (error) {
    if (error.name === 'AbortError') return;
    if (!ANDROID && state.boot?.isLocal && isLocalLibraryRoute()) return revealSelected();
    toast('分享失败：' + error.message, 'err');
  }
}

async function trashSelected() {
  const items = selectedPhotos();
  if (!items.length) return;
  if (!window.confirm(`把选中的 ${items.length} 个文件移到回收站？\n清空回收站后才会真正删除。`)) return;
  try {
    const data = await api('/api/trash', { method: 'POST', body: { ids: items.map((item) => item.id) } });
    toast(`已移到回收站：${data.count || items.length} 个文件`, 'ok');
    state.selecting = false;
    state.selected.clear();
    state.photos = state.photos.filter((item) => !items.some((gone) => gone.id === item.id));
    await refreshBoot();
    renderContent();
    renderMobileTopbar();
  } catch (error) { toast(error.message, 'err'); }
}

async function trashViewerItem() {
  const item = viewerItem();
  if (!item || viewerSource(item) !== 'local') return;
  if (!window.confirm('把这个文件移到回收站？清空回收站后才会真正删除。')) return;
  try {
    await api('/api/trash', { method: 'POST', body: { ids: [item.id] } });
    closeViewer();
    state.photos = state.photos.filter((entry) => entry.id !== item.id);
    await refreshBoot();
    renderContent();
    toast('已移到回收站', 'ok');
  } catch (error) { toast(error.message, 'err'); }
}

async function emptyTrash() {
  if (!state.trashItems.length) return;
  if (!window.confirm(`确定清空回收站？\n${state.trashItems.length} 个文件会被永久删除，无法恢复。`)) return;
  try {
    await api('/api/trash/empty', { method: 'POST' });
    state.trashItems = [];
    toast('回收站已清空', 'ok');
    await refreshBoot();
    renderContent();
  } catch (error) { toast(error.message, 'err'); }
}

function emptyLocalTrash() {
  if (!ANDROID || !window.XPhotoAndroid || typeof window.XPhotoAndroid.emptyLocalRecycle !== 'function') {
    toast('请在手机 App 内清空手机回收站', 'err');
    return;
  }
  if (!state.localRecycleCount) return;
  if (!window.confirm(`确定清空手机回收站？\n${state.localRecycleCount} 个文件会被永久删除，无法恢复。`)) return;
  window.XPhotoAndroid.emptyLocalRecycle();
  toast('正在清空手机回收站…');
  setTimeout(loadAndroidRecycle, 500);
}

async function toggleFavorite(item) {
  if (!item) return;
  try {
    const data = await api('/api/favorite', { method: 'POST', body: { id: item.id, value: !item.fav } });
    item.fav = Boolean(data.value);
    for (const list of [state.photos, state.remotePhotos]) {
      const found = list.find((entry) => entry.id === item.id);
      if (found) found.fav = item.fav;
    }
    if (state.viewer && state.viewer.items[state.viewer.index] && state.viewer.items[state.viewer.index].id === item.id) {
      state.viewer.items[state.viewer.index].fav = item.fav;
    }
    await refreshBoot();
    renderContent();
    if (state.viewer) renderViewer();
    toast(item.fav ? '已加入收藏' : '已取消收藏', 'ok');
  } catch (error) { toast(error.message, 'err'); }
}

function triggerDownload(url) {
  const a = document.createElement('a');
  a.href = url;
  a.download = '';
  a.rel = 'noopener';
  document.body.appendChild(a);
  a.click();
  setTimeout(() => a.remove(), 1500);
}

/* ---------------- viewer ---------------- */
function openViewer(items, index, context = {}) {
  if (!items || !items.length) return;
  state.viewer = { items, index: Math.max(0, Math.min(index, items.length - 1)), context, zoom: 1, panX: 0, panY: 0, info: false };
  renderViewer();
  document.body.classList.add('viewer-open');
}

function closeViewer() {
  if (!state.viewer) return;
  state.viewer = null;
  $('#viewerRoot').innerHTML = '';
  document.body.classList.remove('viewer-open');
}

function viewerItem() {
  if (!state.viewer) return null;
  return state.viewer.items[state.viewer.index] || null;
}

function viewerSource(item) {
  return state.viewer.context.source || 'local';
}

function viewerUrl(item) {
  if (!item) return '';
  const source = viewerSource(item);
  if (source === 'android') return androidMedia(item.uri || item.id, 1800);
  if (source === 'cloud' && state.cloudAccount) return cloudRaw(state.cloudAccount, item);
  if (source === 'remote' && state.route.remote) return remoteImage(state.route.remote, item.id);
  return localImage(item.id);
}

function renderViewer() {
  if (!state.viewer) { $('#viewerRoot').innerHTML = ''; return; }
  const item = viewerItem();
  if (!item) return closeViewer();
  const source = viewerSource(item);
  const count = state.viewer.items.length;
  const index = state.viewer.index;
  const url = viewerUrl(item);
  const canFav = source === 'local';
  const canSavePC = source === 'local' && state.boot && state.boot.isLocal;
  const canReveal = source === 'local' && state.boot && state.boot.isLocal;
  const canTrash = source === 'local';
  const zoom = state.viewer.zoom || 1;
  const panX = state.viewer.panX || 0;
  const panY = state.viewer.panY || 0;
  const info = state.viewer.info;
  const video = isVideoItem(item);
  const viewer = `<div class="viewer" data-viewer>
    <div class="viewer-top">
      <button class="vbtn" data-action="viewer-close" aria-label="关闭">${ico('x')}</button>
      <div style="min-width:0"><div class="vtitle">${esc(item.name || '照片')}</div><div class="vsub">${source === 'android' ? `手机本机 · ${esc(item.album || '手机相册')}` : source === 'cloud' ? '云盘图片' : source === 'remote' ? `${esc(state.route.remote ? state.route.remote.name : '其他电脑')} · 局域网` : esc(item.album || '本地照片')}</div></div>
      <div class="spacer"></div>
      ${canFav ? `<button class="vbtn ${item.fav ? 'fav' : ''}" data-action="viewer-fav" aria-label="收藏">${ico(item.fav ? 'heart-fill' : 'heart')}</button>` : ''}
      ${canTrash ? `<button class="vbtn" data-action="viewer-trash" aria-label="移到回收站" title="移到回收站">${ico('trash')}</button>` : ''}
      ${canReveal ? `<button class="vbtn" data-action="viewer-reveal" aria-label="在文件夹中显示">${ico('folder-open')}</button>` : ''}
      <button class="vbtn" data-action="viewer-info" aria-label="信息">${ico('info')}</button>
      <button class="vbtn" data-action="viewer-close" aria-label="关闭">${ico('x')}</button>
    </div>
    <div class="viewer-stage" data-viewer-stage>
      <div class="viewer-loading" data-viewer-loading></div>
      ${video
        ? `<video class="viewer-video" data-viewer-video src="${esc(url)}" controls autoplay playsinline></video>`
        : `<img class="viewer-img" data-viewer-img src="${esc(url)}" alt="${esc(item.name)}" style="transform:translate(${panX}px, ${panY}px) scale(${zoom})" draggable="false">`}
      <button class="vnav prev" data-action="viewer-prev" ${index === 0 ? 'disabled' : ''} aria-label="上一张">${ico('chevron-left')}</button>
      <button class="vnav next" data-action="viewer-next" ${index === count - 1 ? 'disabled' : ''} aria-label="下一张">${ico('chevron-right')}</button>
      <div class="viewer-counter">${index + 1} / ${count}</div>
    </div>
    <div class="viewer-bottom">
      <div class="viewer-meta"><div class="nm">${esc(item.name || '照片')}</div><div class="dt">${fmtDate(item.mtimeMs || item.t || Date.now())}${item.size ? ` · ${fmtBytes(item.size)}` : ''}${source === 'cloud' && state.cloudPath.length ? ` · ${esc(state.cloudPath[state.cloudPath.length - 1].name)}` : ''}</div></div>
      <div class="viewer-actions">
        ${video ? '' : `<div class="zoom-controls"><button data-action="zoom-out" aria-label="缩小">−</button><span data-viewer-pct>${Math.round(zoom * 100)}%</span><button data-action="zoom-in" aria-label="放大">+</button></div>`}
        ${source !== 'android' ? `<button class="vbtn" data-action="viewer-download" aria-label="下载到手机" title="下载到手机">${ico('download')}</button>` : ''}
        ${canSavePC ? `<button class="vbtn" data-action="viewer-save-pc" aria-label="存到电脑" title="存到电脑">${ico('download-cloud')}</button>` : ''}
      </div>
    </div>
    ${info ? `<aside class="viewer-info"><h4>照片信息</h4>
      <div class="info-row"><span>文件名</span><span>${esc(item.name)}</span></div>
      <div class="info-row"><span>拍摄 / 修改</span><span>${fmtDate(item.mtimeMs || item.t || Date.now())}</span></div>
      <div class="info-row"><span>大小</span><span>${item.size ? fmtBytes(item.size) : '未知'}</span></div>
      <div class="info-row"><span>来源</span><span>${source === 'android' ? '手机本机' : source === 'cloud' ? esc(state.cloudAccount ? state.cloudAccount.name : '云盘') : source === 'remote' ? esc(state.route.remote ? state.route.remote.name : '其他电脑') : '本地文件夹'}</span></div>
      ${item.album ? `<div class="info-row"><span>相册</span><span>${esc(item.album)}</span></div>` : ''}
      ${item.albumRel ? `<div class="info-row"><span>路径</span><span>${esc(item.albumRel)}</span></div>` : ''}
      ${source === 'local' && state.boot && state.boot.isLocal ? `<div class="info-row"><span>位置</span><span>${esc(item.rootName || '')}</span></div>` : ''}
      <button class="btn soft sm" style="margin-top:14px;width:100%" data-action="viewer-close">关闭</button>
    </aside>` : ''}
  </div>`;
  const root = $('#viewerRoot');
  root.innerHTML = viewer;
  paintIcons(root);
  const img = $('[data-viewer-img]', root);
  const vid = $('[data-viewer-video]', root);
  const loading = $('[data-viewer-loading]', root);
  if (vid && loading) loading.style.display = 'none';
  if (vid) {
    vid.addEventListener('error', () => {
      if (loading) loading.style.display = 'none';
      if (vid.parentElement && !$('.viewer-error', vid.parentElement)) {
        const err = document.createElement('div');
        err.className = 'viewer-error';
        err.innerHTML = `${ico('video')}<div>这个视频暂时无法播放</div>`;
        vid.parentElement.appendChild(err);
      }
    });
  }
  if (img) {
    const done = () => {
      img.classList.add('loaded');
      if (loading) loading.style.display = 'none';
    };
    if (img.complete && img.naturalWidth) done();
    img.addEventListener('load', done);
    img.addEventListener('error', () => {
      if (loading) loading.style.display = 'none';
      if (img.parentElement && !$('.viewer-error', img.parentElement)) {
        const err = document.createElement('div');
        err.className = 'viewer-error';
        err.innerHTML = `${ico('image')}<div>这张图片暂时无法预览</div>`;
        img.parentElement.appendChild(err);
      }
    });
    img.addEventListener('dblclick', () => {
      state.viewer.zoom = (state.viewer.zoom || 1) > 1 ? 1 : 2;
      renderViewer();
    });
  }
  setupViewerGestures(root);
  preloadNeighbors();
}

function viewerApplyZoom(zoom, panX, panY) {
  if (!state.viewer) return;
  const next = Math.max(1, Math.min(8, Number(zoom) || 1));
  state.viewer.zoom = next;
  if (next <= 1) { state.viewer.panX = 0; state.viewer.panY = 0; }
  else {
    state.viewer.panX = Number(panX) || 0;
    state.viewer.panY = Number(panY) || 0;
  }
  const img = $('[data-viewer-img]');
  if (img) img.style.transform = `translate(${state.viewer.panX}px, ${state.viewer.panY}px) scale(${next})`;
  const pct = $('[data-viewer-pct]');
  if (pct) pct.textContent = `${Math.round(next * 100)}%`;
}

function viewerZoomBy(delta) {
  if (!state.viewer) return;
  const base = state.viewer.zoom || 1;
  const next = Math.max(1, Math.min(8, delta > 0 ? base * 1.4 : base / 1.4));
  viewerApplyZoom(next, state.viewer.panX, state.viewer.panY);
}

function setupViewerGestures(root) {
  if (!state.viewer) return;
  const stage = $('[data-viewer-stage]', root);
  const img = $('[data-viewer-img]', root);
  if (!stage || !img) return;
  let pinch = null;
  let drag = null;

  stage.addEventListener('wheel', (event) => {
    if (!state.viewer) return;
    event.preventDefault();
    viewerZoomBy(event.deltaY < 0 ? 1 : -1);
  }, { passive: false });

  stage.addEventListener('touchstart', (event) => {
    if (!state.viewer) return;
    if (event.touches.length === 2) {
      const [a, b] = event.touches;
      pinch = { dist: Math.hypot(a.clientX - b.clientX, a.clientY - b.clientY), zoom: state.viewer.zoom || 1 };
      drag = null;
    }
  }, { passive: true });

  stage.addEventListener('touchmove', (event) => {
    if (!state.viewer || !pinch || event.touches.length !== 2) return;
    event.preventDefault();
    const [a, b] = event.touches;
    const dist = Math.hypot(a.clientX - b.clientX, a.clientY - b.clientY);
    viewerApplyZoom(pinch.zoom * (dist / Math.max(1, pinch.dist)), state.viewer.panX, state.viewer.panY);
  }, { passive: false });

  stage.addEventListener('touchend', () => { pinch = null; });
  stage.addEventListener('pointerdown', (event) => {
    if (!state.viewer || (state.viewer.zoom || 1) <= 1.01) return;
    drag = { x: event.clientX, y: event.clientY, panX: state.viewer.panX || 0, panY: state.viewer.panY || 0 };
    try { stage.setPointerCapture(event.pointerId); } catch {}
  });
  stage.addEventListener('pointermove', (event) => {
    if (!drag || !state.viewer) return;
    viewerApplyZoom(state.viewer.zoom, drag.panX + event.clientX - drag.x, drag.panY + event.clientY - drag.y);
  });
  stage.addEventListener('pointerup', () => { drag = null; });
  stage.addEventListener('pointercancel', () => { drag = null; });
}

function preloadNeighbors() {
  if (!state.viewer) return;
  const { items, index } = state.viewer;
  [index - 1, index + 1].forEach((i) => {
    const item = items[i];
    if (item && !isVideoItem(item)) { const image = new Image(); image.src = viewerUrl(item); }
  });
}

function viewerGo(delta) {
  if (!state.viewer) return;
  const next = state.viewer.index + delta;
  if (next < 0 || next >= state.viewer.items.length) return;
  state.viewer.index = next;
  state.viewer.zoom = 1;
  state.viewer.info = false;
  renderViewer();
}

async function viewerDownload() {
  const item = viewerItem();
  if (!item) return;
  const source = viewerSource(item);
  const archive = isMobile() || ANDROID ? 0 : 1;
  if (source === 'cloud' && state.cloudAccount) {
    const folder = state.cloudPath.length ? state.cloudPath[state.cloudPath.length - 1].name : '根目录';
    const url = withToken(`/api/clouds/${encodeURIComponent(state.cloudAccount.id)}/download?kind=file&value=${encodeURIComponent(item.id)}&name=${encodeURIComponent(item.name)}&folder=${encodeURIComponent(folder)}&device=${encodeURIComponent(deviceLabel())}&archive=${archive}`);
    triggerDownload(url);
    toast(archive ? '开始下载到电脑「云盘」文件夹' : '开始下载到手机', 'ok');
    return;
  }
  if (source === 'remote' && state.route.remote) {
    triggerDownload(`${state.route.remote.base}/api/download?id=${encodeURIComponent(item.id)}&archive=${archive}&target=phone&device=${encodeURIComponent(deviceLabel())}&t=${encodeURIComponent(state.route.remote.token || '')}`);
    toast(archive ? '开始下载到手机，同时存到对方电脑' : '开始下载到手机，完成后在「手机下载」查看', 'ok');
    return;
  }
  triggerDownload(withToken(`/api/download?id=${encodeURIComponent(item.id)}&archive=${archive}&target=phone&device=${encodeURIComponent(deviceLabel())}`));
  toast(archive ? '开始下载到手机，同时存到电脑的「手机下载」' : '开始下载到手机，完成后在「手机下载」查看', 'ok');
}

async function viewerSavePC() {
  const item = viewerItem();
  if (!item) return;
  const source = viewerSource(item);
  try {
    if (source === 'cloud' && state.cloudAccount) {
      const folder = state.cloudPath.length ? state.cloudPath[state.cloudPath.length - 1].name : '根目录';
      await api(`/api/clouds/${encodeURIComponent(state.cloudAccount.id)}/save`, { method: 'POST', body: { kind: 'file', value: item.id, name: item.name, folder } });
    } else {
      await api('/api/export', { method: 'POST', body: { ids: [item.id], target: 'desktop', device: deviceLabel() } });
    }
    toast('已保存到电脑下载文件夹', 'ok');
    refreshBoot();
  } catch (error) { toast(error.message, 'err'); }
}

async function viewerReveal() {
  const item = viewerItem();
  if (!item) return;
  try {
    const info = await api(`/api/info?id=${encodeURIComponent(item.id)}`);
    if (info.path && window.xphoto) window.xphoto.reveal(info.path);
    else toast('当前环境不支持打开文件夹', 'err');
  } catch (error) { toast(error.message, 'err'); }
}

/* ---------------- modal ---------------- */
function openModal(name, data = null) {
  state.modal = name;
  state.modalData = data;
  renderModal();
}

function closeModal() {
  state.modal = '';
  state.modalData = null;
  const root = $('#modalRoot');
  if (root) root.innerHTML = '';
}

function modalShell(title, subtitle, body, foot = '', wide = false) {
  return `<div class="modal-backdrop" data-action="modal-backdrop">
    <div class="modal ${wide ? 'wide' : ''}" role="dialog" aria-modal="true" aria-label="${esc(title)}">
      <div class="modal-head"><div><h2>${esc(title)}</h2>${subtitle ? `<p>${subtitle}</p>` : ''}</div><button class="icon-btn" data-action="close-modal" aria-label="关闭">${ico('x')}</button></div>
      <div class="modal-body">${body}</div>
      ${foot ? `<div class="modal-foot">${foot}</div>` : ''}
    </div>
  </div>`;
}

function renderModal() {
  const root = $('#modalRoot');
  if (!root) return;
  if (!state.modal) { root.innerHTML = ''; return; }
  let html = '';
  if (state.modal === 'share') html = shareModal();
  else if (state.modal === 'add-cloud') html = cloudModal();
  else if (state.modal === 'add-remote') html = remoteModal();
  else if (state.modal === 'more') html = moreModal();
  else if (state.modal === 'android-folders') html = androidFoldersModal();
  else if (state.modal === 'search') html = searchModal();
  else if (state.modal === 'about') html = aboutModal();
  else if (state.modal === 'changelog') html = changelogModal();
  else if (state.modal === 'move') html = moveModal();
  else if (state.modal === 'location') html = locationModal();
  else if (state.modal === 'password') html = passwordModal();
  else if (state.modal === 'confirm') html = confirmModal();
  root.innerHTML = html;
  paintIcons(root);
  const tailscaleSwitch = root.querySelector('#tailscaleSwitch');
  if (tailscaleSwitch) tailscaleSwitch.addEventListener('change', toggleRemoteAccess);
  if (state.modal === 'share' && state.shareMode !== 'tailscale') loadQr();
  if (state.modal === 'search') setTimeout(() => { const input = $('#mobileSearchInput'); if (input) input.focus(); }, 60);
}

function shareModal() {
  const boot = state.boot;
  if (!boot) return '';
  const share = boot.share;
  const local = boot.isLocal;
  const mode = state.shareMode || 'lan';
  const url = share.primaryUrl || '';
  const ts = share.tailscale || {};
  const tsUrl = share.tailscaleUrl || '';
  const tabs = `<div class="type-tabs share-tabs">
    <button class="${mode === 'lan' ? 'active' : ''}" data-action="share-mode" data-mode="lan">${ico('wifi')} 局域网</button>
    <button class="${mode === 'tailscale' ? 'active' : ''}" data-action="share-mode" data-mode="tailscale">${ico('cloud')} Tailscale</button>
  </div>`;
  if (mode === 'tailscale') {
    const stateText = ts.installed
      ? (ts.online ? `已连接${ts.ip ? ` · ${ts.ip}` : ''}` : 'Tailscale 已安装，但尚未登录')
      : '未检测到 Tailscale';
    const body = `${tabs}<div class="share-info" style="margin-top:6px">
      <div class="ts-status ${ts.installed && ts.online ? 'ok' : ''}"><span class="dot"></span><b>${esc(stateText)}</b></div>
      ${ts.dnsName ? `<div class="share-url" style="margin-top:8px">${esc(ts.dnsName)}</div>` : ''}
      <div class="field-label" style="margin-top:14px">Tailscale 访问网址</div>
      <div class="share-url">${tsUrl ? esc(tsUrl) : '开启远程访问后会显示'}</div>
      <div class="share-actions">
        <button class="btn primary sm" data-action="copy-tailscale" ${tsUrl ? '' : 'disabled'}>${ico('copy')} 复制网址</button>
        <button class="btn soft sm" data-action="open-password">${ico('shield')} ${share.passwordSet ? '修改密码' : '设置密码'}</button>
        <button class="btn ghost sm" data-action="refresh-tailscale" ${state.tailscaleBusy ? 'disabled' : ''}>${ico('refresh')} 重新检测</button>
      </div>
      ${local ? `<div class="field" style="margin-top:14px"><div><div class="field-label">允许 Tailscale 远程访问</div><div class="field-desc">开启后，不在同一局域网也能访问；需要先设置密码。</div></div><label class="switch"><input type="checkbox" id="tailscaleSwitch" ${share.remoteAccess ? 'checked' : ''} ${share.passwordSet ? '' : 'disabled'}><span></span></label></div>` : ''}
      ${!share.passwordSet ? '<div class="form-hint danger-text">还没有设置访问密码。Tailscale 会把相册暴露到外网，必须先设置密码。</div>' : ''}
      <div class="share-steps">
        <b>怎么用：</b><br>
        1. 电脑和手机都安装 Tailscale，并登录同一个账号；<br>
        2. 电脑保持 xphoto 运行，打开上面的「允许 Tailscale 远程访问」；<br>
        3. 手机打开 Tailscale 访问网址，输入访问密码即可。<br>
        ${ts.installed ? '' : '电脑还没装 Tailscale，请先到 tailscale.com/download 安装。'}<br>
        <span class="muted">Tailscale 是加密虚拟局域网，不需要路由器端口映射。</span>
      </div>
    </div>`;
    return modalShell('手机连接 · Tailscale', '不在同一局域网时，用 Tailscale 加密连接这台电脑。', body, '', true);
  }
  const body = `${tabs}<div class="share-layout">
    <div class="qr-box ${share.enabled && local ? '' : 'off'}" id="qrBox"><img id="qrImage" alt="手机访问二维码" src="${state.qr || ''}">${!share.enabled ? '<div class="qr-off">局域网访问已关闭<br>开启后生成二维码</div>' : !local ? '<div class="qr-off">在电脑上查看二维码</div>' : ''}</div>
    <div class="share-info">
      <div class="field-label">手机访问网址</div>
      <div class="share-url">${url ? esc(url) : '尚未开启'}</div>
      <div class="share-actions">
        <button class="btn primary sm" data-action="copy-share" ${url ? '' : 'disabled'}>${ico('copy')} 一键复制</button>
        <button class="btn soft sm" data-action="firewall" ${local ? '' : 'disabled'}>${ico('shield')} 放行防火墙</button>
        <button class="btn ghost sm" data-action="rotate-token" ${local ? '' : 'disabled'}>${ico('refresh')} 重置口令</button>
      </div>
      ${local ? `<div class="field" style="margin-top:12px"><div><div class="field-label">开启局域网访问</div><div class="field-desc">关闭后所有手机和其他电脑都无法连接</div></div><label class="switch"><input type="checkbox" id="shareSwitch" ${share.enabled ? 'checked' : ''}><span></span></label></div>` : ''}
      <div class="share-steps">
        <b>手机怎么用：</b><br>
        1. 手机和电脑连同一个 Wi-Fi；<br>
        2. 手机浏览器打开上面的网址（或扫描二维码）；<br>
        3. 浏览器菜单选「添加到主屏幕」，以后像 App 一样打开。<br>
        ${local ? '如果打不开，点「放行防火墙」，在 Windows 弹窗里选「是」。' : ''}
      </div>
    </div>
  </div>`;
  return modalShell('手机连接 · 局域网', '同一 Wi-Fi 下，手机无需安装 App，浏览器直接打开。', body, '', true);
}

function passwordModal() {
  const set = Boolean(state.boot && state.boot.share && state.boot.share.passwordSet);
  const body = `<form id="passwordForm">
    <div class="form-hint" style="margin-bottom:14px">Tailscale 会把相册暴露到外网，访问密码至少 6 位，只保存在这台电脑上。</div>
    <div class="form-row"><label class="form-label">${set ? '新密码' : '访问密码'}</label><input name="password" type="password" autocomplete="new-password" placeholder="至少 6 位" maxlength="64"></div>
    <div class="form-row"><label class="form-label">再输一次</label><input name="confirm" type="password" autocomplete="new-password" placeholder="确认密码" maxlength="64"></div>
    <div id="passwordMsg" class="form-hint" style="color:#d83a52"></div>
  </form>`;
  const foot = `<button class="btn ghost" data-action="close-modal">取消</button><button class="btn primary" data-action="save-password">${ico('shield')} ${set ? '保存新密码' : '设置密码'}</button>`;
  return modalShell(set ? '修改访问密码' : '设置访问密码', '手机通过 Tailscale 连接时需要输入这个密码。', body, foot, true);
}

function androidFoldersModal() {
  const pinned = new Set(state.localPinned);
  const rows = state.localFolders.map((folder) => `<label class="android-folder-row">
    <input type="checkbox" data-local-pin="${esc(folder.id)}" ${pinned.has(folder.id) ? 'checked' : ''}>
    <span class="af-cover">${folder.cover ? `<img src="${esc(androidMedia(folder.cover, 120))}" alt="">` : ico('folder')}</span>
    <span class="af-body"><b>${esc(folder.name)}</b><small>${folder.count} 张照片</small></span>
    <span class="af-check">${ico('check')}</span>
  </label>`).join('');
  return modalShell('添加手机文件夹',
    '勾选后显示在左侧「手机本机」和相册页。照片只留在这台手机上，不会上传。',
    rows ? `<div class="android-folder-list">${rows}</div>` : emptyState('folder', '手机里还没有照片', '拍几张照片，或在系统相册里保存图片，再回来刷新。'),
    `<button class="btn primary" data-action="close-modal">完成</button>`);
}

function cloudModal() {
  const is123 = state.cloudFormType === '123';
  const body = `<div class="type-tabs">
      <button class="${is123 ? 'active' : ''}" data-action="cloud-tab" data-type="123">${ico('cloud')} 123云盘</button>
      <button class="${!is123 ? 'active' : ''}" data-action="cloud-tab" data-type="webdav">${ico('disk')} WebDAV</button>
    </div>
    <form id="cloudForm">
      <div class="form-row"><label class="form-label">显示名称</label><input name="name" placeholder="${is123 ? '例如：我的 123 云盘' : '例如：坚果云 / NAS'}" maxlength="40"></div>
      ${is123 ? `
        <div class="form-row"><label class="form-label">clientID</label><input name="clientID" placeholder="123云盘开放平台 clientID" autocomplete="off"></div>
        <div class="form-row"><label class="form-label">clientSecret</label><input name="clientSecret" type="password" placeholder="123云盘开放平台 clientSecret" autocomplete="off"></div>
        <div class="form-hint">在 123云盘开放平台开通「开发者权益包」后，clientID / clientSecret 会通过站内信发放。密钥只会保存在这台电脑。</div>
      ` : `
        <div class="form-row"><label class="form-label">服务器地址</label><input name="url" placeholder="https://dav.jianguoyun.com/dav/" autocomplete="off"></div>
        <div class="form-row"><label class="form-label">用户名</label><input name="username" placeholder="WebDAV 用户名 / 邮箱" autocomplete="username"></div>
        <div class="form-row"><label class="form-label">密码 / 应用密码</label><input name="password" type="password" placeholder="建议使用应用密码" autocomplete="current-password"></div>
        <div class="form-hint">坚果云请用「第三方应用管理」生成的应用密码；Nextcloud 路径通常是 /remote.php/dav/files/用户名/；AList 需在权限里开启 Webdav Read。</div>
      `}
      <div id="cloudFormMsg"></div>
    </form>`;
  const foot = `<button class="btn ghost" data-action="close-modal">取消</button><button class="btn soft" data-action="test-cloud">测试连接</button><button class="btn primary" data-action="save-cloud">${ico('link')} 连接云盘</button>`;
  return modalShell('连接云盘', '手机和电脑共用这个云盘连接，图片由电脑代理读取。', body, foot, true);
}

function remoteModal() {
  const body = `<form id="remoteForm">
    <div class="form-row"><label class="form-label">对方电脑显示的网址</label><input name="url" placeholder="http://192.168.1.8:18573/?t=..." autocomplete="off"></div>
    <div class="form-row"><label class="form-label">备注名称（可选）</label><input name="name" placeholder="例如：客厅电脑" maxlength="30"></div>
    <div class="form-hint">在对方电脑的 xphoto 里点「手机连接」→「一键复制」，把完整网址粘贴到这里。需要两台电脑在同一个局域网，并且对方已开启局域网访问。</div>
    <div id="remoteFormMsg"></div>
  </form>`;
  const foot = `<button class="btn ghost" data-action="close-modal">取消</button><button class="btn primary" data-action="save-remote">${ico('link')} 添加并连接</button>`;
  return modalShell('添加其他电脑', '输入对方 xphoto 显示的网址，即可浏览对方电脑上的相册。', body, foot, true);
}

function moreModal() {
  const items = [
    ['cloud', 'cloud', '连接云盘', '123云盘 / WebDAV', 'nav'],
    ['devices', 'devices', '其他电脑', '通过局域网查看', 'nav'],
    ['mine', 'settings', '设置', '外观、存储与关于', 'nav'],
    ['refresh', 'refresh', '刷新', '重新扫描照片', 'refresh']
  ];
  if (!isMobile()) items.splice(2, 0, ['share', 'smartphone', '手机连接', '网址与二维码', 'open-share']);
  if (!isMobile()) items.splice(items.length - 2, 0, ['downloads', 'download-cloud', '下载记录', '查看保存的照片', 'nav']);
  if (ANDROID) {
    items.unshift(
      ['local', 'photos', '手机相册', '查看本机照片', 'android-local'],
      ['localTrash', 'trash', '手机回收站', '清空后才真正删除', 'nav'],
      ['trash', 'trash', '电脑回收站', '手机删除的电脑照片', 'nav'],
      ['addlocal', 'plus', '添加手机文件夹', '选择要显示的相册', 'android-add-folder'],
      ['clearcache', 'refresh', '清理手机缓存', '释放预览占用，不删照片', 'clear-image-cache'],
      ['disconnect', 'power', '断开电脑连接', '回到手机本机相册', 'android-disconnect']
    );
  } else if (isMobile()) {
    items.splice(2, 0, ['clearcache', 'refresh', '清理手机缓存', '释放预览占用，不删照片', 'clear-image-cache']);
  }
  const body = `<div class="menu-list">${items.map(([key, icon, title, sub, action]) => `<button class="menu-item" data-action="${action}" data-nav="${action === 'nav' ? key : ''}">${ico(icon)}<span><span style="display:block">${title}</span><span style="display:block;font-size:10.5px;color:var(--text-3);margin-top:2px">${sub}</span></span>${ico('chevron-right', 'chev')}</button>`).join('')}</div>`;
  return modalShell('更多', '', body, '', false);
}

function searchModal() {
  const body = `<form id="mobileSearchForm"><div class="form-row"><label class="form-label">搜索照片</label><input id="mobileSearchInput" name="q" type="search" placeholder="文件名、相册或文件夹" value="${esc(state.route.q || '')}"></div><div class="form-hint">在已添加的文件夹中搜索。</div></form>`;
  const foot = `<button class="btn ghost" data-action="close-modal">取消</button><button class="btn primary" data-action="submit-search">${ico('search')} 搜索</button>`;
  return modalShell('搜索', '', body, foot);
}

function aboutModal() {
  const boot = state.boot;
  const body = `<div style="text-align:center;padding:4px 0 8px"><img src="/icons/icon-192.png" alt="" style="width:76px;height:76px;border-radius:22px;margin:0 auto 12px;box-shadow:var(--shadow-md)"><h3 style="font-size:17px;font-weight:680">xphoto</h3><p style="font-size:11.5px;color:var(--text-3);margin-top:4px">版本 ${esc(boot ? boot.version : '1.6.6')} · 电脑 + 手机 局域网相册</p></div>
    <div class="field"><div><div class="field-label">电脑端</div><div class="field-desc">Electron 桌面应用，关闭窗口后仍在托盘运行，手机可继续访问</div></div><span class="field-value">Windows</span></div>
    <div class="field"><div><div class="field-label">手机端</div><div class="field-desc">${ANDROID ? '原生相册 + 局域网连接电脑，下载的照片自动进入「手机下载」' : '响应式网页 / PWA，可添加到主屏幕，也可以安装 APK'}</div></div><span class="field-value">v${ANDROID && window.XPhotoAndroid.version ? window.XPhotoAndroid.version() : '1.6.6'}</span></div>
    <div class="field"><div><div class="field-label">设计参考</div><div class="field-desc">Microsoft Photos 的时间线与信息面板 + 小米相册的移动端网格与三菜单</div></div><span class="field-value">致敬</span></div>
    <div class="form-hint" style="text-align:center;margin-top:14px">照片只在你自己的设备之间传输，不经过任何服务器。</div>`;
  return modalShell('关于 xphoto', '', body, '<button class="btn ghost" data-action="changelog">更新公告</button><button class="btn primary" data-action="close-modal">知道了</button>');
}

function changelogModal() {
  const body = `<div class="changelog">${CHANGELOG.map(([version, tag, items]) => `
    <section class="cl-item">
      <div class="cl-head"><span class="cl-version">v${esc(version)}</span>${tag ? `<span class="cl-tag">${esc(tag)}</span>` : ''}</div>
      <ul>${items.map((item) => `<li>${esc(item)}</li>`).join('')}</ul>
    </section>`).join('')}</div>`;
  return modalShell('更新公告', '从最新到最早，记录 xphoto 每次版本变化。', body, '<button class="btn primary" data-action="close-modal">知道了</button>');
}

function confirmModal() {
  const data = state.confirm || {};
  const body = `<p style="font-size:12.5px;line-height:1.7;color:var(--text-2)">${data.body || ''}</p>`;
  return modalShell(data.title || '确认操作', '', body, `<button class="btn ghost" data-action="confirm-cancel">取消</button><button class="btn ${data.danger ? 'danger' : 'primary'}" data-action="confirm-ok">${esc(data.ok || '确定')}</button>`);
}

function askConfirm(options) {
  return new Promise((resolve) => {
    state.confirm = { ...options, resolve };
    openModal('confirm');
  });
}

function settleConfirm(value) {
  const confirm = state.confirm;
  state.confirm = null;
  closeModal();
  if (confirm && confirm.resolve) confirm.resolve(value);
}

async function loadQr() {
  if (!state.boot || !state.boot.isLocal) return;
  const img = $('#qrImage');
  if (!img) return;
  if (state.qr) { img.src = state.qr; return; }
  if (state.qrLoading) return;
  state.qrLoading = true;
  try {
    const data = await api('/api/share/qr');
    state.qr = data.dataUrl || '';
    const current = $('#qrImage');
    if (current && state.qr) current.src = state.qr;
  } catch {} finally { state.qrLoading = false; }
}

/* ---------------- share actions ---------------- */
async function toggleShare() {
  if (!state.boot || !state.boot.isLocal) return;
  const enabled = !state.boot.share.enabled;
  try {
    const data = await api('/api/share', { method: 'POST', body: { enabled } });
    state.boot.share = { ...state.boot.share, ...data };
    state.qr = '';
    renderShell();
    if (state.modal === 'share') renderModal();
    if (state.route.name === 'mine') renderContent();
    toast(enabled ? '局域网访问已开启' : '局域网访问已关闭', 'ok');
  } catch (error) { toast(error.message, 'err'); }
}

async function copyShare() {
  const url = state.boot && state.boot.share.primaryUrl;
  if (!url) return toast('请先开启局域网访问', 'err');
  const ok = await copyText(url);
  toast(ok ? '手机访问网址已复制' : '复制失败，请长按网址手动复制', ok ? 'ok' : 'err');
}

async function copyTailscale() {
  const url = state.boot && state.boot.share.tailscaleUrl;
  if (!url) return toast('请先开启 Tailscale 远程访问', 'err');
  const ok = await copyText(url);
  toast(ok ? 'Tailscale 网址已复制' : '复制失败，请长按网址手动复制', ok ? 'ok' : 'err');
}

async function refreshTailscale() {
  state.tailscaleBusy = true;
  renderModal();
  try {
    const data = await api('/api/network');
    state.boot.share = { ...state.boot.share, ...data };
    toast(data.tailscale && data.tailscale.installed ? 'Tailscale 状态已更新' : '仍未检测到 Tailscale', data.tailscale && data.tailscale.installed ? 'ok' : 'err');
  } catch (error) {
    toast(error.message, 'err');
  } finally {
    state.tailscaleBusy = false;
    if (state.modal === 'share') renderModal();
  }
}

async function toggleRemoteAccess() {
  if (!state.boot || !state.boot.isLocal) return;
  const input = $('#tailscaleSwitch');
  if (!input) return;
  if (input.checked && !state.boot.share.passwordSet) {
    input.checked = false;
    toast('请先设置访问密码', 'err');
    openModal('password');
    return;
  }
  try {
    const data = await api('/api/share', { method: 'POST', body: { remoteAccess: input.checked } });
    state.boot.share = { ...state.boot.share, ...data };
    renderModal();
    toast(input.checked ? 'Tailscale 远程访问已开启' : 'Tailscale 远程访问已关闭', 'ok');
  } catch (error) {
    input.checked = !input.checked;
    toast(error.message, 'err');
  }
}

async function savePassword() {
  const form = $('#passwordForm');
  if (!form) return;
  const values = new FormData(form);
  const password = String(values.get('password') || '');
  const confirm = String(values.get('confirm') || '');
  const msg = $('#passwordMsg');
  if (password.length < 6) { if (msg) msg.textContent = '密码至少 6 位'; return; }
  if (password !== confirm) { if (msg) msg.textContent = '两次输入的密码不一致'; return; }
  try {
    await api('/api/security/password', { method: 'POST', body: { password } });
    state.boot.share = { ...state.boot.share, passwordSet: true };
    toast('访问密码已保存', 'ok');
    openModal('share');
  } catch (error) {
    if (msg) msg.textContent = error.message;
  }
}

async function rotateToken() {
  const ok = await askConfirm({ title: '重置访问口令？', body: '重置后旧网址和旧二维码会立即失效，已经连接的手机需要重新扫码。', ok: '重置口令', danger: true });
  if (!ok) return;
  try {
    const data = await api('/api/share', { method: 'POST', body: { rotate: true } });
    state.boot.share = { ...state.boot.share, ...data };
    state.qr = '';
    renderShell();
    renderModal();
    toast('口令已重置，请重新扫码', 'ok');
  } catch (error) { toast(error.message, 'err'); }
}

async function openFirewall() {
  if (!state.boot || !state.boot.isLocal) return toast('请在这台电脑上操作', 'err');
  try {
    const data = await api('/api/network/firewall', { method: 'POST' });
    toast(data.message || '已请求 Windows 放行', 'ok');
  } catch (error) { toast(error.message, 'err'); }
}

/* ---------------- cloud actions ---------------- */
async function loadClouds() {
  try {
    const data = await api('/api/clouds');
    state.clouds = data.clouds || [];
    if (state.boot) state.boot.clouds = state.clouds;
    renderContent();
  } catch (error) { toast(error.message, 'err'); }
}

async function openCloud(id) {
  const cloud = state.clouds.find((item) => item.id === id);
  if (!cloud) return;
  state.cloudAccount = cloud;
  state.cloudPath = [{ name: '根目录', value: cloudRootValue(cloud) }];
  state.cloudData = null;
  navigate('cloudBrowse', {}, { noLoad: true });
  await loadCloud();
}

async function loadCloud() {
  const cloud = state.cloudAccount;
  if (!cloud) return;
  state.cloudLoading = true;
  state.cloudError = '';
  renderContent();
  try {
    const folder = state.cloudPath.length ? state.cloudPath[state.cloudPath.length - 1].value : cloudRootValue(cloud);
    const data = await api(`/api/clouds/${encodeURIComponent(cloud.id)}/list?folder=${encodeURIComponent(folder)}`);
    state.cloudData = data;
  } catch (error) {
    state.cloudError = error.message;
  } finally {
    state.cloudLoading = false;
    renderContent();
  }
}

async function deleteCloud(id) {
  const cloud = state.clouds.find((item) => item.id === id);
  const ok = await askConfirm({ title: '移除这个云盘？', body: `将从 xphoto 中移除「${cloud ? cloud.name : '云盘'}」，不会删除云盘里的任何文件。`, ok: '移除', danger: true });
  if (!ok) return;
  try {
    await api(`/api/clouds/${encodeURIComponent(id)}`, { method: 'DELETE' });
    toast('已移除云盘', 'ok');
    await refreshBoot();
    if (state.route.name === 'cloudBrowse') navigate('cloud', {}, { replace: true });
    else loadClouds();
  } catch (error) { toast(error.message, 'err'); }
}

async function submitCloud(testOnly = false) {
  const form = $('#cloudForm');
  if (!form) return;
  const values = Object.fromEntries(new FormData(form).entries());
  const msg = $('#cloudFormMsg');
  const payload = { ...values, type: state.cloudFormType };
  if (!testOnly && !String(values.name || '').trim()) payload.name = state.cloudFormType === '123' ? '123云盘' : 'WebDAV 云盘';
  try {
    if (msg) msg.innerHTML = '<div class="form-ok">正在连接，请稍候…</div>';
    if (testOnly) {
      const result = await api('/api/clouds/test', { method: 'POST', body: payload });
      if (msg) msg.innerHTML = `<div class="form-ok">${esc(result.message || '连接成功')}</div>`;
      toast('连接成功', 'ok');
      return;
    }
    const data = await api('/api/clouds', { method: 'POST', body: payload });
    toast('云盘已连接', 'ok');
    closeModal();
    await refreshBoot();
    if (data.cloud) openCloud(data.cloud.id);
    else navigate('cloud');
  } catch (error) {
    if (msg) msg.innerHTML = `<div class="form-error">${esc(error.message)}</div>`;
  }
}

/* ---------------- remote actions ---------------- */
async function loadRemote(device) {
  if (!device) return;
  state.remoteLoading = true;
  state.remoteError = '';
  state.remoteState = null;
  renderContent();
  try {
    const data = await remoteApi(device, '/api/state');
    state.remoteState = data;
    if (data.deviceName && !device.name) device.name = data.deviceName;
  } catch (error) {
    state.remoteError = error.message;
  } finally {
    state.remoteLoading = false;
    renderContent();
  }
}

async function openRemote(id) {
  const device = state.remotes.find((item) => item.id === id);
  if (!device) return;
  navigate('remote', { remote: device }, { noLoad: true });
  await loadRemote(device);
}

async function loadRemoteAlbum(album) {
  const device = state.route.remote;
  if (!device) return;
  state.remoteLoading = true;
  state.remoteError = '';
  state.remotePhotos = [];
  renderContent();
  try {
    const query = new URLSearchParams({ limit: '300' });
    if (album && album.id) query.set('albumId', album.id);
    const data = await remoteApi(device, `/api/photos?${query.toString()}`);
    state.remotePhotos = data.items || [];
  } catch (error) {
    state.remoteError = error.message;
  } finally {
    state.remoteLoading = false;
    renderContent();
  }
}

async function saveRemote() {
  const form = $('#remoteForm');
  const msg = $('#remoteFormMsg');
  if (!form) return;
  const values = Object.fromEntries(new FormData(form).entries());
  let parsed;
  try { parsed = parseRemoteUrl(values.url); } catch (error) {
    if (msg) msg.innerHTML = `<div class="form-error">${esc(error.message)}</div>`;
    return;
  }
  if (!parsed.token) {
    if (msg) msg.innerHTML = '<div class="form-error">网址里缺少访问口令。请复制对方电脑上完整的一键复制网址（包含 ?t=...）。</div>';
    return;
  }
  if (msg) msg.innerHTML = '<div class="form-ok">正在连接对方电脑…</div>';
  const device = {
    id: `remote-${Date.now().toString(36)}`,
    name: String(values.name || '').trim(),
    base: parsed.base,
    token: parsed.token,
    addedAt: Date.now()
  };
  try {
    const data = await remoteApi(device, '/api/state');
    device.name = device.name || data.deviceName || new URL(device.base).hostname;
    state.remotes = state.remotes.filter((item) => item.base !== device.base);
    state.remotes.push(device);
    saveRemotes();
    toast(`已连接 ${device.name}`, 'ok');
    closeModal();
    navigate('remote', { remote: device }, { noLoad: true });
    await loadRemote(device);
  } catch (error) {
    if (msg) msg.innerHTML = `<div class="form-error">${esc(error.message)}</div>`;
  }
}

async function removeRemote(id) {
  const device = state.remotes.find((item) => item.id === id);
  const ok = await askConfirm({ title: '移除这台电脑？', body: `只会从列表移除「${device ? device.name : '其他电脑'}」，不会影响对方。`, ok: '移除', danger: true });
  if (!ok) return;
  state.remotes = state.remotes.filter((item) => item.id !== id);
  saveRemotes();
  renderContent();
  toast('已移除', 'ok');
}

/* ---------------- misc actions ---------------- */
async function addFolders() {
  if (!state.boot || !state.boot.isLocal) return toast('添加文件夹只能在电脑上操作', 'err');
  try {
    let paths = [];
    if (window.xphoto && window.xphoto.pickFolders) {
      paths = await window.xphoto.pickFolders();
      for (const path of paths || []) {
        await api('/api/roots', { method: 'POST', body: { path } });
      }
    } else {
      const data = await api('/api/roots/browse', { method: 'POST' });
      paths = data.folders || [];
    }
    if (!paths.length) return;
    toast(`已添加 ${paths.length} 个文件夹，正在扫描…`, 'ok');
    await refreshBoot(false);
    await navigate('photos', {}, { replace: true });
  } catch (error) { toast(error.message, 'err'); }
}

async function removeRoot(id, name) {
  const ok = await askConfirm({ title: '移除此文件夹？', body: `只是从 xphoto 移除「${name}」，电脑上的原文件不会被删除。`, ok: '移除', danger: true });
  if (!ok) return;
  try {
    await api(`/api/roots/${encodeURIComponent(id)}`, { method: 'DELETE' });
    await refreshBoot();
    if (state.route.rootId === id) navigate('photos', {}, { replace: true });
    else renderShell();
    toast('已移除文件夹', 'ok');
  } catch (error) { toast(error.message, 'err'); }
}

async function changeDownloadDir() {
  if (!window.xphoto || !window.xphoto.pickFolder) return toast('当前环境不支持选择文件夹', 'err');
  try {
    const dir = await window.xphoto.pickFolder();
    if (!dir) return;
    const data = await api('/api/settings', { method: 'PATCH', body: { downloadDir: dir } });
    if (state.boot) state.boot.settings = data.settings;
    await refreshBoot();
    renderContent();
    toast('下载文件夹已更新', 'ok');
  } catch (error) { toast(error.message, 'err'); }
}

async function openDownloads() {
  if (window.xphoto && window.xphoto.openDownloads) {
    await window.xphoto.openDownloads();
    return;
  }
  if (!state.boot || !state.boot.isLocal) return toast('请在这台电脑上打开下载文件夹', 'err');
  try { await api('/api/open', { method: 'POST', body: { kind: 'download' } }); }
  catch (error) { toast(error.message, 'err'); }
}

async function loadCacheInfo() {
  if (!state.boot || !state.boot.isLocal) return;
  try {
    const data = await api('/api/cache');
    state.cacheBytes = data.bytes || 0;
    state.cacheFiles = data.files || 0;
    if (state.route.name === 'mine') renderContent();
  } catch {}
}

async function clearCache() {
  try {
    const data = await api('/api/cache/clear', { method: 'POST' });
    state.cacheBytes = 0;
    state.cacheFiles = 0;
    toast(`已清理 ${data.removed || 0} 个缩略图缓存`, 'ok');
    renderContent();
  } catch (error) { toast(error.message, 'err'); }
}

async function loadDownloads() {
  try {
    const data = await api('/api/downloads');
    state.downloads = data.items || [];
    renderContent();
  } catch (error) { toast(error.message, 'err'); }
}

function applyGridSize(value, { persist = true, render = false } = {}) {
  const next = Math.min(8, Math.max(2, Number(value) || 5));
  state.gridSize = next;
  document.documentElement.style.setProperty('--grid-cols', String(next));
  const label = $('.grid-count');
  if (label) label.textContent = `${next} 列`;
  localStorage.setItem(LS.grid, String(next));
  if (persist) {
    clearTimeout(state.gridTimer);
    state.gridTimer = setTimeout(() => {
      api('/api/settings', { method: 'PATCH', body: { gridSize: next } }).catch(() => {});
    }, 420);
  }
  if (render) renderContent();
}

function changeGrid(delta = 1) {
  const next = state.gridSize >= 8 ? 2 : state.gridSize < 2 ? 8 : state.gridSize + delta;
  applyGridSize(next, { render: true });
}

function applyMobileGrid(value) {
  const next = Math.min(8, Math.max(2, Number(value) || 3));
  state.mobileGrid = next;
  document.documentElement.style.setProperty('--mobile-cols', String(next));
  localStorage.setItem(LS.mobileGrid, String(next));
}

function setSort(sort) {
  state.sort = sort;
  api('/api/settings', { method: 'PATCH', body: { sort } }).catch(() => {});
  if (['photos', 'favorites', 'recent', 'album', 'root'].includes(state.route.name)) {
    state.photos = [];
    renderContent();
    loadPhotos(false);
  } else if (state.route.name === 'mine') {
    renderContent();
  }
}

function search(value) {
  const q = String(value || '').trim();
  if (!q) {
    navigate('photos', {}, { replace: true });
    return;
  }
  navigate('photos', { q }, { replace: true });
}

/* ---------------- gate ---------------- */
function showGate(message, needPassword = false) {
  const root = $('#gateRoot');
  if (!root) return;
  if (!needPassword) {
    root.innerHTML = `<div class="gate"><div class="gate-card">
      <img src="/icons/icon-192.png" alt="xphoto">
      <h2>需要访问口令</h2>
      <p>${esc(message || '这个相册开启了局域网保护。请扫描电脑上 xphoto 显示的二维码，或粘贴带口令的完整网址。')}</p>
      <form id="gateForm"><input name="token" placeholder="粘贴访问口令" autocomplete="off" spellcheck="false"><button class="btn primary" type="submit">进入相册</button></form>
      <p style="font-size:10.5px;margin-top:12px">口令可以在电脑端「手机连接」里重置。</p>
    </div></div>`;
    paintIcons(root);
    const form = $('#gateForm');
    if (form) form.addEventListener('submit', (event) => {
      event.preventDefault();
      const token = String(new FormData(form).get('token') || '').trim();
      if (!token) return;
      state.token = token;
      localStorage.setItem(LS.token, token);
      root.innerHTML = '';
      boot();
    });
    return;
  }
  root.innerHTML = `<div class="gate"><div class="gate-card">
    <img src="/icons/icon-192.png" alt="xphoto">
    <h2>输入访问密码</h2>
    <p>${esc(message || '这台电脑开启了 Tailscale 远程访问。请输入电脑上设置的 xphoto 访问密码。')}</p>
    <form id="gateForm"><input name="password" type="password" placeholder="xphoto 访问密码" autocomplete="current-password"><button class="btn primary" type="submit">进入相册</button></form>
    <p id="gateMsg" style="font-size:10.5px;margin-top:12px;color:#d83a52"></p>
  </div></div>`;
  paintIcons(root);
  const form = $('#gateForm');
  if (form) form.addEventListener('submit', async (event) => {
    event.preventDefault();
    const password = String(new FormData(form).get('password') || '');
    const msg = $('#gateMsg');
    if (!password) return;
    try {
      const response = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'same-origin',
        body: JSON.stringify({ password })
      });
      const data = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(data.error || '密码不正确');
      root.innerHTML = '';
      boot();
    } catch (error) {
      if (msg) msg.textContent = error.message || '登录失败';
    }
  });
}

/* ---------------- events ---------------- */
document.addEventListener('click', async (event) => {
  const el = event.target.closest('[data-action]');
  if (!el) return;
  if (el.classList.contains('modal-backdrop') && event.target !== el) return;
  const action = el.dataset.action;
  const id = el.dataset.id;
  if (state.suppressClick && (action === 'photo' || action === 'local-photo')) {
    state.suppressClick = false;
    return;
  }
  switch (action) {
    case 'nav': navigate(el.dataset.nav || 'photos', {}, { replace: true }); break;
    case 'open-root': {
      const root = rootById(id);
      navigate('root', { rootId: id }, { replace: true });
      break;
    }
    case 'open-album': {
      const album = (state.boot.albums || []).find((item) => item.id === id);
      if (album) navigate('album', { album }, {});
      break;
    }
    case 'toggle-album-group': {
      const key = el.dataset.key || '';
      const body = el.parentElement && el.parentElement.querySelector('.album-group-body');
      const collapsed = !body || body.hidden;
      if (body) body.hidden = !collapsed;
      el.setAttribute('aria-expanded', String(collapsed));
      const caret = el.querySelector('.ag-caret');
      if (caret) caret.classList.toggle('collapsed', !collapsed);
      const index = state.albumCollapsed.indexOf(key);
      if (collapsed && index >= 0) state.albumCollapsed.splice(index, 1);
      if (!collapsed && index < 0) state.albumCollapsed.push(key);
      try { localStorage.setItem(LS.albumCollapsed, JSON.stringify(state.albumCollapsed)); } catch {}
      break;
    }
    case 'android-local': {
      const folderId = el.dataset.id || 'all';
      if (folderId === 'all') navigate('local', { folderId: 'all' }, {});
      else navigate('localFolder', { folderId, folderName: localFolderName(folderId) }, {});
      break;
    }
    case 'android-local-folder': navigate('localFolder', { folderId: id, folderName: el.dataset.name || '' }, {}); break;
    case 'android-local-trash': navigate('localTrash', {}, {}); break;
    case 'empty-local-trash': emptyLocalTrash(); break;
    case 'android-add-folder': openModal('android-folders'); break;
    case 'android-disconnect':
      if (ANDROID && window.XPhotoAndroid && typeof window.XPhotoAndroid.disconnect === 'function') {
        closeModal();
        window.XPhotoAndroid.disconnect();
      } else {
        toast('当前环境不支持断开电脑', 'err');
      }
      break;
    case 'local-photo': {
      if (state.selecting) { toggleSelection(id); break; }
      const index = state.localPhotos.findIndex((item) => item.id === id);
      if (index < 0) break;
      const item = state.localPhotos[index];
      if (isVideoItem(item) && ANDROID && window.XPhotoAndroid.playVideo) {
        window.XPhotoAndroid.playVideo(item.uri, item.name);
        break;
      }
      openViewer(state.localPhotos, index, { source: 'android' });
      break;
    }
    case 'photo': {
      if (state.selecting) { toggleSelection(id); break; }
      const index = state.photos.findIndex((item) => item.id === id);
      if (index < 0) break;
      const item = state.photos[index];
      if (isVideoItem(item) && ANDROID && window.XPhotoAndroid && window.XPhotoAndroid.playVideo) {
        window.XPhotoAndroid.playVideo(absoluteUrl(localImage(item.id)), item.name);
        break;
      }
      openViewer(state.photos, index, { source: 'local' });
      break;
    }
    case 'fav-tile': {
      const item = state.photos.find((entry) => entry.id === id);
      if (item) toggleFavorite(item);
      break;
    }
    case 'select-mode': toggleSelectMode(); break;
    case 'cancel-select':
      state.selecting = false; state.selected.clear(); renderContent(); renderMobileTopbar(); break;
    case 'select-all': {
      const pool = isPhoneLocalRoute() ? state.localPhotos : state.photos;
      if (state.selected.size === pool.length) state.selected.clear();
      else pool.forEach((item) => state.selected.add(item.id));
      renderContent(); break;
    }
    case 'select-date': selectDateGroup(Number(el.dataset.group || 0)); break;
    case 'download-selected': downloadSelected(); break;
    case 'save-selected': saveSelectedToPC(); break;
    case 'fav-selected': favoriteSelected(); break;
    case 'move-selected': moveSelected(); break;
    case 'share-selected': shareSelected(); break;
    case 'reveal-selected': revealSelected(); break;
    case 'location-selected': locationSelected(); break;
    case 'copy-location': copyLocation(); break;
    case 'move-to': moveToAlbum(id); break;
    case 'trash-selected': trashSelected(); break;
    case 'refresh-trash': loadTrash(); break;
    case 'empty-trash': emptyTrash(); break;
    case 'viewer-trash': trashViewerItem(); break;
    case 'load-more': loadPhotos(true); break;
    case 'retry-photos': loadPhotos(false); break;
    case 'sort': setSort(el.dataset.sort); break;
    case 'cycle-grid': changeGrid(); break;
    case 'refresh':
      closeModal();
      state.qr = '';
      await refreshBoot(false);
      if (['photos', 'favorites', 'recent', 'album', 'root'].includes(state.route.name)) { state.photos = []; await loadPhotos(false); }
      else loadRoute();
      toast('已刷新', 'ok');
      break;
    case 'retry-boot': boot(); break;
    case 'add-folder': addFolders(); break;
    case 'remove-root': removeRoot(id, el.dataset.name); break;
    case 'open-share': openModal('share'); break;
    case 'copy-share': await copyShare(); break;
    case 'firewall': await openFirewall(); break;
    case 'rotate-token': await rotateToken(); break;
    case 'share-mode':
      state.shareMode = el.dataset.mode === 'tailscale' ? 'tailscale' : 'lan';
      renderModal();
      if (state.shareMode === 'lan') loadQr();
      break;
    case 'copy-tailscale': await copyTailscale(); break;
    case 'refresh-tailscale': await refreshTailscale(); break;
    case 'open-password': openModal('password'); break;
    case 'save-password': await savePassword(); break;
    case 'close-modal': closeModal(); break;
    case 'modal-backdrop': closeModal(); break;
    case 'cloud-tab': state.cloudFormType = el.dataset.type === 'webdav' ? 'webdav' : '123'; renderModal(); break;
    case 'test-cloud': submitCloud(true); break;
    case 'save-cloud': submitCloud(false); break;
    case 'add-cloud': openModal('add-cloud'); break;
    case 'open-cloud': await openCloud(id); break;
    case 'delete-cloud': await deleteCloud(id); break;
    case 'cloud-folder': {
      state.cloudPath = state.cloudPath.slice(0, state.cloudPath.findIndex((item) => item.value === id) + 1);
      if (!state.cloudPath.length) state.cloudPath = [{ name: '根目录', value: cloudRootValue(state.cloudAccount) }];
      await loadCloud();
      break;
    }
    case 'cloud-crumb': {
      const index = Number(el.dataset.index);
      if (Number.isFinite(index)) { state.cloudPath = state.cloudPath.slice(0, index + 1); await loadCloud(); }
      break;
    }
    case 'cloud-refresh': await loadCloud(); break;
    case 'cloud-photo': {
      const files = (state.cloudData && state.cloudData.files) || [];
      const index = files.findIndex((item) => item.id === id);
      if (index < 0) break;
      const item = files[index];
      if (isVideoItem(item) && ANDROID && window.XPhotoAndroid && window.XPhotoAndroid.playVideo && state.cloudAccount) {
        window.XPhotoAndroid.playVideo(absoluteUrl(cloudRaw(state.cloudAccount, item)), item.name);
        break;
      }
      openViewer(files, index, { source: 'cloud' });
      break;
    }
    case 'add-remote': openModal('add-remote'); break;
    case 'save-remote': await saveRemote(); break;
    case 'open-remote': await openRemote(id); break;
    case 'remove-remote': await removeRemote(id); break;
    case 'remote-album': {
      const album = (state.remoteState && state.remoteState.albums || []).find((item) => item.id === id);
      if (album) { navigate('remoteAlbum', { remote: state.route.remote, remoteAlbum: album }, { noLoad: true }); await loadRemoteAlbum(album); }
      break;
    }
    case 'remote-all': {
      navigate('remoteAlbum', { remote: state.route.remote, remoteAlbum: { name: '全部照片', count: state.remoteState ? state.remoteState.totalPhotos : 0 } }, { noLoad: true });
      await loadRemoteAlbum(null);
      break;
    }
    case 'remote-photo': {
      const index = state.remotePhotos.findIndex((item) => item.id === id);
      if (index < 0) break;
      const item = state.remotePhotos[index];
      if (isVideoItem(item) && ANDROID && window.XPhotoAndroid && window.XPhotoAndroid.playVideo && state.route.remote) {
        window.XPhotoAndroid.playVideo(absoluteUrl(remoteImage(state.route.remote, item.id)), item.name);
        break;
      }
      openViewer(state.remotePhotos, index, { source: 'remote' });
      break;
    }
    case 'remote-refresh':
      if (state.route.name === 'remoteAlbum') await loadRemoteAlbum(state.route.remoteAlbum);
      else await loadRemote(state.route.remote);
      break;
    case 'back': back(); break;
    case 'refresh-downloads': await loadDownloads(); break;
    case 'open-downloads': await openDownloads(); break;
    case 'reveal-path':
      if (el.dataset.path && window.xphoto) window.xphoto.reveal(el.dataset.path);
      else toast('当前环境不支持打开文件夹', 'err');
      break;
    case 'set-theme': setTheme(el.dataset.theme); break;
    case 'setting-sort': setSort(el.dataset.sort); break;
    case 'change-download-dir': await changeDownloadDir(); break;
    case 'clear-cache': await clearCache(); break;
    case 'about': openModal('about'); break;
    case 'changelog': openModal('changelog'); break;
    case 'clear-image-cache':
      if (ANDROID && window.XPhotoAndroid && window.XPhotoAndroid.clearImageCache) {
        window.XPhotoAndroid.clearImageCache();
        toast('已清理手机预览缓存', 'ok');
      } else if ('caches' in window) {
        caches.keys().then((keys) => Promise.all(keys.map((key) => caches.delete(key)))).finally(() => {
          toast('已清理网页缓存，刷新后重新加载', 'ok');
        });
      } else {
        toast('请到浏览器设置里清理站点缓存');
      }
      break;
    case 'quit-app': {
      const ok = await askConfirm({ title: '退出 xphoto？', body: '退出后手机和其他电脑将无法访问这台电脑的相册。', ok: '退出', danger: true });
      if (ok && window.xphoto) window.xphoto.quit();
      break;
    }
    case 'mobile-search': openModal('search'); break;
    case 'mobile-more': openModal('more'); break;
    case 'local':
      closeModal();
      if (window.XPhotoAndroid && window.XPhotoAndroid.showLocal) window.XPhotoAndroid.showLocal();
      break;
    case 'submit-search': {
      const input = $('#mobileSearchInput');
      closeModal();
      search(input ? input.value : '');
      break;
    }
    case 'clear-search': navigate('photos', {}, { replace: true }); break;
    case 'confirm-ok': settleConfirm(true); break;
    case 'confirm-cancel': settleConfirm(false); break;
    case 'viewer-close': closeViewer(); break;
    case 'viewer-prev': viewerGo(-1); break;
    case 'viewer-next': viewerGo(1); break;
    case 'viewer-fav': if (viewerItem()) toggleFavorite(viewerItem()); break;
    case 'viewer-download': await viewerDownload(); break;
    case 'viewer-save-pc': await viewerSavePC(); break;
    case 'viewer-reveal': await viewerReveal(); break;
    case 'viewer-info': state.viewer.info = !state.viewer.info; renderViewer(); break;
    case 'zoom-in': viewerZoomBy(1); break;
    case 'zoom-out': viewerZoomBy(-1); break;
    default: break;
  }
});

document.addEventListener('change', (event) => {
  const pin = event.target.closest && event.target.closest('[data-local-pin]');
  if (pin) {
    const id = pin.dataset.localPin;
    const set = new Set(state.localPinned);
    if (pin.checked) set.add(id); else set.delete(id);
    state.localPinned = Array.from(set);
    try { localStorage.setItem(LS.localPinned, JSON.stringify(state.localPinned)); } catch (error) {}
    renderShell();
    return;
  }
  if (event.target.id === 'androidRemoteSwitch' && !event.target.checked) {
    if (ANDROID && window.XPhotoAndroid && typeof window.XPhotoAndroid.disconnect === 'function') {
      window.XPhotoAndroid.disconnect();
    } else {
      toast('当前环境不支持断开电脑', 'err');
    }
  }
});

window.onAndroidLocalChanged = () => {
  if (!ANDROID) return;
  loadAndroidFolders();
  refreshAndroidRecycleCount();
  if (state.route.name === 'local' || state.route.name === 'localFolder') {
    loadAndroidPhotos(state.route.name === 'localFolder' ? (state.route.folderId || 'all') : 'all');
  } else if (state.route.name === 'localTrash') {
    loadAndroidRecycle();
  } else {
    renderShell();
  }
};

document.addEventListener('keydown', (event) => {
  if (event.key === 'Escape') {
    if (state.viewer) { closeViewer(); return; }
    if (state.modal) { closeModal(); return; }
  }
  if (state.viewer) {
    if (event.key === 'ArrowLeft') viewerGo(-1);
    else if (event.key === 'ArrowRight') viewerGo(1);
    else if (event.key === 'f' || event.key === 'F') { const item = viewerItem(); if (item) toggleFavorite(item); }
    else if (event.key === 'i' || event.key === 'I') { state.viewer.info = !state.viewer.info; renderViewer(); }
    else if (event.key === '-' || event.key === '_') { viewerZoomBy(-1); }
    else if (event.key === '+' || event.key === '=') { viewerZoomBy(1); }
  }
  const target = event.target;
  if (target && target.matches && target.matches('.photo-tile') && (event.key === 'Enter' || event.key === ' ')) {
    event.preventDefault();
    target.click();
  }
});

document.addEventListener('submit', (event) => {
  const form = event.target;
  if (form.id === 'cloudForm') { event.preventDefault(); submitCloud(false); }
  else if (form.id === 'remoteForm') { event.preventDefault(); saveRemote(); }
  else if (form.id === 'mobileSearchForm') {
    event.preventDefault();
    const input = $('#mobileSearchInput');
    closeModal();
    search(input ? input.value : '');
  }
});

/* global search */
const globalSearch = $('#globalSearch');
if (globalSearch) {
  const runSearch = debounce(() => search(globalSearch.value), 420);
  globalSearch.addEventListener('input', runSearch);
  globalSearch.addEventListener('keydown', (event) => {
    if (event.key === 'Enter') { event.preventDefault(); search(globalSearch.value); }
    if (event.key === 'Escape') { globalSearch.value = ''; search(''); }
  });
}

/* infinite scroll */
function maybeLoadMore() {
  if (!['photos', 'favorites', 'recent', 'album', 'root'].includes(state.route.name)) return;
  if (!state.photoHasMore || state.photoLoading) return;
  let nearBottom = false;
  if (isMobile()) {
    const doc = document.documentElement;
    nearBottom = window.innerHeight + window.scrollY > doc.scrollHeight - 700;
  } else {
    const content = $('#content');
    if (content) nearBottom = content.scrollTop + content.clientHeight > content.scrollHeight - 600;
  }
  if (nearBottom) loadPhotos(true);
}
window.addEventListener('scroll', maybeLoadMore, { passive: true });
const contentEl = $('#content');
if (contentEl) contentEl.addEventListener('scroll', maybeLoadMore, { passive: true });

/* Ctrl + wheel / pinch grid zoom */
document.addEventListener('wheel', (event) => {
  if (!event.ctrlKey || state.viewer || state.modal) return;
  event.preventDefault();
  state.wheelAccum += event.deltaY;
  if (Math.abs(state.wheelAccum) < 55) return;
  const delta = state.wheelAccum < 0 ? -1 : 1;
  state.wheelAccum = 0;
  if (state.gridSize + delta < 2 || state.gridSize + delta > 8) return;
  applyGridSize(state.gridSize + delta);
}, { passive: false });

let pinchStartDistance = 0;
let pinchStartCols = 3;
let pinchActive = false;
function touchDistance(touches) {
  const dx = touches[0].clientX - touches[1].clientX;
  const dy = touches[0].clientY - touches[1].clientY;
  return Math.hypot(dx, dy);
}
document.addEventListener('touchstart', (event) => {
  if (state.viewer || state.modal || event.touches.length !== 2) return;
  pinchActive = true;
  pinchStartDistance = touchDistance(event.touches) || 1;
  pinchStartCols = state.mobileGrid;
}, { passive: true });
document.addEventListener('touchmove', (event) => {
  if (!pinchActive || event.touches.length !== 2) return;
  event.preventDefault();
  const distance = touchDistance(event.touches) || 1;
  const next = Math.round(pinchStartCols * (pinchStartDistance / distance));
  const clamped = Math.min(8, Math.max(2, next));
  if (clamped !== state.mobileGrid) applyMobileGrid(clamped);
}, { passive: false });
document.addEventListener('touchend', (event) => {
  if (event.touches.length < 2) pinchActive = false;
}, { passive: true });

/* swipe in viewer */
let touchStartX = 0;
let touchStartY = 0;
document.addEventListener('touchstart', (event) => {
  if (!state.viewer || !event.touches[0] || event.touches.length > 1) return;
  if (event.target.closest('.viewer-info')) return;
  touchStartX = event.touches[0].clientX;
  touchStartY = event.touches[0].clientY;
}, { passive: true });
document.addEventListener('touchend', (event) => {
  if (!state.viewer || !event.changedTouches[0] || (state.viewer.zoom || 1) > 1.01) return;
  const dx = event.changedTouches[0].clientX - touchStartX;
  const dy = event.changedTouches[0].clientY - touchStartY;
  if (Math.abs(dx) > 55 && Math.abs(dx) > Math.abs(dy) * 1.4) viewerGo(dx > 0 ? -1 : 1);
}, { passive: true });

/* image fade + error */
document.addEventListener('load', (event) => {
  const img = event.target;
  if (img.tagName === 'IMG') img.classList.add('loaded');
}, true);
document.addEventListener('error', (event) => {
  const img = event.target;
  if (img.tagName !== 'IMG') return;
  const tile = img.closest('.photo-tile, .album-card');
  if (tile) tile.classList.add('img-error');
}, true);

/* service worker */
function registerServiceWorker() {
  if (window.xphoto) return;
  if (!('serviceWorker' in navigator)) return;
  if (location.protocol !== 'http:' && location.protocol !== 'https:') return;
  navigator.serviceWorker.register('/sw.js').catch(() => {});
}

/* platform marker */
if (window.xphoto) {
  document.documentElement.dataset.platform = window.xphoto.platform || 'desktop';
}

/* start */
applyTheme();
setupLongPress();
boot();
