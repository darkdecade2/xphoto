'use strict';

// Start Electron with a clean environment. Some terminals (including DSH)
// export ELECTRON_RUN_AS_NODE=1, which turns Electron into plain Node.
const { spawn } = require('child_process');
const path = require('path');
const electronPath = require('electron');

const env = { ...process.env };
delete env.ELECTRON_RUN_AS_NODE;

const child = spawn(electronPath, [path.join(__dirname, '..')], {
  stdio: 'inherit',
  windowsHide: false,
  env
});

child.on('close', (code) => process.exit(code == null ? 0 : code));
child.on('error', (error) => {
  console.error('无法启动 xphoto：', error.message);
  process.exit(1);
});

for (const signal of ['SIGINT', 'SIGTERM']) {
  process.on(signal, () => {
    try { child.kill(signal); } catch {}
  });
}
