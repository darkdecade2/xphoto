﻿const sharp = require('sharp');
const fs = require('fs');
(async () => {
  const svg = fs.readFileSync('assets/icon.svg');
  for (const size of [512, 192]) {
    const inner = Math.round(size * 0.78);
    const art = await sharp(svg, { density: 300 }).resize(inner, inner).png().toBuffer();
    await sharp({ create: { width: size, height: size, channels: 4, background: '#0a0e27' } })
      .composite([{ input: art, gravity: 'center' }])
      .png().toFile(`app/icons/icon-maskable-${size}.png`);
  }
  console.log('maskable done');
})().catch(e => { console.error(e); process.exit(1); });
