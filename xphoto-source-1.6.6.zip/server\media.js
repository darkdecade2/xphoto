'use strict';

const fs = require('fs');
const fsp = fs.promises;
const path = require('path');
const crypto = require('crypto');
const { spawn } = require('child_process');
const { ensureDir, sha1, isVideoName } = require('./util');

function ffmpegPath() {
  const candidates = [
    process.env.XPHOTO_FFMPEG,
    process.env.FFMPEG_PATH,
    'C:\\Users\\darkd\\AppData\\Local\\Tools\\ffmpeg\\bin\\ffmpeg.exe',
    'ffmpeg'
  ].filter(Boolean);
  for (const candidate of candidates) {
    if (candidate === 'ffmpeg' || fs.existsSync(candidate)) return candidate;
  }
  return null;
}

function runFfmpeg(bin, args, timeout = 20000) {
  return new Promise((resolve) => {
    let child;
    try {
      child = spawn(bin, args, { windowsHide: true });
    } catch {
      resolve(false);
      return;
    }
    const timer = setTimeout(() => {
      try { child.kill(); } catch {}
      resolve(false);
    }, timeout);
    child.on('error', () => { clearTimeout(timer); resolve(false); });
    child.on('close', (code) => { clearTimeout(timer); resolve(code === 0); });
    child.stderr.on('data', () => {});
  });
}

let sharp = null;
try {
  sharp = require('sharp');
  sharp.cache({ memory: 64, files: 20 });
} catch (error) {
  sharp = null;
}

class MediaService {
  constructor(store) {
    this.store = store;
    this.thumbDir = store.thumbDir;
    ensureDir(this.thumbDir).catch(() => {});
    this.pending = new Map();
  }

  thumbFile(key) {
    return path.join(this.thumbDir, `${key}.webp`);
  }

  cacheKey(sourceKey, size) {
    return sha1(`${sourceKey}|${size}`);
  }

  async getVideoThumb(photo, px) {
    const key = this.cacheKey(`${photo.path}|${photo.mtimeMs}|${photo.size}`, px);
    const target = this.thumbFile(key);
    try {
      const stat = await fsp.stat(target);
      if (stat.size > 0) return { file: target, buffer: null, size: px };
    } catch {}
    if (this.pending.has(target)) return this.pending.get(target);
    const bin = ffmpegPath();
    if (!bin) return null;
    const work = (async () => {
      const ok = await runFfmpeg(bin, [
        '-hide_banner', '-loglevel', 'error', '-y',
        '-ss', '0.4', '-i', photo.path, '-frames:v', '1',
        '-vf', `scale=${px}:-2`, '-f', 'webp', target
      ]);
      if (!ok) {
        try { await fsp.unlink(target); } catch {}
        return null;
      }
      try {
        const stat = await fsp.stat(target);
        if (stat.size > 0) return { file: target, buffer: null, size: px };
      } catch {}
      return null;
    })().finally(() => this.pending.delete(target));
    this.pending.set(target, work);
    return work;
  }

  async getLocalThumb(photo, size = 400) {
    if (!sharp) return null;
    const px = Math.max(120, Math.min(1200, Number(size) || 400));
    if (isVideoName(photo.name)) return this.getVideoThumb(photo, px);
    const key = this.cacheKey(`${photo.path}|${photo.mtimeMs}|${photo.size}`, px);
    const target = this.thumbFile(key);
    try {
      const stat = await fsp.stat(target);
      if (stat.size > 0) return { file: target, buffer: null, size: px };
    } catch {}
    if (this.pending.has(target)) return this.pending.get(target);
    const work = (async () => {
      try {
        const buffer = await sharp(photo.path, { failOn: 'none', animated: false })
          .rotate()
          .resize({ width: px, height: px, fit: 'inside', withoutEnlargement: true })
          .webp({ quality: 82, effort: 4 })
          .toBuffer();
        await fsp.writeFile(target, buffer);
        return { file: target, buffer, size: px };
      } catch (error) {
        return null;
      } finally {
        this.pending.delete(target);
      }
    })();
    this.pending.set(target, work);
    return work;
  }

  async getBufferThumb(buffer, sourceKey, size = 400) {
    if (!sharp) return null;
    const px = Math.max(120, Math.min(1200, Number(size) || 400));
    const key = this.cacheKey(sourceKey, px);
    const target = this.thumbFile(key);
    try {
      const stat = await fsp.stat(target);
      if (stat.size > 0) return { file: target, buffer: null, size: px };
    } catch {}
    try {
      const out = await sharp(buffer, { failOn: 'none', animated: false })
        .rotate()
        .resize({ width: px, height: px, fit: 'inside', withoutEnlargement: true })
        .webp({ quality: 82, effort: 4 })
        .toBuffer();
      await fsp.writeFile(target, out);
      return { file: target, buffer: out, size: px };
    } catch {
      return null;
    }
  }

  async metadata(file) {
    if (!sharp) {
      return { width: null, height: null, format: path.extname(file).slice(1) };
    }
    try {
      const meta = await sharp(file, { failOn: 'none' }).metadata();
      return {
        width: meta.width || null,
        height: meta.height || null,
        format: meta.format || path.extname(file).slice(1),
        space: meta.space || null,
        orientation: meta.orientation || null,
        hasAlpha: Boolean(meta.hasAlpha)
      };
    } catch {
      return { width: null, height: null, format: path.extname(file).slice(1) };
    }
  }

  async convertForWeb(file, ext) {
    if (!sharp) return null;
    if (!['.heic', '.heif', '.tif', '.tiff'].includes(String(ext).toLowerCase())) return null;
    try {
      return await sharp(file, { failOn: 'none' })
        .rotate()
        .jpeg({ quality: 90 })
        .toBuffer();
    } catch {
      return null;
    }
  }

  async saveBuffer(buffer, dir, name) {
    const { uniqueFile } = require('./util');
    await ensureDir(dir);
    const target = uniqueFile(dir, name);
    await fsp.writeFile(target, buffer);
    return target;
  }

  fileEtag(stat) {
    return crypto.createHash('md5').update(`${stat.size}:${stat.mtimeMs}`).digest('hex');
  }
}

module.exports = { MediaService };
