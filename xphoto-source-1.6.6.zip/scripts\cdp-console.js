'use strict';

// Debug helper: load a page in headless Edge and print console/exception events.
// Usage: node scripts/cdp-console.js <url> [waitMs]
const { spawn } = require('child_process');
const os = require('os');
const path = require('path');
const fs = require('fs');

const EDGE = 'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe';
const url = process.argv[2];
const waitMs = Number(process.argv[3] || 6000);
const port = 9700 + Math.floor(Math.random() * 200);
const profile = path.join(os.tmpdir(), 'xphoto-edge-debug', `${process.pid}-${Date.now()}`);

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

async function target() {
  for (let i = 0; i < 80; i += 1) {
    try {
      const list = await (await fetch(`http://127.0.0.1:${port}/json/list`)).json();
      const page = list.find((item) => item.type === 'page' && item.webSocketDebuggerUrl);
      if (page) return page;
    } catch {}
    await sleep(250);
  }
  throw new Error('no CDP target');
}

function connect(wsUrl) {
  return new Promise((resolve, reject) => {
    const ws = new WebSocket(wsUrl);
    const pending = new Map();
    let id = 0;
    ws.addEventListener('open', () => resolve({
      send(method, params = {}) {
        return new Promise((res, rej) => {
          const callId = ++id;
          pending.set(callId, { res, rej });
          ws.send(JSON.stringify({ id: callId, method, params }));
        });
      },
      close() { try { ws.close(); } catch {} }
    }));
    ws.addEventListener('message', (event) => {
      let msg;
      try { msg = JSON.parse(event.data); } catch { return; }
      if (msg.id && pending.has(msg.id)) {
        const item = pending.get(msg.id);
        pending.delete(msg.id);
        if (msg.error) item.rej(new Error(msg.error.message));
        else item.res(msg.result);
        return;
      }
      if (msg.method === 'Runtime.exceptionThrown') {
        const d = msg.params.exceptionDetails;
        console.log('EXCEPTION:', d.text, d.exception && (d.exception.description || d.exception.value));
      }
      if (msg.method === 'Runtime.consoleAPICalled') {
        const values = (msg.params.args || []).map((a) => a.value ?? a.description ?? '').join(' ');
        if (msg.params.type === 'error' || msg.params.type === 'warning') console.log('CONSOLE ' + msg.params.type + ':', values);
      }
    });
    ws.addEventListener('error', reject);
  });
}

(async () => {
  fs.mkdirSync(profile, { recursive: true });
  const child = spawn(EDGE, [
    '--headless=new', '--disable-gpu', '--hide-scrollbars', '--no-first-run', '--force-device-scale-factor=1',
    '--no-default-browser-check', '--disable-extensions', '--mute-audio', '--disable-sync',
    '--disable-features=msEdgeSignin,msEdgeSync,msEdgeIdentity', '--no-service-autorun',
    `--remote-debugging-port=${port}`, `--user-data-dir=${profile}`, 'about:blank'
  ], { stdio: 'ignore', windowsHide: true });
  try {
    const page = await target();
    const cdp = await connect(page.webSocketDebuggerUrl);
    await cdp.send('Page.enable');
    await cdp.send('Runtime.enable');
    await cdp.send('Page.navigate', { url });
    await sleep(waitMs);
    const result = await cdp.send('Runtime.evaluate', {
      expression: '({title:document.title,text:document.body.innerText.slice(0,800),html:document.querySelector("#content")?.innerHTML.slice(0,300)})',
      returnByValue: true
    });
    console.log('PAGE', JSON.stringify(result.result && result.result.value, null, 2));
    cdp.close();
  } finally {
    try { child.kill(); } catch {}
  }
})().catch((error) => { console.error('FATAL', error); process.exit(1); });
