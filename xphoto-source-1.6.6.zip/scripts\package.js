'use strict';

// Build a portable Windows folder with @electron/packager.
// Output: dist/xphoto-win32-x64/xphoto.exe
const path = require('path');
const fs = require('fs');
const os = require('os');
const { packager } = require('@electron/packager');

const ROOT = path.join(__dirname, '..');
const OUT = path.join(ROOT, 'dist');
const ELECTRON_VERSION = require('electron/package.json').version;

// Reuse the already-downloaded Electron zip so offline packaging still works.
function findElectronZipDir() {
  const cacheRoot = path.join(os.homedir(), 'AppData', 'Local', 'electron', 'Cache');
  const wanted = `electron-v${ELECTRON_VERSION}-win32-x64.zip`;
  try {
    for (const entry of fs.readdirSync(cacheRoot)) {
      const file = path.join(cacheRoot, entry, wanted);
      if (fs.existsSync(file)) return path.dirname(file);
    }
  } catch {}
  return undefined;
}

(async () => {
  fs.mkdirSync(OUT, { recursive: true });
  const appPaths = await packager({
    dir: ROOT,
    out: OUT,
    name: 'xphoto',
    executableName: 'xphoto',
    platform: 'win32',
    arch: 'x64',
    electronVersion: ELECTRON_VERSION,
    electronZipDir: findElectronZipDir(),
    icon: path.join(ROOT, 'assets', 'icon.ico'),
    appVersion: '1.6.6',
    buildVersion: '1.6.6',
    overwrite: true,
    prune: true,
    asar: false,
    appCopyright: 'xphoto',
    win32metadata: {
      CompanyName: 'xphoto',
      FileDescription: 'xphoto 鐩稿唽 路 鐢佃剳鎵嬫満閫氱敤灞€鍩熺綉鐩稿唽',
      ProductName: 'xphoto 鐩稿唽',
      InternalName: 'xphoto',
      OriginalFilename: 'xphoto.exe',
      LegalCopyright: 'xphoto'
    },
    ignore: [
      /^\/dist($|\/)/,
      /^\/\.shots($|\/)/,
      /^\/\.shots-eval-/,
      /^\/\.test($|\/)/,
      /^\/\.testdata/,
      /^\/\.packtest($|\/)/,
      /^\/\.test-photos($|\/)/,
      /^\/\.electron-shot-data($|\/)/,
      /^\/\.electron-test-data/,
      /^\/\.edge-profile/,
      /^\/@\.shots/,
      /^\/scripts($|\/)/,
      /^\/android($|\/)/,
      /^\/launcher($|\/)/,
      /^\/README\.md$/,
      /^\/\.git($|\/)/,
      /^\/electron-shot\.log$/
    ]
  });
  for (const appPath of appPaths) {
    fs.cpSync(path.join(ROOT, 'launcher'), appPath, { recursive: true });
    fs.copyFileSync(path.join(ROOT, 'README.md'), path.join(appPath, 'README.md'));
    const apkPath = path.join(ROOT, 'dist', 'xphoto.apk');
    if (fs.existsSync(apkPath)) fs.copyFileSync(apkPath, path.join(appPath, 'xphoto.apk'));
    console.log('PACKAGED ' + appPath);
  }
})().catch((error) => {
  console.error('PACKAGE FAILED', error);
  process.exit(1);
});
