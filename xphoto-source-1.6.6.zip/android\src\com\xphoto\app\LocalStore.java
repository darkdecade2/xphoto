package com.xphoto.app;

import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import android.text.TextUtils;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * A tiny, dependency-free view of the phone's photo library.
 *
 * The app itself opens the native gallery; this class only exposes the same
 * MediaStore data to the connected WebView so the PC-style sidebar can show
 * "手机本机" folders while the phone is connected to a computer.
 */
public class LocalStore {
    private final Context context;
    private final ContentResolver resolver;

    public LocalStore(Context context) {
        this.context = context.getApplicationContext();
        this.resolver = context.getContentResolver();
    }

    private static final class Folder {
        String id;
        String name;
        int count;
        String cover;
    }

    private static final class Photo {
        long id;
        String name;
        long size;
        long date;
        Uri uri;
        String bucket;
        String location;
    }

    private boolean supportsBuckets() {
        return Build.VERSION.SDK_INT >= 29;
    }

    private String imageSelection() {
        return MediaStore.Images.Media.MIME_TYPE + " LIKE 'image/%'";
    }

    /** All MediaStore buckets, newest first. */
    public String foldersJson() {
        JSONArray out = new JSONArray();
        Map<String, Folder> map = new LinkedHashMap<>();
        if (supportsBuckets()) {
            String[] projection = new String[]{
                    MediaStore.Images.Media._ID,
                    MediaStore.Images.Media.BUCKET_ID,
                    MediaStore.Images.Media.BUCKET_DISPLAY_NAME,
                    MediaStore.Images.Media.DATE_ADDED
            };
            try (Cursor cursor = resolver.query(
                    MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                    projection, imageSelection(), null,
                    MediaStore.Images.Media.DATE_ADDED + " DESC")) {
                if (cursor != null) {
                    int idCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media._ID);
                    int bucketCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.BUCKET_ID);
                    int nameCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.BUCKET_DISPLAY_NAME);
                    while (cursor.moveToNext()) {
                        String bucketId = cursor.getString(bucketCol);
                        if (TextUtils.isEmpty(bucketId)) bucketId = "0";
                        String key = "bucket:" + bucketId;
                        Folder folder = map.get(key);
                        if (folder == null) {
                            folder = new Folder();
                            folder.id = key;
                            folder.name = cursor.getString(nameCol);
                            if (TextUtils.isEmpty(folder.name)) folder.name = "手机相册";
                            map.put(key, folder);
                        }
                        if (folder.cover == null) {
                            folder.cover = ContentUris.withAppendedId(
                                    MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                                    cursor.getLong(idCol)).toString();
                        }
                        folder.count += 1;
                    }
                }
            } catch (Exception ignored) {
            }
        } else {
            String[] projection = new String[]{
                    MediaStore.Images.Media._ID,
                    MediaStore.Images.Media.DATA,
                    MediaStore.Images.Media.DATE_ADDED
            };
            try (Cursor cursor = resolver.query(
                    MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                    projection, imageSelection(), null,
                    MediaStore.Images.Media.DATE_ADDED + " DESC")) {
                if (cursor != null) {
                    int idCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media._ID);
                    int dataCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
                    while (cursor.moveToNext()) {
                        String data = cursor.getString(dataCol);
                        if (TextUtils.isEmpty(data)) continue;
                        File parent = new File(data).getParentFile();
                        if (parent == null) continue;
                        String key = "path:" + parent.getAbsolutePath();
                        Folder folder = map.get(key);
                        if (folder == null) {
                            folder = new Folder();
                            folder.id = key;
                            folder.name = parent.getName();
                            if (TextUtils.isEmpty(folder.name)) folder.name = "手机相册";
                            map.put(key, folder);
                        }
                        if (folder.cover == null) {
                            folder.cover = ContentUris.withAppendedId(
                                    MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                                    cursor.getLong(idCol)).toString();
                        }
                        folder.count += 1;
                    }
                }
            } catch (Exception ignored) {
            }
        }

        for (Folder folder : map.values()) {
            try {
                JSONObject item = new JSONObject();
                item.put("id", folder.id);
                item.put("name", folder.name);
                item.put("count", folder.count);
                item.put("cover", folder.cover == null ? "" : folder.cover);
                out.put(item);
            } catch (Exception ignored) {
            }
        }
        return out.toString();
    }

    /** Photos in one bucket, or every phone photo when folderId is "all". */
    public String photosJson(String folderId) {
        List<Photo> photos = new ArrayList<>();
        String selection = imageSelection();
        String[] args = null;
        String bucketName = "手机相册";

        if ("all".equals(folderId)) {
            // No extra selection.
        } else if (folderId != null && folderId.startsWith("bucket:")) {
            String bucket = folderId.substring("bucket:".length());
            if (supportsBuckets()) {
                selection += " AND " + MediaStore.Images.Media.BUCKET_ID + " = ?";
                args = new String[]{bucket};
            }
        } else if (folderId != null && folderId.startsWith("path:")) {
            String parent = folderId.substring("path:".length());
            selection += " AND " + MediaStore.Images.Media.DATA + " LIKE ?";
            args = new String[]{parent + "/%"};
            File file = new File(parent);
            if (!TextUtils.isEmpty(file.getName())) bucketName = file.getName();
        } else {
            return "[]";
        }

        String[] projection;
        if (supportsBuckets()) {
            projection = new String[]{
                    MediaStore.Images.Media._ID,
                    MediaStore.Images.Media.DISPLAY_NAME,
                    MediaStore.Images.Media.SIZE,
                    MediaStore.Images.Media.DATE_ADDED,
                    MediaStore.Images.Media.BUCKET_DISPLAY_NAME,
                    MediaStore.MediaColumns.RELATIVE_PATH
            };
        } else {
            projection = new String[]{
                    MediaStore.Images.Media._ID,
                    MediaStore.Images.Media.DISPLAY_NAME,
                    MediaStore.Images.Media.SIZE,
                    MediaStore.Images.Media.DATE_ADDED,
                    MediaStore.Images.Media.DATA
            };
        }

        try (Cursor cursor = resolver.query(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                projection, selection, args,
                MediaStore.Images.Media.DATE_ADDED + " DESC")) {
            if (cursor != null) {
                int idCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media._ID);
                int nameCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DISPLAY_NAME);
                int sizeCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.SIZE);
                int dateCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATE_ADDED);
                int bucketCol = supportsBuckets()
                        ? cursor.getColumnIndex(MediaStore.Images.Media.BUCKET_DISPLAY_NAME) : -1;
                int locCol = supportsBuckets()
                        ? cursor.getColumnIndex(MediaStore.MediaColumns.RELATIVE_PATH)
                        : cursor.getColumnIndex(MediaStore.Images.Media.DATA);
                while (cursor.moveToNext() && photos.size() < 2000) {
                    Photo photo = new Photo();
                    photo.id = cursor.getLong(idCol);
                    photo.name = cursor.getString(nameCol);
                    if (TextUtils.isEmpty(photo.name)) photo.name = "照片";
                    photo.size = cursor.getLong(sizeCol);
                    photo.date = cursor.getLong(dateCol);
                    photo.uri = ContentUris.withAppendedId(
                            MediaStore.Images.Media.EXTERNAL_CONTENT_URI, photo.id);
                    if (bucketCol >= 0) {
                        String name = cursor.getString(bucketCol);
                        if (!TextUtils.isEmpty(name)) photo.bucket = name;
                    }
                    if (locCol >= 0) {
                        String loc = cursor.getString(locCol);
                        if (!TextUtils.isEmpty(loc)) {
                            if (supportsBuckets()) {
                                photo.location = new File(
                                        new File(Environment.getExternalStorageDirectory(), loc),
                                        photo.name).getAbsolutePath();
                            } else {
                                photo.location = loc;
                            }
                        }
                    }
                    photos.add(photo);
                }
            }
        } catch (Exception ignored) {
        }

        JSONArray out = new JSONArray();
        for (Photo photo : photos) {
            try {
                JSONObject item = new JSONObject();
                item.put("id", photo.uri.toString());
                item.put("name", photo.name);
                item.put("size", photo.size);
                item.put("date", photo.date);
                item.put("uri", photo.uri.toString());
                item.put("location", photo.location == null ? "" : photo.location);
                item.put("folder", photo.bucket == null ? bucketName : photo.bucket);
                out.put(item);
            } catch (Exception ignored) {
            }
        }
        return out.toString();
    }
}
