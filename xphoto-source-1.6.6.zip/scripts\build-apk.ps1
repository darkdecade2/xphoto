$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
$homeDir = if ($env:XPHOTO_ANDROID_HOME) { $env:XPHOTO_ANDROID_HOME } else { Join-Path $env:TEMP 'xphoto-android-build' }
$sdk = Join-Path $homeDir 'sdk'
$bt = Join-Path $sdk 'build-tools\35.0.0'
$jdk = Join-Path $homeDir 'jdk\jdk-17.0.21.1+2'
$androidJar = Join-Path $sdk 'platforms\android-35\android.jar'
$lambdaStubs = Join-Path $bt 'core-lambda-stubs.jar'

foreach ($tool in @(
    (Join-Path $bt 'aapt2.exe'),
    (Join-Path $bt 'd8.bat'),
    (Join-Path $bt 'zipalign.exe'),
    (Join-Path $bt 'apksigner.bat'),
    (Join-Path $jdk 'bin\javac.exe'),
    (Join-Path $jdk 'bin\jar.exe'),
    $androidJar, $lambdaStubs
)) {
    if (-not (Test-Path $tool)) { throw "缺少 Android 构建工具: $tool" }
}

$build = Join-Path $root 'android\build'
if (Test-Path $build) { Remove-Item $build -Recurse -Force }
New-Item -ItemType Directory -Force (Join-Path $build 'gen'), (Join-Path $build 'classes'), (Join-Path $build 'dex') | Out-Null

$env:JAVA_HOME = $jdk
$env:PATH = "$jdk\bin;$env:PATH"

Push-Location $root
try {
    & (Join-Path $bt 'aapt2.exe') compile --dir 'android\res' -o 'android\build\res.zip'
    if ($LASTEXITCODE -ne 0) { throw 'aapt2 compile failed' }

    & (Join-Path $bt 'aapt2.exe') link `
        -o 'android\build\base.apk' `
        -I $androidJar `
        --manifest 'android\AndroidManifest.xml' `
        --java 'android\build\gen' `
        --auto-add-overlay `
        'android\build\res.zip'
    if ($LASTEXITCODE -ne 0) { throw 'aapt2 link failed' }

    $sources = @('android\build\gen\com\xphoto\app\R.java') + (Get-ChildItem 'android\src\com\xphoto\app\*.java' | ForEach-Object { $_.FullName })
    & (Join-Path $jdk 'bin\javac.exe') `
        -source 8 -target 8 -encoding UTF-8 `
        -bootclasspath "$androidJar;$lambdaStubs" `
        -d 'android\build\classes' @sources
    if ($LASTEXITCODE -ne 0) { throw 'javac failed' }

    $classes = (Get-ChildItem 'android\build\classes' -Recurse -Filter '*.class' | ForEach-Object { $_.FullName })
    & (Join-Path $bt 'd8.bat') --min-api 23 --lib $androidJar --output 'android\build\dex' @classes
    if ($LASTEXITCODE -ne 0) { throw 'd8 failed' }

    Copy-Item 'android\build\base.apk' 'android\build\unsigned.apk' -Force
    & (Join-Path $jdk 'bin\jar.exe') uf 'android\build\unsigned.apk' -C 'android\build\dex' 'classes.dex'
    if ($LASTEXITCODE -ne 0) { throw 'jar classes.dex failed' }

    & (Join-Path $bt 'zipalign.exe') -f 4 'android\build\unsigned.apk' 'android\build\aligned.apk'
    if ($LASTEXITCODE -ne 0) { throw 'zipalign failed' }

    New-Item -ItemType Directory -Force 'dist' | Out-Null
    & (Join-Path $bt 'apksigner.bat') sign `
        --ks 'android\keystore\xphoto.jks' `
        --ks-key-alias 'xphoto' `
        --ks-pass 'pass:xphoto123456' `
        --key-pass 'pass:xphoto123456' `
        --out 'dist\xphoto.apk' `
        'android\build\aligned.apk'
    if ($LASTEXITCODE -ne 0) { throw 'apksigner failed' }

    & (Join-Path $bt 'apksigner.bat') verify --print-certs 'dist\xphoto.apk'
    if ($LASTEXITCODE -ne 0) { throw 'apksigner verify failed' }

    $apk = Get-Item 'dist\xphoto.apk'
    $manifest = Get-Content 'android\AndroidManifest.xml' -Raw
    $versionCode = [regex]::Match($manifest, 'android:versionCode="([^"]+)"').Groups[1].Value
    $versionName = [regex]::Match($manifest, 'android:versionName="([^"]+)"').Groups[1].Value
    "APK: $($apk.FullName)"
    "Size: $($apk.Length) bytes"
    "Version: $versionName ($versionCode)"
}
finally {
    Pop-Location
}
