package com.xphoto.app;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.os.Handler;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.view.GestureDetector;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.MediaController;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.VideoView;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Full-screen local photo viewer with swipe, pinch and double-tap zoom. */
class PhotoViewerDialog extends Dialog {
    private static final ExecutorService IO = Executors.newFixedThreadPool(2);
    private final Handler main = new Handler(Looper.getMainLooper());
    private final List<PhotoItem> items;
    private final Matrix matrix = new Matrix();
    private final float[] matrixValues = new float[9];
    private ImageView image;
    private VideoView video;
    private ProgressBar progress;
    private TextView info;
    private TextView counter;
    private int index;
    private Bitmap bitmap;
    private float baseScale = 1f;
    private float extraScale = 1f;
    private float downX;
    private float downY;
    private boolean dragging;

    static void show(Context context, ArrayList<PhotoItem> items, int index) {
        if (items == null || items.isEmpty()) return;
        PhotoViewerDialog dialog = new PhotoViewerDialog(context, items, index);
        dialog.show();
    }

    static void showVideo(Context context, android.net.Uri uri, String name) {
        ArrayList<PhotoItem> list = new ArrayList<>();
        list.add(new PhotoItem(-1, name, "手机本机", System.currentTimeMillis(), 0, uri, false, true, false, uri.toString()));
        show(context, list, 0);
    }

    private PhotoViewerDialog(Context context, List<PhotoItem> items, int index) {
        super(context, android.R.style.Theme_Black_NoTitleBar_Fullscreen);
        this.items = items;
        this.index = Math.max(0, Math.min(index, items.size() - 1));
        setContentView(build());
        setCanceledOnTouchOutside(true);
        // VideoView needs a real window/surface before setVideoURI, otherwise some
        // phones prepare the clip but never paint a frame. load() runs in show().
    }

    private int dp(float value) {
        return Math.round(value * getContext().getResources().getDisplayMetrics().density);
    }

    private View build() {
        FrameLayout root = new FrameLayout(getContext());
        root.setBackgroundColor(Color.BLACK);

        image = new ImageView(getContext());
        image.setScaleType(ImageView.ScaleType.MATRIX);
        image.setBackgroundColor(Color.BLACK);
        root.addView(image, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        video = new VideoView(getContext());
        video.setVisibility(View.GONE);
        video.setBackgroundColor(Color.BLACK);
        MediaController controller = new MediaController(getContext());
        controller.setAnchorView(video);
        video.setMediaController(controller);
        root.addView(video, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        progress = new ProgressBar(getContext());
        progress.setIndeterminate(true);
        FrameLayout.LayoutParams progressParams = new FrameLayout.LayoutParams(
                dp(42), dp(42), Gravity.CENTER);
        root.addView(progress, progressParams);

        LinearLayout top = new LinearLayout(getContext());
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setPadding(dp(14), dp(10), dp(14), dp(10));
        FrameLayout.LayoutParams topParams = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.TOP);
        root.addView(top, topParams);

        TextView close = new TextView(getContext());
        close.setText("×");
        close.setTextColor(Color.WHITE);
        close.setTextSize(30);
        close.setGravity(Gravity.CENTER);
        close.setBackground(circle(0x66000000));
        close.setOnClickListener(v -> dismiss());
        top.addView(close, new LinearLayout.LayoutParams(dp(40), dp(40)));

        counter = new TextView(getContext());
        counter.setTextColor(Color.WHITE);
        counter.setTextSize(12);
        counter.setGravity(Gravity.CENTER_VERTICAL);
        counter.setPadding(dp(12), 0, 0, 0);
        top.addView(counter, new LinearLayout.LayoutParams(0, dp(40), 1f));

        TextView location = new TextView(getContext());
        location.setText("位置");
        location.setTextColor(Color.WHITE);
        location.setTextSize(12);
        location.setGravity(Gravity.CENTER);
        location.setPadding(dp(10), 0, dp(10), 0);
        location.setBackground(circle(0x66000000));
        location.setOnClickListener(v -> {
            if (!items.isEmpty()) LocalGalleryView.showLocation(getContext(), items.get(index));
        });
        top.addView(location, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, dp(36)));

        info = new TextView(getContext());
        info.setTextColor(0xFFE4E7EC);
        info.setTextSize(12);
        info.setGravity(Gravity.CENTER);
        info.setPadding(dp(22), dp(16), dp(22), dp(28));
        info.setBackgroundColor(0x66000000);
        FrameLayout.LayoutParams infoParams = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM);
        root.addView(info, infoParams);

        GestureDetector gestures = new GestureDetector(getContext(), new GestureDetector.SimpleOnGestureListener() {
            @Override
            public boolean onDown(MotionEvent e) {
                downX = e.getX();
                downY = e.getY();
                dragging = false;
                return true;
            }

            @Override
            public boolean onScroll(MotionEvent e1, MotionEvent e2, float distanceX, float distanceY) {
                if (currentScale() > 1.03f) {
                    dragging = true;
                    matrix.postTranslate(-distanceX, -distanceY);
                    image.setImageMatrix(matrix);
                }
                return true;
            }

            @Override
            public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX, float velocityY) {
                if (e1 == null || e2 == null) return false;
                float dx = e2.getX() - e1.getX();
                float dy = e2.getY() - e1.getY();
                if (currentScale() <= 1.03f && Math.abs(dx) > dp(55) && Math.abs(dx) > Math.abs(dy) * 1.4f) {
                    if (dx > 0) previous();
                    else next();
                    return true;
                }
                return false;
            }

            @Override
            public boolean onDoubleTap(MotionEvent e) {
                extraScale = extraScale > 1.4f ? 1f : 2.2f;
                applyScale(e.getX(), e.getY());
                return true;
            }

            @Override
            public boolean onSingleTapConfirmed(MotionEvent e) {
                return false;
            }
        });

        ScaleGestureDetector scale = new ScaleGestureDetector(getContext(),
                new ScaleGestureDetector.SimpleOnScaleGestureListener() {
                    @Override
                    public boolean onScale(ScaleGestureDetector detector) {
                        extraScale = Math.max(1f, Math.min(10f, extraScale * detector.getScaleFactor()));
                        applyScale(detector.getFocusX(), detector.getFocusY());
                        return true;
                    }
                });

        image.setOnTouchListener((v, event) -> {
            scale.onTouchEvent(event);
            gestures.onTouchEvent(event);
            return true;
        });
        return root;
    }

    private android.graphics.drawable.GradientDrawable circle(int color) {
        android.graphics.drawable.GradientDrawable d = new android.graphics.drawable.GradientDrawable();
        d.setShape(android.graphics.drawable.GradientDrawable.OVAL);
        d.setColor(color);
        return d;
    }

    private void load() {
        progress.setVisibility(View.VISIBLE);
        image.setImageDrawable(null);
        bitmap = null;
        matrix.reset();
        extraScale = 1f;
        PhotoItem item = items.get(index);
        counter.setText((index + 1) + " / " + items.size());
        info.setText(item.name + "\n" + item.bucket);
        if (item.video) {
            image.setVisibility(View.GONE);
            video.setVisibility(View.VISIBLE);
            progress.setVisibility(View.GONE);
            video.setVideoURI(item.uri);
            video.setOnPreparedListener(mp -> {
                mp.setLooping(false);
                video.start();
            });
            video.setOnErrorListener((mp, what, extra) -> {
                // Let the phone's own video player try the clip. This covers codecs
                // that the in-app VideoView cannot decode.
                openExternal();
                return true;
            });
            return;
        }
        video.stopPlayback();
        video.setVisibility(View.GONE);
        image.setVisibility(View.VISIBLE);
        final int wantedIndex = index;
        IO.execute(() -> {
            Bitmap decoded = decode(item);
            main.post(() -> {
                if (isShowing() && wantedIndex == index) {
                    bitmap = decoded;
                    if (bitmap != null) {
                        image.setImageBitmap(bitmap);
                        fit();
                    } else {
                        Toast.makeText(getContext(), "这张图片打不开", Toast.LENGTH_SHORT).show();
                    }
                    progress.setVisibility(View.GONE);
                }
            });
        });
    }

    private Bitmap decode(PhotoItem item) {
        try {
            BitmapFactory.Options bounds = new BitmapFactory.Options();
            bounds.inJustDecodeBounds = true;
            try (InputStream in = getContext().getContentResolver().openInputStream(item.uri)) {
                BitmapFactory.decodeStream(in, null, bounds);
            }
            DisplayMetrics dm = getContext().getResources().getDisplayMetrics();
            int target = Math.max(dm.widthPixels, dm.heightPixels);
            int sample = 1;
            int w = Math.max(1, bounds.outWidth);
            int h = Math.max(1, bounds.outHeight);
            while (w / (sample * 2) >= target || h / (sample * 2) >= target) sample *= 2;
            BitmapFactory.Options opts = new BitmapFactory.Options();
            opts.inSampleSize = sample;
            opts.inPreferredConfig = Bitmap.Config.RGB_565;
            try (InputStream in = getContext().getContentResolver().openInputStream(item.uri)) {
                return BitmapFactory.decodeStream(in, null, opts);
            }
        } catch (Exception | OutOfMemoryError ignored) {
            return null;
        }
    }

    private void fit() {
        if (bitmap == null || image.getWidth() == 0 || image.getHeight() == 0) {
            image.post(this::fit);
            return;
        }
        float vw = image.getWidth();
        float vh = image.getHeight();
        float scale = Math.min(vw / bitmap.getWidth(), vh / bitmap.getHeight());
        baseScale = scale;
        matrix.reset();
        matrix.postScale(scale, scale);
        matrix.postTranslate((vw - bitmap.getWidth() * scale) / 2f,
                (vh - bitmap.getHeight() * scale) / 2f);
        image.setImageMatrix(matrix);
    }

    private float currentScale() {
        matrix.getValues(matrixValues);
        return matrixValues[Matrix.MSCALE_X];
    }

    private void applyScale(float focusX, float focusY) {
        if (bitmap == null) return;
        float current = currentScale();
        float target = baseScale * extraScale;
        if (current <= 0f) return;
        float factor = target / current;
        matrix.postScale(factor, factor, focusX, focusY);
        image.setImageMatrix(matrix);
    }

    private void previous() {
        if (index <= 0) return;
        index -= 1;
        load();
    }

    private void next() {
        if (index >= items.size() - 1) return;
        index += 1;
        load();
    }

    @Override
    public void dismiss() {
        try { video.stopPlayback(); } catch (Exception ignored) {}
        super.dismiss();
    }

    @Override
    public void show() {
        super.show();
        Window window = getWindow();
        if (window != null) {
            window.setLayout(WindowManager.LayoutParams.MATCH_PARENT,
                    WindowManager.LayoutParams.MATCH_PARENT);
            window.setBackgroundDrawable(new ColorDrawable(Color.BLACK));
            window.setStatusBarColor(Color.BLACK);
            window.setNavigationBarColor(Color.BLACK);
        }
        load();
    }

    static boolean playExternal(Context context, Uri uri) {
        if (context == null || uri == null) return false;
        try {
            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setDataAndType(uri, "video/*");
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION
                    | Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(intent);
            return true;
        } catch (Exception error) {
            return false;
        }
    }

    private void openExternal() {
        if (playExternal(getContext(), items.get(index).uri)) {
            dismiss();
        } else {
            Toast.makeText(getContext(), "这个视频手机也打不开，可能是编码不支持", Toast.LENGTH_LONG).show();
        }
    }
}
