﻿const sharp = require('sharp');
const fs = require('fs');
const path = require('path');
const root = path.join(process.cwd(), '.test-photos');
fs.rmSync(root, { recursive: true, force: true });
const folders = [
  { dir: '旅行/杭州', names: ['西湖日落', '断桥清晨', '龙井茶园', '河坊街夜色', '雷峰塔远景'] },
  { dir: '日常', names: ['早餐', '咖啡时间', '猫咪午睡', '书桌一角', '雨后的窗'] },
  { dir: '家庭/2026 春节', names: ['年夜饭', '烟花', '全家福', '红包', '春联'] },
  { dir: '壁纸', names: ['极光', '深海', '晚霞', '星云', '薄荷渐变'] }
];
const palettes = [
  ['#0f172a','#38bdf8','#f472b6'], ['#1e1b4b','#8b5cf6','#22d3ee'],
  ['#052e16','#34d399','#fde68a'], ['#431407','#fb923c','#f43f5e'],
  ['#0c4a6e','#7dd3fc','#e0f2fe'], ['#3b0764','#d946ef','#f9a8d4']
];
let count = 0;
(async () => {
  for (let f = 0; f < folders.length; f++) {
    const folder = folders[f];
    const dir = path.join(root, folder.dir);
    fs.mkdirSync(dir, { recursive: true });
    for (let i = 0; i < folder.names.length; i++) {
      const p = palettes[(f + i) % palettes.length];
      const label = folder.names[i];
      const idx = String(++count).padStart(2, '0');
      const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="1200" height="900" viewBox="0 0 1200 900">
        <defs>
          <linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop stop-color="${p[0]}"/><stop offset=".55" stop-color="${p[1]}"/><stop offset="1" stop-color="${p[2]}"/></linearGradient>
          <radialGradient id="sun" cx=".5" cy=".5" r=".5"><stop stop-color="#fff8e7" stop-opacity=".95"/><stop offset=".5" stop-color="#ffe8b0" stop-opacity=".45"/><stop offset="1" stop-color="#ffe8b0" stop-opacity="0"/></radialGradient>
          <linearGradient id="haze" x1="0" y1="0" x2="0" y2="1"><stop stop-color="#fff" stop-opacity=".12"/><stop offset="1" stop-color="#000" stop-opacity=".25"/></linearGradient>
        </defs>
        <rect width="1200" height="900" fill="url(#g)"/>
        <circle cx="${760 + (i%3)*80}" cy="${250 + (f%2)*40}" r="220" fill="url(#sun)"/>
        <circle cx="${760 + (i%3)*80}" cy="${250 + (f%2)*40}" r="78" fill="#fff6da" opacity=".9"/>
        <path d="M0 620 L240 420 L420 580 L650 360 L900 600 L1080 470 L1200 560 L1200 900 L0 900 Z" fill="#081224" opacity=".55"/>
        <path d="M0 720 L300 560 L560 760 L820 600 L1080 740 L1200 690 L1200 900 L0 900 Z" fill="#030812" opacity=".7"/>
        <rect width="1200" height="900" fill="url(#haze)"/>
        <g font-family="Segoe UI, Microsoft YaHei, sans-serif" fill="#ffffff">
          <text x="70" y="120" font-size="34" opacity=".65" letter-spacing="8">XPHOTO SAMPLE</text>
          <text x="70" y="790" font-size="78" font-weight="700">${label}</text>
          <text x="76" y="842" font-size="26" opacity=".65">${folder.dir} · ${idx}</text>
        </g>
      </svg>`;
      const file = path.join(dir, `IMG_2026${String(10 + f).padStart(2,'0')}${String(1+i).padStart(2,'0')}_${idx}.jpg`);
      await sharp(Buffer.from(svg)).jpeg({ quality: 88 }).toFile(file);
      const d = new Date(2026, 8 + f, 2 + Math.floor(i / 3) * 3, 9 + i, 24, 0);
      fs.utimesSync(file, d, d);
    }
  }
  console.log('sample photos:', count, root);
})().catch(e => { console.error(e); process.exit(1); });

