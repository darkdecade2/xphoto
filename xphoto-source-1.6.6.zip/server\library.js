'use strict';

const fs = require('fs');
const fsp = fs.promises;
const path = require('path');
const {
  base64url,
  fromBase64url,
  isMediaName,
  isVideoName,
  isInside,
  normalizePath,
  uniqueFile
} = require('./util');

const SKIP_DIRS = new Set([
  '$recycle.bin',
  'system volume information',
  'node_modules',
  '.git',
  '.svn',
  '@eadir',
  '#recycle',
  'lost+found',
  'thumbnails',
  '.thumbnails'
]);

const CACHE_TTL = 25 * 1000;
const MAX_FILES = 120000;
const MAX_DEPTH = 12;

function albumIdFor(rootPath, rel) {
  return base64url(JSON.stringify([rootPath, rel]));
}

function decodeAlbumId(id) {
  try {
    const parsed = JSON.parse(fromBase64url(id));
    if (Array.isArray(parsed) && typeof parsed[0] === 'string') {
      return { rootPath: parsed[0], rel: String(parsed[1] || '') };
    }
  } catch {}
  return null;
}

function prettyAlbumName(root, rel) {
  if (!rel) return root.name;
  const parts = rel.split(/[\\/]/).filter(Boolean);
  const last = parts[parts.length - 1] || root.name;
  if (parts.length <= 1) return last;
  return `${parts[0]} / ${last}`;
}

class Library {
  constructor(store) {
    this.store = store;
    this.cache = new Map();
    this.favorites = new Set(store.config.favorites);
  }

  invalidate(rootId) {
    if (rootId) this.cache.delete(rootId);
    else this.cache.clear();
  }

  get roots() {
    return this.store.roots;
  }

  async scanRoot(root, force = false) {
    const cached = this.cache.get(root.id);
    if (!force && cached && Date.now() - cached.at < CACHE_TTL) return cached;
    const result = {
      at: Date.now(),
      root,
      files: [],
      albums: new Map(),
      error: null
    };
    const started = Date.now();
    try {
      const stat = await fsp.stat(root.path).catch(() => null);
      if (!stat || !stat.isDirectory()) throw new Error('文件夹不存在或已被移动');
      let count = 0;
      const walk = async (dir, rel, depth) => {
        if (depth > MAX_DEPTH || count >= MAX_FILES) return;
        let entries;
        try {
          entries = await fsp.readdir(dir, { withFileTypes: true });
        } catch {
          return;
        }
        entries.sort((a, b) => a.name.localeCompare(b.name, 'zh-CN'));
        const dirs = [];
        for (const entry of entries) {
          if (count >= MAX_FILES) break;
          const name = entry.name;
          if (name.startsWith('.') || SKIP_DIRS.has(name.toLowerCase())) continue;
          const full = path.join(dir, name);
          if (entry.isDirectory()) {
            dirs.push([full, rel ? path.join(rel, name) : name]);
          } else if (entry.isFile() && isMediaName(name)) {
            let fileStat;
            try {
              fileStat = await fsp.stat(full);
            } catch {
              continue;
            }
            const albumRel = rel || '';
            const photo = {
              id: base64url(full),
              path: full,
              name,
              ext: path.extname(name).toLowerCase(),
              mediaType: isVideoName(name) ? 'video' : 'image',
              size: fileStat.size,
              mtimeMs: fileStat.mtimeMs,
              t: Math.round(fileStat.mtimeMs),
              rootId: root.id,
              rootName: root.name,
              rel: albumRel,
              albumId: albumIdFor(root.path, albumRel),
              albumName: prettyAlbumName(root, albumRel)
            };
            result.files.push(photo);
            count += 1;
            let album = result.albums.get(photo.albumId);
            if (!album) {
              album = {
                id: photo.albumId,
                rootId: root.id,
                rootName: root.name,
                rel: albumRel,
                name: prettyAlbumName(root, albumRel),
                folderName: albumRel ? path.basename(albumRel) : root.name,
                count: 0,
                latest: 0,
                coverId: null
              };
              result.albums.set(photo.albumId, album);
            }
            album.count += 1;
            if (photo.mtimeMs >= album.latest) {
              album.latest = photo.mtimeMs;
              album.coverId = photo.id;
            }
          }
        }
        for (const [child, childRel] of dirs) {
          await walk(child, childRel, depth + 1);
        }
      };
      await walk(root.path, '', 0);
      result.files.sort((a, b) => b.mtimeMs - a.mtimeMs);
      result.stats = {
        count: result.files.length,
        albums: result.albums.size,
        bytes: result.files.reduce((sum, file) => sum + file.size, 0),
        scanMs: Date.now() - started
      };
      this.cache.set(root.id, result);
    } catch (error) {
      result.error = error.message || '扫描失败';
      this.cache.set(root.id, result);
    }
    return result;
  }

  async scanAll(force = false) {
    const results = [];
    for (const root of this.roots) {
      results.push(await this.scanRoot(root, force));
    }
    return results;
  }

  async getState({ includeFavorites = true } = {}) {
    const scans = await this.scanAll();
    const rootViews = [];
    const albums = [];
    let totalPhotos = 0;
    let totalBytes = 0;
    let favoritesCount = 0;
    const now = Date.now();
    let recentCount = 0;
    for (const scan of scans) {
      const root = scan.root;
      const rootAlbums = Array.from(scan.albums.values())
        .sort((a, b) => b.latest - a.latest)
        .map((album) => ({
          ...album,
          cover: album.coverId ? `/api/thumb?id=${encodeURIComponent(album.coverId)}&size=480` : null
        }));
      const view = {
        id: root.id,
        name: root.name,
        path: root.path,
        system: Boolean(root.system),
        auto: Boolean(root.auto),
        count: scan.files.length,
        bytes: scan.files.reduce((sum, file) => sum + file.size, 0),
        cover: scan.files[0] ? `/api/thumb?id=${encodeURIComponent(scan.files[0].id)}&size=480` : null,
        latest: scan.files[0] ? scan.files[0].mtimeMs : 0,
        error: scan.error,
        albums: rootAlbums
      };
      rootViews.push(view);
      albums.push(...rootAlbums);
      totalPhotos += view.count;
      totalBytes += view.bytes;
      for (const file of scan.files) {
        if (this.favorites.has(file.id)) favoritesCount += 1;
        if (now - file.mtimeMs < 30 * 86400000) recentCount += 1;
      }
    }
    return {
      roots: rootViews,
      albums,
      totalPhotos,
      totalBytes,
      favoritesCount: includeFavorites ? favoritesCount : 0,
      recentCount,
      stats: {
        roots: rootViews.length,
        albums: albums.length
      }
    };
  }

  async query(options = {}) {
    const {
      albumId = '',
      rootId = '',
      q = '',
      sort = 'desc',
      offset = 0,
      limit = 240,
      favorites = false,
      recent = false
    } = options;
    const needle = String(q || '').trim().toLowerCase();
    const targetAlbum = albumId ? decodeAlbumId(albumId) : null;
    let scans;
    if (targetAlbum) {
      const root = this.roots.find((item) => path.resolve(item.path).toLowerCase() === path.resolve(targetAlbum.rootPath).toLowerCase());
      scans = root ? [await this.scanRoot(root)] : [];
    } else if (rootId) {
      const root = this.roots.find((item) => item.id === rootId);
      scans = root ? [await this.scanRoot(root)] : [];
    } else {
      scans = await this.scanAll();
    }
    let files = [];
    for (const scan of scans) files.push(...scan.files);
    if (targetAlbum) {
      files = files.filter((file) => file.rel === targetAlbum.rel);
    }
    if (needle) {
      files = files.filter((file) =>
        file.name.toLowerCase().includes(needle) ||
        file.albumName.toLowerCase().includes(needle) ||
        file.rel.toLowerCase().includes(needle)
      );
    }
    if (favorites) files = files.filter((file) => this.favorites.has(file.id));
    if (recent) {
      const cutoff = Date.now() - 30 * 86400000;
      files = files.filter((file) => file.mtimeMs >= cutoff);
    }
    if (sort === 'asc') files.sort((a, b) => a.mtimeMs - b.mtimeMs);
    else if (sort === 'name') files.sort((a, b) => a.name.localeCompare(b.name, 'zh-CN'));
    else files.sort((a, b) => b.mtimeMs - a.mtimeMs);
    const total = files.length;
    const start = Math.max(0, Number(offset) || 0);
    const take = Math.max(1, Math.min(500, Number(limit) || 240));
    const slice = files.slice(start, start + take);
    return {
      total,
      offset: start,
      limit: take,
      hasMore: start + slice.length < total,
      items: slice.map((file) => this.publicPhoto(file))
    };
  }

  publicPhoto(file) {
    return {
      id: file.id,
      name: file.name,
      ext: file.ext,
      mediaType: file.mediaType || 'image',
      size: file.size,
      t: file.t,
      mtimeMs: file.mtimeMs,
      albumId: file.albumId,
      album: file.albumName,
      albumRel: file.rel,
      rootId: file.rootId,
      rootName: file.rootName,
      fav: this.favorites.has(file.id)
    };
  }

  getPhoto(id) {
    const filePath = fromBase64url(id);
    if (!filePath) return null;
    const resolved = path.resolve(filePath);
    const allowed = this.roots.some((root) => isInside(resolved, root.path));
    if (!allowed) return null;
    let stat;
    try {
      stat = fs.statSync(resolved);
    } catch {
      return null;
    }
    if (!stat.isFile() || !isMediaName(resolved)) return null;
    const root = this.roots.find((item) => isInside(resolved, item.path));
    if (!root) return null;
    const rel = path.relative(root.path, path.dirname(resolved));
    const photo = {
      id,
      path: resolved,
      name: path.basename(resolved),
      ext: path.extname(resolved).toLowerCase(),
      mediaType: isVideoName(resolved) ? 'video' : 'image',
      size: stat.size,
      mtimeMs: stat.mtimeMs,
      t: Math.round(stat.mtimeMs),
      rootId: root.id,
      rootName: root.name,
      rel: rel === '.' ? '' : rel,
      albumId: albumIdFor(root.path, rel === '.' ? '' : rel),
      albumName: prettyAlbumName(root, rel === '.' ? '' : rel)
    };
    return photo;
  }

  setFavorite(id, value) {
    this.store.setFavorite(id, value);
    this.favorites = new Set(this.store.config.favorites);
    return value;
  }

  isFavorite(id) {
    return this.favorites.has(id);
  }

  get trashDir() {
    return path.join(this.store.downloadDir, '.xphoto-trash');
  }

  async move(ids, targetAlbumId) {
    let decoded;
    try {
      decoded = JSON.parse(fromBase64url(targetAlbumId));
    } catch {
      return { moved: 0, skipped: 0, error: '目标相册无效' };
    }
    const [rootPath, rel = ''] = Array.isArray(decoded) ? decoded : [];
    const root = this.roots.find((item) => path.resolve(item.path) === path.resolve(rootPath || ''));
    if (!root) return { moved: 0, skipped: 0, error: '目标相册不在已添加的文件夹中' };
    const targetDir = path.join(root.path, rel);
    if (!isInside(targetDir, root.path)) return { moved: 0, skipped: 0, error: '目标路径无效' };
    fs.mkdirSync(targetDir, { recursive: true });
    let moved = 0;
    let skipped = 0;
    for (const id of Array.isArray(ids) ? ids : []) {
      const photo = this.getPhoto(id);
      if (!photo || photo.rootId !== root.id) { skipped += 1; continue; }
      if (path.dirname(photo.path) === targetDir) { skipped += 1; continue; }
      const target = uniqueFile(targetDir, photo.name);
      try {
        await fsp.rename(photo.path, target);
      } catch {
        try {
          await fsp.copyFile(photo.path, target);
          await fsp.unlink(photo.path);
        } catch {
          skipped += 1;
          continue;
        }
      }
      moved += 1;
    }
    if (moved) this.invalidate();
    return { moved, skipped };
  }

  async trash(ids) {
    fs.mkdirSync(this.trashDir, { recursive: true });
    const moved = [];
    for (const id of Array.isArray(ids) ? ids : []) {
      const photo = this.getPhoto(id);
      if (!photo) continue;
      const target = uniqueFile(this.trashDir, photo.name);
      try {
        await fsp.rename(photo.path, target);
      } catch {
        try {
          await fsp.copyFile(photo.path, target);
          await fsp.unlink(photo.path);
        } catch {
          continue;
        }
      }
      moved.push(target);
    }
    if (moved.length) this.invalidate();
    return moved.length;
  }

  trashList() {
    const dir = this.trashDir;
    let names = [];
    try {
      names = fs.readdirSync(dir);
    } catch {
      return [];
    }
    return names
      .map((name) => {
        const full = path.join(dir, name);
        try {
          const stat = fs.statSync(full);
          if (!stat.isFile() || !isMediaName(name)) return null;
          return {
            id: base64url(full),
            name,
            size: stat.size,
            t: Math.round(stat.mtimeMs),
            mtimeMs: stat.mtimeMs,
            mediaType: isVideoName(name) ? 'video' : 'image'
          };
        } catch {
          return null;
        }
      })
      .filter(Boolean)
      .sort((a, b) => b.mtimeMs - a.mtimeMs);
  }

  emptyTrash() {
    const dir = this.trashDir;
    try {
      fs.rmSync(dir, { recursive: true, force: true });
    } catch {
      return false;
    }
    fs.mkdirSync(dir, { recursive: true });
    return true;
  }

  async info(id) {
    const photo = this.getPhoto(id);
    if (!photo) throw new Error('照片不存在');
    return {
      ...this.publicPhoto(photo),
      path: photo.path
    };
  }

  findByPath(filePath) {
    const resolved = normalizePath(filePath);
    return this.roots.find((root) => isInside(resolved, root.path)) || null;
  }
}

module.exports = { Library, albumIdFor, decodeAlbumId };
