'use strict';

// Headless Edge screenshot + optional JS evaluation through CDP.
// Usage: node scripts/cdp-shot.js <url> <width> <height> <out.png> [eval-file] [waitMs]
const { spawn } = require('child_process');
const fs = require('fs');
const os = require('os');
const path = require('path');

const EDGE = 'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe';
const url = process.argv[2];
const width = Number(process.argv[3] || 1440);
const height = Number(process.argv[4] || 900);
const out = path.resolve(process.argv[5] || '.shots/cdp.png');
const evalFile = process.argv[6] || '';
const waitMs = Number(process.argv[7] || 5000);
const preloadFile = process.env.XPHOTO_PRELOAD || '';
const port = 9333 + Math.floor(Math.random() * 300);
const profile = path.join(os.tmpdir(), 'xphoto-edge-cdp', `${process.pid}-${Date.now()}`);

function sleep(ms) { return new Promise((resolve) => setTimeout(resolve, ms)); }

async function getTargets() {
  for (let i = 0; i < 60; i += 1) {
    try {
      const response = await fetch(`http://127.0.0.1:${port}/json/list`);
      const list = await response.json();
      const page = list.find((item) => item.type === 'page' && item.webSocketDebuggerUrl);
      if (page) return page;
    } catch {}
    await sleep(250);
  }
  throw new Error('Edge CDP target not found');
}

function connect(wsUrl) {
  return new Promise((resolve, reject) => {
    const ws = new WebSocket(wsUrl);
    const pending = new Map();
    let id = 0;
    ws.addEventListener('open', () => resolve({
      send(method, params = {}) {
        return new Promise((res, rej) => {
          const callId = ++id;
          pending.set(callId, { res, rej });
          ws.send(JSON.stringify({ id: callId, method, params }));
        });
      },
      close() { try { ws.close(); } catch {} }
    }));
    ws.addEventListener('message', (event) => {
      let message;
      try { message = JSON.parse(event.data); } catch { return; }
      if (message.method === 'Runtime.exceptionThrown') {
        const detail = message.params.exceptionDetails;
        console.error('EXCEPTION', detail.text, detail.exception && (detail.exception.description || detail.exception.value));
      }
      if (message.method === 'Runtime.consoleAPICalled' && message.params.type === 'error') {
        console.error('CONSOLE', (message.params.args || []).map((a) => a.value ?? a.description ?? '').join(' '));
      }
      if (!message.id || !pending.has(message.id)) return;
      const item = pending.get(message.id);
      pending.delete(message.id);
      if (message.error) item.rej(new Error(message.error.message || JSON.stringify(message.error)));
      else item.res(message.result);
    });
    ws.addEventListener('error', reject);
  });
}

(async () => {
  fs.mkdirSync(profile, { recursive: true });
  fs.mkdirSync(path.dirname(out), { recursive: true });
  const child = spawn(EDGE, [
    '--headless=new', '--disable-gpu', '--hide-scrollbars', '--no-first-run', '--force-device-scale-factor=1',
    '--no-default-browser-check', '--disable-extensions', '--mute-audio', '--disable-sync', '--no-proxy-server',
    '--disable-features=msEdgeSignin,msEdgeSync,msEdgeIdentity', '--no-service-autorun',
    `--remote-debugging-port=${port}`, `--user-data-dir=${profile}`,
    `--window-size=${width},${height}`, 'about:blank'
  ], { stdio: 'ignore', windowsHide: true });

  try {
    const target = await getTargets();
    const cdp = await connect(target.webSocketDebuggerUrl);
    await cdp.send('Page.enable');
    await cdp.send('Runtime.enable');
    await cdp.send('Emulation.setDeviceMetricsOverride', {
      width, height, deviceScaleFactor: 1, mobile: false
    });
    if (preloadFile) {
      await cdp.send('Page.addScriptToEvaluateOnNewDocument', {
        source: fs.readFileSync(preloadFile, 'utf8')
      });
    }
    await cdp.send('Page.navigate', { url });
    await sleep(waitMs);
    if (process.env.XPHOTO_GESTURE) {
      await cdp.send('Emulation.setTouchEmulationEnabled', { enabled: true, maxTouchPoints: 5 });
      const x = Math.round(width / 2);
      let y = Math.round(height * 0.7);
      await cdp.send('Input.dispatchTouchEvent', { type: 'touchStart', touchPoints: [{ x, y }] });
      for (let i = 0; i < 12; i += 1) {
        y -= 35;
        await cdp.send('Input.dispatchTouchEvent', { type: 'touchMove', touchPoints: [{ x, y }] });
        await sleep(16);
      }
      await cdp.send('Input.dispatchTouchEvent', { type: 'touchEnd', touchPoints: [] });
      await sleep(900);
    }
    if (evalFile) {
      const expression = fs.readFileSync(evalFile, 'utf8');
      const result = await cdp.send('Runtime.evaluate', {
        expression, awaitPromise: true, returnByValue: true, userGesture: true
      });
      console.log('EVAL ' + JSON.stringify(result.result && result.result.value !== undefined ? result.result.value : result, null, 2));
      await sleep(700);
    }
    const shot = await cdp.send('Page.captureScreenshot', { format: 'png', fromSurface: true });
    fs.writeFileSync(out, Buffer.from(shot.data, 'base64'));
    console.log('SHOT ' + out);
    try { await cdp.send('Browser.close'); } catch {}
    cdp.close();
  } finally {
    try { child.kill(); } catch {}
  }
})().catch((error) => { console.error('FATAL', error); process.exit(1); });
