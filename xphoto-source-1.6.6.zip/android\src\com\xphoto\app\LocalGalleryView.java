package com.xphoto.app;

import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.media.MediaMetadataRetriever;
import android.media.MediaScannerConnection;
import android.text.TextUtils;
import android.util.LruCache;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.BaseAdapter;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * The phone's own gallery. It is deliberately independent from the PC:
 * photos come from MediaStore, and files downloaded by the APK land in
 * Download/xphoto, which appears here as the "手机下载" folder.
 */
public class LocalGalleryView extends FrameLayout {
    public interface Listener {
        void onConnectRequested();
        void onPermissionRequested();
    }

    static final String FILTER_ALL = "__all__";
    static final String FILTER_DOWNLOAD = "__download__";
    static final String FILTER_RECYCLE = "__recycle__";

    private final Listener listener;
    private final ExecutorService io = Executors.newFixedThreadPool(2);
    private final Handler main = new Handler(Looper.getMainLooper());
    // 32MB in-memory thumbnail cache. It disappears with the process and never touches storage.
    private final LruCache<Long, Bitmap> thumbCache = new LruCache<Long, Bitmap>(32 * 1024) {
        @Override
        protected int sizeOf(Long key, Bitmap value) {
            return Math.max(1, value.getByteCount() / 1024);
        }
    };

    private final List<PhotoItem> all = new ArrayList<>();
    private final List<PhotoItem> shown = new ArrayList<>();
    private final List<Section> sections = new ArrayList<>();
    private final LinkedHashMap<String, Integer> buckets = new LinkedHashMap<>();

    private ListView list;
    private FrameLayout listWrap;
    private LinearLayout chipRow;
    private TextView title;
    private TextView subtitle;
    private TextView empty;
    private TextView dateBubble;
    private SectionAdapter adapter;
    private FastScroller fast;
    private ScaleGestureDetector scaleDetector;
    private float scaleAccumulator = 1f;
    private String filter = FILTER_ALL;
    private int columns;
    private boolean loading;
    private boolean permissionGranted = true;
    private final Set<Long> selectedIds = new HashSet<>();
    private boolean selecting;
    private LinearLayout selectionBar;
    private TextView selectionCount;

    public LocalGalleryView(Context context, Listener listener) {
        super(context);
        this.listener = listener;
        this.columns = Math.max(2, Math.min(6, context.getSharedPreferences(MainActivity.PREFS, Context.MODE_PRIVATE)
                .getInt("grid_cols", 3)));
        setBackgroundColor(0xFFF5F7FC);
        build();
        refresh();
    }

    private int dp(float value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private GradientDrawable rounded(int color, float radiusDp) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radiusDp));
        return d;
    }

    private void build() {
        LinearLayout page = new LinearLayout(getContext());
        page.setOrientation(LinearLayout.VERTICAL);
        page.setBackgroundColor(0xFFF5F7FC);
        page.setClipToPadding(false);

        LinearLayout header = new LinearLayout(getContext());
        header.setOrientation(LinearLayout.VERTICAL);
        header.setPadding(dp(20), dp(16), dp(20), dp(2));
        page.addView(header, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        title = new TextView(getContext());
        title.setText("照片");
        title.setTextColor(0xFF101828);
        title.setTextSize(27);
        title.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        header.addView(title);

        subtitle = new TextView(getContext());
        subtitle.setText("本机相册 · 正在读取…");
        subtitle.setTextColor(0xFF667085);
        subtitle.setTextSize(12);
        subtitle.setPadding(0, dp(4), 0, 0);
        header.addView(subtitle);

        HorizontalScrollView chipScroll = new HorizontalScrollView(getContext());
        chipScroll.setHorizontalScrollBarEnabled(false);
        chipScroll.setClipToPadding(false);
        LinearLayout.LayoutParams chipScrollParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        chipScrollParams.topMargin = dp(12);
        header.addView(chipScroll, chipScrollParams);

        chipRow = new LinearLayout(getContext());
        chipRow.setOrientation(LinearLayout.HORIZONTAL);
        chipRow.setPadding(dp(16), 0, dp(16), dp(8));
        chipScroll.addView(chipRow, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        listWrap = new FrameLayout(getContext());
        page.addView(listWrap, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        list = new ListView(getContext());
        list.setDivider(null);
        list.setDividerHeight(0);
        list.setSelector(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));
        list.setCacheColorHint(Color.TRANSPARENT);
        list.setVerticalScrollBarEnabled(false);
        list.setClipToPadding(false);
        list.setPadding(dp(13), dp(2), dp(30), dp(86));
        listWrap.addView(list, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        adapter = new SectionAdapter();
        list.setAdapter(adapter);

        fast = new FastScroller(getContext());
        FrameLayout.LayoutParams fastParams = new FrameLayout.LayoutParams(
                dp(30), ViewGroup.LayoutParams.MATCH_PARENT, Gravity.TOP | Gravity.END);
        fastParams.topMargin = dp(2);
        fastParams.bottomMargin = dp(86);
        listWrap.addView(fast, fastParams);
        fast.setListener(new FastScroller.Listener() {
            @Override
            public void onFraction(float fraction, float thumbTop) {
                if (sections.isEmpty()) return;
                int index = Math.round(fraction * (sections.size() - 1));
                index = Math.max(0, Math.min(sections.size() - 1, index));
                list.setSelection(adapter.positionOfSection(index));
                showDateBubble(index, thumbTop);
            }

            @Override
            public void onDrag(boolean dragging) {
                if (!dragging) hideDateBubble(0);
            }
        });

        dateBubble = new TextView(getContext());
        dateBubble.setTextColor(Color.WHITE);
        dateBubble.setTextSize(12);
        dateBubble.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        dateBubble.setGravity(Gravity.CENTER);
        dateBubble.setSingleLine(true);
        dateBubble.setPadding(dp(11), dp(6), dp(11), dp(6));
        dateBubble.setBackground(rounded(0xEE101828, 13));
        dateBubble.setElevation(dp(7));
        dateBubble.setVisibility(View.GONE);
        FrameLayout.LayoutParams bubbleParams = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.TOP | Gravity.END);
        bubbleParams.rightMargin = dp(38);
        listWrap.addView(dateBubble, bubbleParams);

        list.setOnScrollListener(new AbsListView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(AbsListView view, int scrollState) {}

            @Override
            public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {
                if (adapter.getCount() <= 1) {
                    fast.setProgress(0);
                    return;
                }
                fast.setProgress(firstVisibleItem / (float) (adapter.getCount() - 1));
                if (fast.isDragging() && !sections.isEmpty()) {
                    int section = adapter.sectionAt(firstVisibleItem);
                    showDateBubble(section, fast.getThumbTop());
                }
            }
        });

        scaleDetector = new ScaleGestureDetector(getContext(), new ScaleGestureDetector.SimpleOnScaleGestureListener() {
            @Override
            public boolean onScaleBegin(ScaleGestureDetector detector) {
                scaleAccumulator = 1f;
                return true;
            }

            @Override
            public boolean onScale(ScaleGestureDetector detector) {
                scaleAccumulator *= detector.getScaleFactor();
                if (scaleAccumulator > 1.28f) {
                    scaleAccumulator = 1f;
                    setColumns(columns - 1);
                } else if (scaleAccumulator < 0.78f) {
                    scaleAccumulator = 1f;
                    setColumns(columns + 1);
                }
                return true;
            }
        });
        list.setOnTouchListener((v, event) -> {
            scaleDetector.onTouchEvent(event);
            return false;
        });

        addView(page, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        empty = new TextView(getContext());
        empty.setText("还没有照片\n\n手机拍的照片会自动出现在这里");
        empty.setTextColor(0xFF7C8AA5);
        empty.setTextSize(13);
        empty.setGravity(Gravity.CENTER);
        empty.setLineSpacing(dp(3), 1f);
        empty.setPadding(dp(34), 0, dp(34), dp(90));
        empty.setVisibility(View.GONE);
        empty.setOnClickListener(v -> {
            if (!permissionGranted) listener.onPermissionRequested();
        });
        addView(empty, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        TextView fab = new TextView(getContext());
        fab.setText("连接电脑");
        fab.setTextColor(Color.WHITE);
        fab.setTextSize(13);
        fab.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        fab.setGravity(Gravity.CENTER);
        fab.setPadding(dp(18), 0, dp(18), 0);
        GradientDrawable fabBg = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                new int[]{0xFF356DF3, 0xFF7B5CFF});
        fabBg.setCornerRadius(dp(28));
        fab.setBackground(fabBg);
        fab.setElevation(dp(8));
        fab.setOnClickListener(v -> listener.onConnectRequested());
        FrameLayout.LayoutParams fabParams = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, dp(52), Gravity.BOTTOM | Gravity.END);
        fabParams.rightMargin = dp(18);
        fabParams.bottomMargin = dp(20);
        addView(fab, fabParams);

        selectionBar = new LinearLayout(getContext());
        selectionBar.setOrientation(LinearLayout.HORIZONTAL);
        selectionBar.setGravity(Gravity.CENTER_VERTICAL);
        selectionBar.setPadding(dp(10), dp(6), dp(10), dp(6));
        selectionBar.setBackground(rounded(0xF2111827, 16));
        selectionBar.setElevation(dp(12));
        selectionBar.setVisibility(View.GONE);
        selectionCount = new TextView(getContext());
        selectionCount.setTextColor(Color.WHITE);
        selectionCount.setTextSize(12);
        selectionCount.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        selectionCount.setPadding(dp(6), 0, dp(8), 0);
        selectionBar.addView(selectionCount);
        addSelectionAction("收藏", this::favoriteSelected);
        addSelectionAction("删除", this::deleteSelected);
        addSelectionAction("分享", this::shareSelected);
        addSelectionAction("取消", this::exitSelection);
        FrameLayout.LayoutParams selectionParams = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(54), Gravity.BOTTOM);
        selectionParams.leftMargin = dp(12);
        selectionParams.rightMargin = dp(12);
        selectionParams.bottomMargin = dp(14);
        addView(selectionBar, selectionParams);
    }

    private void addSelectionAction(String label, Runnable action) {
        TextView button = new TextView(getContext());
        button.setText(label);
        button.setTextColor(Color.WHITE);
        button.setTextSize(12);
        button.setGravity(Gravity.CENTER);
        button.setPadding(dp(12), dp(8), dp(12), dp(8));
        button.setOnClickListener(v -> action.run());
        selectionBar.addView(button, new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
    }

    public void setPermissionGranted(boolean granted) {
        permissionGranted = granted;
        if (!granted) {
            all.clear();
            shown.clear();
            sections.clear();
            adapter.notifyDataSetChanged();
            subtitle.setText("需要相册权限 · 点下方文字开启");
            empty.setText("允许 xphoto 访问手机照片\n\n点这里开启权限");
            empty.setVisibility(View.VISIBLE);
            rebuildChips();
        } else {
            empty.setText("还没有照片\n\n手机拍的照片会自动出现在这里");
            refresh();
        }
    }

    public void refresh() {
        if (!permissionGranted || loading) return;
        loading = true;
        subtitle.setText("本机相册 · 正在读取…");
        io.execute(() -> {
            List<PhotoItem> result = queryPhotos();
            main.post(() -> {
                loading = false;
                all.clear();
                all.addAll(result);
                int downloadCount = 0;
                int recycleCount = 0;
                buckets.clear();
                for (PhotoItem item : all) {
                    if (item.recycle) { recycleCount += 1; continue; }
                    if (item.download) downloadCount += 1;
                    if (!item.download) {
                        Integer old = buckets.get(item.bucket);
                        buckets.put(item.bucket, old == null ? 1 : old + 1);
                    }
                }
                if (filter.equals(FILTER_DOWNLOAD) && downloadCount == 0) filter = FILTER_ALL;
                if (!filter.equals(FILTER_ALL) && !filter.equals(FILTER_DOWNLOAD)
                        && !filter.equals(FILTER_RECYCLE) && !buckets.containsKey(filter)) {
                    filter = FILTER_ALL;
                }
                rebuildChips(downloadCount, recycleCount);
                applyFilter();
            });
        });
    }

    private List<PhotoItem> queryPhotos() {
        List<PhotoItem> result = new ArrayList<>();
        queryCollection(false, result);
        queryCollection(true, result);
        result.sort((a, b) -> Long.compare(b.date, a.date));
        return result;
    }

    private void queryCollection(boolean video, List<PhotoItem> result) {
        ContentResolver resolver = getContext().getContentResolver();
        boolean api29 = Build.VERSION.SDK_INT >= 29;
        Uri collection = video
                ? MediaStore.Video.Media.EXTERNAL_CONTENT_URI
                : MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
        String[] projection = api29
                ? new String[]{
                    MediaStore.MediaColumns._ID,
                    MediaStore.MediaColumns.DISPLAY_NAME,
                    MediaStore.MediaColumns.BUCKET_DISPLAY_NAME,
                    MediaStore.MediaColumns.DATE_ADDED,
                    MediaStore.MediaColumns.SIZE,
                    MediaStore.MediaColumns.RELATIVE_PATH,
                    MediaStore.MediaColumns.DATA}
                : new String[]{
                    MediaStore.MediaColumns._ID,
                    MediaStore.MediaColumns.DISPLAY_NAME,
                    MediaStore.MediaColumns.BUCKET_DISPLAY_NAME,
                    MediaStore.MediaColumns.DATE_ADDED,
                    MediaStore.MediaColumns.SIZE,
                    MediaStore.MediaColumns.DATA};
        try (Cursor cursor = resolver.query(collection, projection, null, null,
                MediaStore.MediaColumns.DATE_ADDED + " DESC")) {
            if (cursor == null) return;
            int idCol = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns._ID);
            int nameCol = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME);
            int bucketCol = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.BUCKET_DISPLAY_NAME);
            int dateCol = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_ADDED);
            int sizeCol = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.SIZE);
            int pathCol = cursor.getColumnIndex(api29
                    ? MediaStore.MediaColumns.RELATIVE_PATH : MediaStore.MediaColumns.DATA);
            int dataCol = cursor.getColumnIndex(MediaStore.MediaColumns.DATA);
            while (cursor.moveToNext()) {
                long id = cursor.getLong(idCol);
                String name = cursor.getString(nameCol);
                String bucket = cursor.getString(bucketCol);
                String path = pathCol >= 0 ? cursor.getString(pathCol) : null;
                if (TextUtils.isEmpty(path) && dataCol >= 0) path = cursor.getString(dataCol);
                long date = cursor.getLong(dateCol) * 1000L;
                long size = cursor.getLong(sizeCol);
                if (TextUtils.isEmpty(name)) name = video ? "视频" : "照片";
                if (TextUtils.isEmpty(bucket)) bucket = "其他";
                String lowerPath = path == null ? "" : path.toLowerCase(Locale.ROOT);
                String lowerBucket = bucket.toLowerCase(Locale.ROOT);
                boolean recycle = lowerPath.contains("pictures/xphoto/回收站")
                        || lowerPath.contains("pictures/xphoto/.trash");
                boolean download = !recycle && (lowerPath.contains("download/xphoto")
                        || lowerPath.contains("pictures/xphoto")
                        || lowerBucket.equals("xphoto")
                        || lowerBucket.equals("xphoto下载"));
                Uri uri = ContentUris.withAppendedId(collection, id);
                result.add(new PhotoItem(id, name, bucket, date, size, uri, download, video, recycle, path));
            }
        } catch (Exception ignored) {
        }
    }

    private void rebuildChips() {
        int downloadCount = 0;
        int recycleCount = 0;
        for (PhotoItem item : all) {
            if (item.recycle) recycleCount += 1;
            else if (item.download) downloadCount += 1;
        }
        rebuildChips(downloadCount, recycleCount);
    }

    private void rebuildChips(int downloadCount, int recycleCount) {
        chipRow.removeAllViews();
        int total = all.size() - recycleCount;
        addChip("全部  " + total, FILTER_ALL);
        if (downloadCount > 0) addChip("手机下载  " + downloadCount, FILTER_DOWNLOAD);
        for (Map.Entry<String, Integer> entry : buckets.entrySet()) {
            addChip(entry.getKey() + "  " + entry.getValue(), entry.getKey());
        }
        addChip("回收站  " + recycleCount, FILTER_RECYCLE);
        if (recycleCount > 0 && filter.equals(FILTER_RECYCLE)) {
            TextView clear = new TextView(getContext());
            clear.setText("清空回收站");
            clear.setTextSize(12.5f);
            clear.setTextColor(0xFFE5484D);
            clear.setPadding(dp(14), dp(8), dp(14), dp(8));
            clear.setOnClickListener(v -> emptyRecycle());
            chipRow.addView(clear);
        }
    }

    private void addChip(String label, String key) {
        TextView chip = new TextView(getContext());
        chip.setText(label);
        chip.setTextSize(12.5f);
        chip.setSingleLine(true);
        chip.setGravity(Gravity.CENTER);
        chip.setPadding(dp(14), dp(8), dp(14), dp(8));
        boolean active = key.equals(filter);
        chip.setTextColor(active ? Color.WHITE : 0xFF475467);
        GradientDrawable bg = rounded(active ? 0xFF356DF3 : 0xFFE9EEF8, 18);
        chip.setBackground(bg);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        params.rightMargin = dp(8);
        chipRow.addView(chip, params);
        chip.setOnClickListener(v -> {
            filter = key;
            rebuildChips();
            applyFilter();
        });
    }

    private void applyFilter() {
        shown.clear();
        for (PhotoItem item : all) {
            if (filter.equals(FILTER_ALL)) {
                if (!item.recycle) shown.add(item);
            } else if (filter.equals(FILTER_DOWNLOAD)) {
                if (item.download) shown.add(item);
            } else if (filter.equals(FILTER_RECYCLE)) {
                if (item.recycle) shown.add(item);
            } else if (filter.equals(item.bucket) && !item.recycle) shown.add(item);
        }
        buildSections();
        adapter.notifyDataSetChanged();
        list.setSelection(0);
        fast.setProgress(0);
        hideDateBubble(0);
        if (shown.isEmpty()) {
            empty.setVisibility(View.VISIBLE);
            subtitle.setText(filter.equals(FILTER_RECYCLE) ? "回收站是空的" : (all.isEmpty() ? "本机相册 · 0 个" : "这个相册是空的"));
        } else {
            empty.setVisibility(View.GONE);
            int recycleCount = 0;
            for (PhotoItem item : all) if (item.recycle) recycleCount += 1;
            int total = all.size() - recycleCount;
            subtitle.setText("本机 " + total + " 个 · 长按可收藏或删除");
        }
    }

    private boolean hasDownloads() {
        for (PhotoItem item : all) if (item.download) return true;
        return false;
    }

    private void setColumns(int value) {
        int next = Math.max(2, Math.min(6, value));
        if (next == columns) return;
        columns = next;
        adapter.rebuildPositions();
        adapter.notifyDataSetChanged();
        getContext().getSharedPreferences(MainActivity.PREFS, Context.MODE_PRIVATE)
                .edit().putInt("grid_cols", next).apply();
    }

    private Set<String> favoriteSet() {
        Set<String> saved = getContext().getSharedPreferences(MainActivity.PREFS, Context.MODE_PRIVATE)
                .getStringSet("favorites", null);
        return saved == null ? new HashSet<>() : new HashSet<>(saved);
    }

    private boolean isFavorite(PhotoItem item) {
        return favoriteSet().contains(item.uri.toString());
    }

    private void toggleFavorite(PhotoItem item) {
        Set<String> favorites = favoriteSet();
        if (!favorites.add(item.uri.toString())) favorites.remove(item.uri.toString());
        getContext().getSharedPreferences(MainActivity.PREFS, Context.MODE_PRIVATE)
                .edit().putStringSet("favorites", favorites).apply();
        adapter.notifyDataSetChanged();
        Toast.makeText(getContext(), favorites.contains(item.uri.toString()) ? "已收藏" : "已取消收藏", Toast.LENGTH_SHORT).show();
    }

    private void enterSelection(PhotoItem item) {
        selecting = true;
        selectedIds.clear();
        selectedIds.add(item.id);
        refreshSelection();
    }

    private void toggleSelection(PhotoItem item) {
        if (!selectedIds.add(item.id)) selectedIds.remove(item.id);
        if (selectedIds.isEmpty()) {
            exitSelection();
            return;
        }
        refreshSelection();
    }

    private void exitSelection() {
        selecting = false;
        selectedIds.clear();
        if (selectionBar != null) selectionBar.setVisibility(View.GONE);
        title.setText("照片");
        subtitle.setText("本机 " + shown.size() + " 个 · 长按可收藏或删除");
        if (adapter != null) adapter.notifyDataSetChanged();
    }

    private void refreshSelection() {
        if (selectionBar == null) return;
        selectionBar.setVisibility(View.VISIBLE);
        selectionCount.setText("已选 " + selectedIds.size() + " 项");
        title.setText("已选 " + selectedIds.size() + " 项");
        subtitle.setText("点图片继续选择 · 长按也可多选");
        if (adapter != null) adapter.notifyDataSetChanged();
    }

    private void selectSection(Section section) {
        selecting = true;
        selectedIds.clear();
        for (PhotoItem item : section.items) selectedIds.add(item.id);
        refreshSelection();
    }

    private void favoriteSelected() {
        Set<String> favorites = favoriteSet();
        for (PhotoItem item : all) {
            if (selectedIds.contains(item.id)) favorites.add(item.uri.toString());
        }
        getContext().getSharedPreferences(MainActivity.PREFS, Context.MODE_PRIVATE)
                .edit().putStringSet("favorites", favorites).apply();
        Toast.makeText(getContext(), "已收藏 " + selectedIds.size() + " 项", Toast.LENGTH_SHORT).show();
        exitSelection();
    }

    private void deleteSelected() {
        int count = selectedIds.size();
        for (PhotoItem item : new ArrayList<>(all)) {
            if (!selectedIds.contains(item.id)) continue;
            if (item.recycle) deletePermanently(item);
            else moveToRecycle(item);
        }
        Toast.makeText(getContext(), "已处理 " + count + " 项", Toast.LENGTH_SHORT).show();
        exitSelection();
    }

    private void shareSelected() {
        ArrayList<Uri> uris = new ArrayList<>();
        boolean anyVideo = false;
        for (PhotoItem item : all) {
            if (!selectedIds.contains(item.id)) continue;
            if (uris.size() >= 9) break;
            uris.add(item.uri);
            anyVideo |= item.video;
        }
        if (uris.isEmpty()) return;
        Intent intent;
        if (uris.size() == 1) {
            intent = new Intent(Intent.ACTION_SEND);
            intent.putExtra(Intent.EXTRA_STREAM, uris.get(0));
        } else {
            intent = new Intent(Intent.ACTION_SEND_MULTIPLE);
            intent.putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris);
        }
        intent.setType(anyVideo ? "video/*" : "image/*");
        // WeChat/QQ read the grant from ClipData; EXTRA_STREAM alone is not enough on many ROMs.
        ClipData clip = ClipData.newRawUri("xphoto", uris.get(0));
        for (int i = 1; i < uris.size(); i++) clip.addItem(new ClipData.Item(uris.get(i)));
        intent.setClipData(clip);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        try {
            Intent chooser = Intent.createChooser(intent, "分享到");
            chooser.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            getContext().startActivity(chooser);
        } catch (Exception error) {
            Toast.makeText(getContext(), "没有可用的分享应用", Toast.LENGTH_SHORT).show();
        }
    }

    static String fullLocation(PhotoItem item) {
        String value = item.location == null ? "" : item.location.trim();
        if (value.isEmpty()) return item.uri.toString();
        if (!value.startsWith("/")) value = "/storage/emulated/0/" + value;
        if (value.endsWith("/")) value += item.name;
        else if (!value.endsWith("/" + item.name) && !value.endsWith(item.name)) value += "/" + item.name;
        return value;
    }

    static void showLocation(Context context, PhotoItem item) {
        String full = fullLocation(item);
        int slash = full.lastIndexOf('/');
        String folder = slash > 0 ? full.substring(0, slash) : full;
        String message = "文件：\n" + full + "\n\n所在文件夹：\n" + folder
                + "\n\n媒体地址：\n" + item.uri;
        new AlertDialog.Builder(context)
                .setTitle(item.video ? "视频位置" : "图片位置")
                .setMessage(message)
                .setPositiveButton("复制路径", (dialog, which) -> {
                    ClipboardManager clipboard = (ClipboardManager) context
                            .getSystemService(Context.CLIPBOARD_SERVICE);
                    if (clipboard != null) {
                        clipboard.setPrimaryClip(ClipData.newPlainText("xphoto 路径", full));
                        Toast.makeText(context, "路径已复制", Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("关闭", null)
                .show();
    }

    private void itemMenu(PhotoItem item) {
        String favorite = isFavorite(item) ? "取消收藏" : "收藏";
        if (item.recycle) {
            new AlertDialog.Builder(getContext())
                    .setTitle(item.name)
                    .setItems(new String[]{"查看位置", "彻底删除"}, (dialog, which) -> {
                        if (which == 0) showLocation(getContext(), item);
                        else deletePermanently(item);
                    })
                    .setNegativeButton("取消", null)
                    .show();
            return;
        }
        new AlertDialog.Builder(getContext())
                .setTitle(item.name)
                .setItems(new String[]{favorite, "查看位置", "移到回收站"}, (dialog, which) -> {
                    if (which == 0) toggleFavorite(item);
                    else if (which == 1) showLocation(getContext(), item);
                    else moveToRecycle(item);
                })
                .setNegativeButton("取消", null)
                .show();
    }

    private void moveToRecycle(PhotoItem item) {
        ContentResolver resolver = getContext().getContentResolver();
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                ContentValues values = new ContentValues();
                values.put(MediaStore.MediaColumns.RELATIVE_PATH, "Pictures/xphoto/回收站/");
                values.put(MediaStore.MediaColumns.DISPLAY_NAME,
                        System.currentTimeMillis() + "_" + item.name.replace('/', '_'));
                int updated = resolver.update(item.uri, values, null, null);
                if (updated <= 0) throw new IllegalStateException("update failed");
            } else {
                File dir = new File(Environment.getExternalStoragePublicDirectory(
                        Environment.DIRECTORY_PICTURES), "xphoto/回收站");
                if (!dir.exists() && !dir.mkdirs()) throw new IllegalStateException("mkdir failed");
                File target = new File(dir, System.currentTimeMillis() + "_" + item.name);
                try (InputStream in = resolver.openInputStream(item.uri);
                     FileOutputStream out = new FileOutputStream(target)) {
                    if (in == null) throw new IllegalStateException("open failed");
                    byte[] buffer = new byte[64 * 1024];
                    int read;
                    while ((read = in.read(buffer)) > 0) out.write(buffer, 0, read);
                }
                resolver.delete(item.uri, null, null);
                MediaScannerConnection.scanFile(getContext(), new String[]{target.getAbsolutePath()}, null, null);
            }
            Toast.makeText(getContext(), "已移到回收站", Toast.LENGTH_SHORT).show();
            refresh();
        } catch (Exception error) {
            Toast.makeText(getContext(), "系统不允许移动这个文件，请在系统相册里删除", Toast.LENGTH_LONG).show();
        }
    }

    private void deletePermanently(PhotoItem item) {
        try {
            getContext().getContentResolver().delete(item.uri, null, null);
            Toast.makeText(getContext(), "已彻底删除", Toast.LENGTH_SHORT).show();
            refresh();
        } catch (Exception error) {
            Toast.makeText(getContext(), "系统不允许删除这个文件", Toast.LENGTH_LONG).show();
        }
    }

    /** Recycle items for the connected WebView sidebar. */
    public String recycleJson() {
        JSONArray out = new JSONArray();
        for (PhotoItem item : new ArrayList<>(all)) {
            if (!item.recycle) continue;
            try {
                JSONObject entry = new JSONObject();
                entry.put("id", item.uri.toString());
                entry.put("name", item.name);
                entry.put("size", item.size);
                entry.put("date", item.date);
                entry.put("uri", item.uri.toString());
                entry.put("mediaType", item.video ? "video" : "image");
                entry.put("folder", "手机回收站");
                out.put(entry);
            } catch (Exception ignored) {
            }
        }
        return out.toString();
    }

    /** Permanently delete everything in the phone recycle folder. */
    public int emptyRecycleNow() {
        int removed = 0;
        for (PhotoItem item : new ArrayList<>(all)) {
            if (!item.recycle) continue;
            try {
                if (getContext().getContentResolver().delete(item.uri, null, null) > 0) removed += 1;
            } catch (Exception ignored) {
            }
        }
        if (removed > 0) refresh();
        return removed;
    }

    private void emptyRecycle() {
        int recycleCount = 0;
        for (PhotoItem item : all) if (item.recycle) recycleCount += 1;
        if (recycleCount == 0) return;
        new AlertDialog.Builder(getContext())
                .setTitle("清空回收站？")
                .setMessage(recycleCount + " 个文件会被永久删除，无法恢复。")
                .setNegativeButton("取消", null)
                .setPositiveButton("清空", (dialog, which) -> {
                    int removed = 0;
                    for (PhotoItem item : new ArrayList<>(all)) {
                        if (!item.recycle) continue;
                        try {
                            if (getContext().getContentResolver().delete(item.uri, null, null) > 0) removed += 1;
                        } catch (Exception ignored) {}
                    }
                    Toast.makeText(getContext(), "已永久删除 " + removed + " 个文件", Toast.LENGTH_SHORT).show();
                    refresh();
                })
                .show();
    }

    private void buildSections() {
        sections.clear();
        SimpleDateFormat keyFormat = new SimpleDateFormat("yyyyMMdd", Locale.CHINA);
        String lastKey = null;
        Section current = null;
        for (int i = 0; i < shown.size(); i++) {
            PhotoItem item = shown.get(i);
            String key = keyFormat.format(new Date(item.date));
            if (!key.equals(lastKey)) {
                current = new Section();
                current.label = dateLabel(item.date);
                current.start = i;
                sections.add(current);
                lastKey = key;
            }
            if (current != null) current.items.add(item);
        }
        if (adapter != null) adapter.rebuildPositions();
    }

    private String dateLabel(long millis) {
        Calendar date = Calendar.getInstance();
        date.setTimeInMillis(millis);
        Calendar today = Calendar.getInstance();
        String day;
        if (date.get(Calendar.YEAR) == today.get(Calendar.YEAR)
                && date.get(Calendar.DAY_OF_YEAR) == today.get(Calendar.DAY_OF_YEAR)) {
            day = "今天";
        } else {
            today.add(Calendar.DAY_OF_YEAR, -1);
            if (date.get(Calendar.YEAR) == today.get(Calendar.YEAR)
                    && date.get(Calendar.DAY_OF_YEAR) == today.get(Calendar.DAY_OF_YEAR)) {
                day = "昨天";
            } else if (date.get(Calendar.YEAR) != today.get(Calendar.YEAR)) {
                day = new SimpleDateFormat("yyyy年M月d日", Locale.CHINA).format(new Date(millis));
            } else {
                day = new SimpleDateFormat("M月d日", Locale.CHINA).format(new Date(millis));
            }
        }
        String week = new SimpleDateFormat("EEEE", Locale.CHINA).format(new Date(millis));
        return day + "  " + week;
    }

    private void toggleFilter(String key) {
        filter = key;
        rebuildChips();
        applyFilter();
    }

    private void showDateBubble(int sectionIndex, float thumbTop) {
        if (sections.isEmpty() || dateBubble == null) return;
        main.removeCallbacks(hideBubbleRunnable);
        int index = Math.max(0, Math.min(sections.size() - 1, sectionIndex));
        dateBubble.setText(sections.get(index).label);
        dateBubble.setVisibility(View.VISIBLE);
        FrameLayout.LayoutParams params = (FrameLayout.LayoutParams) dateBubble.getLayoutParams();
        int maxTop = Math.max(dp(4), listWrap.getHeight() - dp(34));
        params.topMargin = Math.max(dp(4), Math.min(maxTop, (int) thumbTop - dp(11)));
        dateBubble.setLayoutParams(params);
    }

    private void hideDateBubble(long delay) {
        if (dateBubble == null) return;
        main.removeCallbacks(hideBubbleRunnable);
        if (delay <= 0) dateBubble.setVisibility(View.GONE);
        else main.postDelayed(hideBubbleRunnable, delay);
    }

    private final Runnable hideBubbleRunnable = () -> {
        if (dateBubble != null) dateBubble.setVisibility(View.GONE);
    };

    public void clearThumbCache() {
        thumbCache.evictAll();
    }

    private Bitmap loadThumb(PhotoItem item) {
        // Video first: several Android builds return a generic “play” poster from
        // loadThumbnail() for HEVC/3GP clips. Decoding one local frame is both
        // truthful and fast, because the result is cached in memory.
        if (item.video) {
            Bitmap frame = videoFrame(item);
            if (frame != null) return frame;
        }
        Bitmap bitmap = null;
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                bitmap = getContext().getContentResolver().loadThumbnail(
                        item.uri, new android.util.Size(dp(180), dp(180)), null);
            } else if (item.video) {
                bitmap = MediaStore.Video.Thumbnails.getThumbnail(
                        getContext().getContentResolver(), item.id,
                        MediaStore.Video.Thumbnails.MINI_KIND, null);
            } else {
                bitmap = MediaStore.Images.Thumbnails.getThumbnail(
                        getContext().getContentResolver(), item.id,
                        MediaStore.Images.Thumbnails.MINI_KIND, null);
            }
        } catch (Exception | OutOfMemoryError ignored) {
            bitmap = null;
        }
        return bitmap;
    }

    /** Some devices return no MediaStore poster for a video; grab a local first frame instead. */
    private Bitmap videoFrame(PhotoItem item) {
        MediaMetadataRetriever retriever = new MediaMetadataRetriever();
        try {
            retriever.setDataSource(getContext(), item.uri);
            int width = dp(360);
            Bitmap frame = Build.VERSION.SDK_INT >= 27
                    ? retriever.getScaledFrameAtTime(1000, MediaMetadataRetriever.OPTION_CLOSEST_SYNC, width, width)
                    : retriever.getFrameAtTime(1000, MediaMetadataRetriever.OPTION_CLOSEST_SYNC);
            return frame;
        } catch (Exception | OutOfMemoryError ignored) {
            return null;
        } finally {
            try { retriever.release(); } catch (Exception ignored) {}
        }
    }

    private static class Section {
        String label;
        int start;
        final List<PhotoItem> items = new ArrayList<>();
    }

    private class SectionAdapter extends BaseAdapter {
        private final List<Integer> rowSection = new ArrayList<>();
        private final List<Integer> rowStart = new ArrayList<>();
        private int[] sectionPositions = new int[0];

        void rebuildPositions() {
            rowSection.clear();
            rowStart.clear();
            sectionPositions = new int[sections.size()];
            for (int s = 0; s < sections.size(); s++) {
                Section section = sections.get(s);
                sectionPositions[s] = rowSection.size();
                rowSection.add(s);
                rowStart.add(-1);
                for (int i = 0; i < section.items.size(); i += columns) {
                    rowSection.add(s);
                    rowStart.add(i);
                }
            }
        }

        int positionOfSection(int sectionIndex) {
            if (sectionIndex < 0 || sectionIndex >= sectionPositions.length) return 0;
            return sectionPositions[sectionIndex];
        }

        int sectionAt(int position) {
            if (rowSection.isEmpty()) return 0;
            int index = Math.max(0, Math.min(rowSection.size() - 1, position));
            return rowSection.get(index);
        }

        @Override
        public int getCount() {
            return rowSection.size();
        }

        @Override
        public Object getItem(int position) {
            return rowSection.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            if (position < 0 || position >= rowSection.size()) return new View(getContext());
            int sectionIndex = rowSection.get(position);
            int start = rowStart.get(position);
            Section section = sections.get(sectionIndex);
            if (start < 0) {
                LinearLayout header = new LinearLayout(getContext());
                header.setGravity(Gravity.CENTER_VERTICAL);
                header.setPadding(dp(4), dp(14), dp(8), dp(7));
                TextView label = new TextView(getContext());
                label.setText(section.label + "    " + section.items.size() + " 项");
                label.setTextColor(0xFF344054);
                label.setTextSize(13.5f);
                label.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
                header.addView(label, new LinearLayout.LayoutParams(
                        0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
                TextView all = new TextView(getContext());
                all.setText("全选");
                all.setTextColor(0xFF356DF3);
                all.setTextSize(12);
                all.setPadding(dp(10), dp(4), dp(6), dp(4));
                all.setOnClickListener(v -> selectSection(section));
                header.addView(all);
                return header;
            }

            LinearLayout row = new LinearLayout(getContext());
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setPadding(0, 0, 0, dp(3));
            for (int column = 0; column < columns; column++) {
                int itemIndex = start + column;
                if (itemIndex < section.items.size()) {
                    PhotoItem item = section.items.get(itemIndex);
                    FrameLayout cell = new FrameLayout(getContext());
                    SquareImageView image = new SquareImageView(getContext());
                    image.setScaleType(ImageView.ScaleType.CENTER_CROP);
                    image.setBackgroundColor(0xFFE7ECF6);
                    cell.addView(image, new FrameLayout.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
                    LinearLayout.LayoutParams cellParams = new LinearLayout.LayoutParams(
                            0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
                    cellParams.rightMargin = dp(2);
                    row.addView(cell, cellParams);
                    image.setTag(item.id);
                    if (item.video) {
                        TextView badge = new TextView(getContext());
                        badge.setText("▶");
                        badge.setTextColor(Color.WHITE);
                        badge.setTextSize(10);
                        badge.setGravity(Gravity.CENTER);
                        badge.setBackground(rounded(0x99000000, 12));
                        FrameLayout.LayoutParams badgeParams = new FrameLayout.LayoutParams(
                                dp(24), dp(24), Gravity.LEFT | Gravity.BOTTOM);
                        badgeParams.leftMargin = dp(6);
                        badgeParams.bottomMargin = dp(6);
                        cell.addView(badge, badgeParams);
                    }
                    if (isFavorite(item)) {
                        TextView heart = new TextView(getContext());
                        heart.setText("♥");
                        heart.setTextColor(0xFFFF5C7A);
                        heart.setTextSize(16);
                        heart.setGravity(Gravity.CENTER);
                        FrameLayout.LayoutParams heartParams = new FrameLayout.LayoutParams(
                                dp(24), dp(24), Gravity.RIGHT | Gravity.TOP);
                        heartParams.topMargin = dp(5);
                        heartParams.rightMargin = dp(5);
                        cell.addView(heart, heartParams);
                    }
                    Bitmap cached = thumbCache.get(item.id);
                    if (cached != null) {
                        image.setImageBitmap(cached);
                    } else {
                        image.setImageDrawable(null);
                        io.execute(() -> {
                            Bitmap bitmap = loadThumb(item);
                            if (bitmap != null) thumbCache.put(item.id, bitmap);
                            main.post(() -> {
                                if (bitmap != null && Long.valueOf(item.id).equals(image.getTag())) {
                                    image.setImageBitmap(bitmap);
                                }
                            });
                        });
                    }
                    if (selectedIds.contains(item.id)) {
                        image.setAlpha(0.72f);
                        TextView check = new TextView(getContext());
                        check.setText("✓");
                        check.setTextColor(Color.WHITE);
                        check.setTextSize(13);
                        check.setGravity(Gravity.CENTER);
                        check.setBackground(rounded(0xFF356DF3, 12));
                        FrameLayout.LayoutParams checkParams = new FrameLayout.LayoutParams(
                                dp(24), dp(24), Gravity.LEFT | Gravity.TOP);
                        checkParams.leftMargin = dp(6);
                        checkParams.topMargin = dp(6);
                        cell.addView(check, checkParams);
                    }
                    final int viewerIndex = section.start + itemIndex;
                    cell.setOnClickListener(v -> {
                        if (selecting) {
                            toggleSelection(item);
                            return;
                        }
                        if (item.video && PhotoViewerDialog.playExternal(getContext(), item.uri)) return;
                        PhotoViewerDialog.show(getContext(), new ArrayList<>(shown), viewerIndex);
                    });
                    cell.setOnLongClickListener(v -> {
                        if (selecting) toggleSelection(item);
                        else enterSelection(item);
                        return true;
                    });
                } else {
                    View spacer = new View(getContext());
                    row.addView(spacer, new LinearLayout.LayoutParams(
                            0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
                }
            }
            return row;
        }
    }

    static class FastScroller extends View {
        interface Listener {
            void onFraction(float fraction, float thumbTop);
            void onDrag(boolean dragging);
        }

        private final Paint trackPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint thumbPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final float density;
        private Listener listener;
        private float progress;
        private boolean dragging;
        private int thumbTop;

        FastScroller(Context context) {
            super(context);
            density = context.getResources().getDisplayMetrics().density;
            trackPaint.setColor(0xFFE1E7F2);
            thumbPaint.setColor(0xFF356DF3);
            setWillNotDraw(false);
        }

        void setListener(Listener listener) {
            this.listener = listener;
        }

        void setProgress(float value) {
            progress = Math.max(0f, Math.min(1f, value));
            invalidate();
        }

        boolean isDragging() {
            return dragging;
        }

        int getThumbTop() {
            return thumbTop;
        }

        private int thumbHeight() {
            return Math.max(dp(46), getHeight() / 5);
        }

        private int dp(float value) {
            return Math.round(value * density);
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            int width = getWidth();
            int height = getHeight();
            if (height <= 0) return;
            float x = width / 2f;
            float trackTop = dp(10);
            float trackBottom = height - dp(10);
            trackPaint.setStrokeWidth(dp(2));
            canvas.drawLine(x, trackTop, x, trackBottom, trackPaint);
            int thumbH = thumbHeight();
            int top = Math.round(trackTop + (trackBottom - trackTop - thumbH) * progress);
            thumbTop = top;
            thumbPaint.setStrokeWidth(dp(4));
            thumbPaint.setStrokeCap(Paint.Cap.ROUND);
            canvas.drawLine(x, top + dp(4), x, top + thumbH - dp(4), thumbPaint);
        }

        @Override
        public boolean onTouchEvent(MotionEvent event) {
            switch (event.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                case MotionEvent.ACTION_MOVE:
                    dragging = true;
                    getParent().requestDisallowInterceptTouchEvent(true);
                    float top = dp(10);
                    float bottom = getHeight() - dp(10);
                    float fraction = (event.getY() - top) / Math.max(1f, bottom - top);
                    fraction = Math.max(0f, Math.min(1f, fraction));
                    progress = fraction;
                    invalidate();
                    if (listener != null) listener.onFraction(fraction, thumbTop);
                    return true;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    dragging = false;
                    if (listener != null) listener.onDrag(false);
                    return true;
            }
            return super.onTouchEvent(event);
        }
    }
}

class PhotoItem {
    final long id;
    final String name;
    final String bucket;
    final long date;
    final long size;
    final Uri uri;
    final boolean download;
    final boolean video;
    final boolean recycle;
    final String location;

    PhotoItem(long id, String name, String bucket, long date, long size, Uri uri, boolean download,
              boolean video, boolean recycle, String location) {
        this.id = id;
        this.name = name;
        this.bucket = bucket;
        this.date = date;
        this.size = size;
        this.uri = uri;
        this.download = download;
        this.video = video;
        this.recycle = recycle;
        this.location = location;
    }
}

class SquareImageView extends ImageView {
    SquareImageView(Context context) {
        super(context);
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        super.onMeasure(widthMeasureSpec, widthMeasureSpec);
    }
}
