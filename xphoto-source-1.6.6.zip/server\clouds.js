'use strict';

const path = require('path');
const fsp = require('fs').promises;
const crypto = require('crypto');
const {
  isImageName,
  safeName,
  uniqueFile,
  ensureDir,
  parseDate,
  decodeEntities,
  escapeXml,
  sleep
} = require('./util');

const API_123 = 'https://open-api.123pan.com';
const WEBDAV_XML = `<?xml version="1.0" encoding="UTF-8"?>
<d:propfind xmlns:d="DAV:" xmlns:oc="http://owncloud.org/ns" xmlns:nc="http://nextcloud.org/ns">
  <d:prop>
    <d:displayname/>
    <d:resourcetype/>
    <d:getcontentlength/>
    <d:getcontenttype/>
    <d:getlastmodified/>
    <d:getetag/>
    <oc:size/>
  </d:prop>
</d:propfind>`;

class CloudError extends Error {
  constructor(message, status = 400) {
    super(message);
    this.status = status;
  }
}

function normalizeBaseUrl(input) {
  let value = String(input || '').trim();
  if (!value) throw new CloudError('请填写 WebDAV 地址');
  if (!/^https?:\/\//i.test(value)) value = `https://${value}`;
  const url = new URL(value);
  if (!url.pathname.endsWith('/')) url.pathname += '/';
  return url.toString();
}

function basicAuth(username, password) {
  return `Basic ${Buffer.from(`${username || ''}:${password || ''}`, 'utf8').toString('base64')}`;
}

function tagContent(xml, tag) {
  const re = new RegExp(`<(?:[\\w.-]+:)?${tag}\\b[^>]*>([\\s\\S]*?)</(?:[\\w.-]+:)?${tag}>`, 'i');
  const match = xml.match(re);
  return match ? decodeEntities(match[1]) : '';
}

function hasSelfClosing(xml, tag) {
  return new RegExp(`<(?:[\\w.-]+:)?${tag}\\b[^>]*/>`, 'i').test(xml);
}

function parseWebDav(xml) {
  const responses = [];
  const re = /<(?:[\w.-]+:)?response\b[^>]*>([\s\S]*?)<\/(?:[\w.-]+:)?response>/gi;
  let match;
  while ((match = re.exec(xml))) {
    const chunk = match[1];
    const href = tagContent(chunk, 'href');
    if (!href) continue;
    const isFolder = /<(?:[\w.-]+:)?collection\b/i.test(chunk) || hasSelfClosing(chunk, 'collection');
    const displayname = tagContent(chunk, 'displayname');
    const length = Number(tagContent(chunk, 'getcontentlength') || tagContent(chunk, 'size') || 0) || 0;
    const modified = tagContent(chunk, 'getlastmodified');
    const contentType = tagContent(chunk, 'getcontenttype');
    responses.push({
      href,
      displayname: decodeEntities(displayname || ''),
      isFolder,
      size: length,
      modified: parseDate(modified),
      contentType
    });
  }
  return responses;
}

function fetchWithTimeout(url, options = {}, timeout = 30000) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeout);
  return fetch(url, { ...options, signal: controller.signal }).finally(() => clearTimeout(timer));
}

class CloudManager {
  constructor(store, media) {
    this.store = store;
    this.media = media;
    this.downloadCache = new Map();
    this.tokenCache = new Map();
    this.lastDownloadAt = 0;
    this.queue = Promise.resolve();
  }

  publicList() {
    return this.store.clouds.map((cloud) => ({
      id: cloud.id,
      type: cloud.type,
      name: cloud.name,
      createdAt: cloud.createdAt,
      updatedAt: cloud.updatedAt,
      status: cloud.status || 'ok'
    }));
  }

  typeLabel(type) {
    return type === '123' ? '123云盘' : type === 'webdav' ? 'WebDAV' : type;
  }

  async test(input) {
    const cloud = this.prepare(input, true);
    if (cloud.type === '123') {
      await this.ensureToken(cloud);
      await this.list123(cloud, '0', 1);
    } else {
      await this.listWebdav(cloud, '');
    }
    return {
      ok: true,
      message: cloud.type === '123' ? '123云盘连接成功' : 'WebDAV 连接成功',
      name: cloud.name
    };
  }

  prepare(input, forTest = false) {
    const type = input.type === 'webdav' ? 'webdav' : '123';
    const name = String(input.name || '').trim().slice(0, 40) || this.typeLabel(type);
    if (type === '123') {
      const clientID = String(input.clientID || input.clientId || '').trim();
      const clientSecret = String(input.clientSecret || '').trim();
      if (!clientID || !clientSecret) throw new CloudError('请填写 123云盘开放平台的 clientID 与 clientSecret');
      return {
        id: input.id || crypto.randomBytes(6).toString('hex'),
        type,
        name,
        data: { clientID, clientSecret },
        state: input.state || {},
        createdAt: input.createdAt || Date.now(),
        updatedAt: Date.now()
      };
    }
    const url = normalizeBaseUrl(input.url);
    const username = String(input.username || '').trim();
    const password = String(input.password || '');
    if (!username || !password) throw new CloudError('请填写 WebDAV 用户名与应用密码');
    return {
      id: input.id || crypto.randomBytes(6).toString('hex'),
      type,
      name,
      data: { url, username, password },
      state: input.state || {},
      createdAt: input.createdAt || Date.now(),
      updatedAt: Date.now()
    };
  }

  async create(input) {
    const cloud = this.prepare(input);
    if (cloud.type === '123') {
      await this.ensureToken(cloud);
      await this.list123(cloud, '0', 1);
    } else {
      await this.listWebdav(cloud, '');
    }
    cloud.status = 'ok';
    this.store.addCloud(cloud);
    return this.publicList().find((item) => item.id === cloud.id);
  }

  async ensureToken(cloud, force = false) {
    if (cloud.type !== '123') return null;
    const state = cloud.state || {};
    if (!force && state.accessToken && state.expiresAt && state.expiresAt > Date.now() + 3600 * 1000) {
      return state.accessToken;
    }
    const cacheKey = crypto.createHash('sha1')
      .update(`${cloud.data.clientID}\u0000${cloud.data.clientSecret}`)
      .digest('hex');
    const cached = this.tokenCache.get(cacheKey);
    if (!force && cached && cached.expiresAt > Date.now() + 3600 * 1000) {
      cloud.state = { accessToken: cached.token, expiresAt: cached.expiresAt };
      return cached.token;
    }
    const response = await fetchWithTimeout(`${API_123}/api/v1/access_token`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Platform: 'open_platform'
      },
      body: JSON.stringify({
        clientID: cloud.data.clientID,
        clientSecret: cloud.data.clientSecret
      })
    }, 25000);
    let payload;
    try {
      payload = await response.json();
    } catch {
      throw new CloudError('123云盘返回了无法解析的内容，请稍后再试');
    }
    if (!response.ok || payload.code !== 0) {
      throw new CloudError(`123云盘授权失败：${payload.message || response.status}`);
    }
    cloud.state = {
      accessToken: payload.data.accessToken,
      expiresAt: Date.parse(payload.data.expiredAt) || Date.now() + 29 * 86400000
    };
    this.tokenCache.set(cacheKey, { token: cloud.state.accessToken, expiresAt: cloud.state.expiresAt });
    if (cloud.id) {
      try {
        this.store.updateCloud(cloud.id, { state: cloud.state, status: 'ok' });
      } catch {}
    }
    return cloud.state.accessToken;
  }

  async list(id, folder = '') {
    const cloud = this.store.getCloud(id);
    if (!cloud) throw new CloudError('云盘不存在', 404);
    return cloud.type === '123' ? this.list123(cloud, folder || '0') : this.listWebdav(cloud, folder || '');
  }

  async list123(cloud, parentFileId = '0', maxPages = 20) {
    const token = await this.ensureToken(cloud);
    let lastFileId = 0;
    let page = 0;
    const folders = [];
    const files = [];
    let total = 0;
    while (page < maxPages) {
      const query = new URLSearchParams({
        parentFileId: String(parentFileId || '0'),
        limit: '100'
      });
      if (lastFileId) query.set('lastFileId', String(lastFileId));
      const response = await fetchWithTimeout(`${API_123}/api/v2/file/list?${query}`, {
        headers: {
          Authorization: `Bearer ${token}`,
          Platform: 'open_platform'
        }
      }, 25000);
      const payload = await response.json().catch(() => null);
      if (!response.ok || !payload || payload.code !== 0) {
        if (payload && payload.code === 401) {
          cloud.state = {};
          try { this.store.updateCloud(cloud.id, { state: {}, status: 'expired' }); } catch {}
          throw new CloudError('123云盘授权已过期，请重新添加或检查密钥', 401);
        }
        throw new CloudError(`123云盘读取失败：${(payload && payload.message) || response.status}`);
      }
      const data = payload.data || {};
      const list = Array.isArray(data.fileList) ? data.fileList : [];
      for (const item of list) {
        if (item.trashed === 1) continue;
        if (typeof item.status === 'number' && item.status > 100) continue;
        const filename = item.filename || item.fileName || item.name || '未命名';
        if (item.type === 1) {
          folders.push({
            key: `folder:${item.fileId}`,
            id: String(item.fileId),
            name: filename,
            kind: 'folder',
            t: parseDate(item.updateAt || item.createAt)
          });
        } else if (this.isCloudImage(filename, item.category)) {
          files.push({
            key: `file:${item.fileId}`,
            id: String(item.fileId),
            name: filename,
            kind: 'image',
            size: Number(item.size) || 0,
            t: parseDate(item.updateAt || item.createAt),
            etag: item.etag || ''
          });
        }
      }
      total += list.length;
      lastFileId = data.lastFileId;
      page += 1;
      if (!lastFileId || lastFileId === -1 || list.length === 0 || total >= 800) break;
    }
    folders.sort((a, b) => a.name.localeCompare(b.name, 'zh-CN'));
    files.sort((a, b) => b.t - a.t);
    return {
      type: '123',
      folder: String(parentFileId || '0'),
      folders,
      files,
      total: files.length
    };
  }

  async listWebdav(cloud, folder = '') {
    const base = cloud.data.url;
    const target = folder || base;
    const response = await fetchWithTimeout(target, {
      method: 'PROPFIND',
      headers: {
        Authorization: basicAuth(cloud.data.username, cloud.data.password),
        Depth: '1',
        'Content-Type': 'application/xml; charset=utf-8',
        'User-Agent': 'xphoto/1.0 WebDAV client'
      },
      body: WEBDAV_XML
    }, 35000);
    const text = await response.text();
    if (response.status === 401) throw new CloudError('WebDAV 认证失败：请使用应用密码，而不是登录密码', 401);
    if (response.status === 404) throw new CloudError('WebDAV 路径不存在', 404);
    if (response.status !== 207) {
      throw new CloudError(`WebDAV 读取失败：HTTP ${response.status}`);
    }
    const targetUrl = new URL(target);
    const targetPath = decodeURIComponent(targetUrl.pathname).replace(/\/+$/, '');
    const entries = parseWebDav(text);
    const folders = [];
    const files = [];
    for (const entry of entries) {
      let absolute;
      try {
        absolute = new URL(entry.href, base).toString();
      } catch {
        continue;
      }
      const entryUrl = new URL(absolute);
      const entryPath = decodeURIComponent(entryUrl.pathname).replace(/\/+$/, '');
      if (entryPath === targetPath) continue;
      const name = entry.displayname || decodeURIComponent(entryUrl.pathname.split('/').filter(Boolean).pop() || '未命名');
      if (entry.isFolder) {
        folders.push({
          key: `folder:${absolute}`,
          id: absolute,
          name,
          kind: 'folder',
          t: entry.modified
        });
      } else if (this.isCloudImage(name, 0, entry.contentType)) {
        files.push({
          key: `file:${absolute}`,
          id: absolute,
          name,
          kind: 'image',
          size: entry.size,
          t: entry.modified,
          etag: ''
        });
      }
    }
    folders.sort((a, b) => a.name.localeCompare(b.name, 'zh-CN'));
    files.sort((a, b) => b.t - a.t);
    return {
      type: 'webdav',
      folder: target,
      folders,
      files,
      total: files.length
    };
  }

  isCloudImage(name, category, contentType) {
    if (contentType && /^image\//i.test(contentType)) return true;
    if (Number(category) === 3) return true;
    return isImageName(name);
  }

  async downloadUrl123(cloud, fileId) {
    const key = `${cloud.id}:${fileId}`;
    const cached = this.downloadCache.get(key);
    if (cached && cached.expiresAt > Date.now()) return cached.url;
    // 官方限制 5 QPS，这里做 4/s 的温和节流。
    const wait = Math.max(0, 260 - (Date.now() - this.lastDownloadAt));
    if (wait) await sleep(wait);
    this.lastDownloadAt = Date.now();
    const token = await this.ensureToken(cloud);
    const response = await fetchWithTimeout(`${API_123}/api/v1/file/download_info?fileId=${encodeURIComponent(fileId)}`, {
      headers: {
        Authorization: `Bearer ${token}`,
        Platform: 'open_platform'
      }
    }, 25000);
    const payload = await response.json().catch(() => null);
    if (!response.ok || !payload || payload.code !== 0) {
      const message = (payload && payload.message) || `HTTP ${response.status}`;
      if (payload && payload.code === 5113) {
        throw new CloudError('123云盘今日下载流量已超过 1GB 限制，请升级会员或明天再试', 429);
      }
      throw new CloudError(`获取 123云盘下载地址失败：${message}`);
    }
    const url = payload.data && payload.data.downloadUrl;
    if (!url) throw new CloudError('123云盘没有返回下载地址');
    this.downloadCache.set(key, { url, expiresAt: Date.now() + 8 * 60 * 1000 });
    if (this.downloadCache.size > 500) {
      const first = this.downloadCache.keys().next().value;
      this.downloadCache.delete(first);
    }
    return url;
  }

  async raw(id, kind, value, res) {
    const cloud = this.store.getCloud(id);
    if (!cloud) throw new CloudError('云盘不存在', 404);
    if (cloud.type === '123') {
      const url = await this.downloadUrl123(cloud, value);
      res.writeHead(302, {
        Location: url,
        'Cache-Control': 'private, max-age=300'
      });
      res.end();
      return;
    }
    const response = await fetchWithTimeout(value, {
      headers: {
        Authorization: basicAuth(cloud.data.username, cloud.data.password),
        'User-Agent': 'xphoto/1.0 WebDAV client'
      }
    }, 45000);
    if (!response.ok) throw new CloudError(`WebDAV 图片读取失败：HTTP ${response.status}`);
    const buffer = Buffer.from(await response.arrayBuffer());
    const type = response.headers.get('content-type') || 'application/octet-stream';
    res.writeHead(200, {
      'Content-Type': type,
      'Content-Length': buffer.length,
      'Cache-Control': 'private, max-age=600'
    });
    res.end(buffer);
  }

  async thumb(id, kind, value, version, res, size = 420) {
    const cloud = this.store.getCloud(id);
    if (!cloud) throw new CloudError('云盘不存在', 404);
    let buffer;
    if (cloud.type === '123') {
      const url = await this.downloadUrl123(cloud, value);
      const response = await fetchWithTimeout(url, {}, 45000);
      if (!response.ok) throw new CloudError(`缩略图下载失败：HTTP ${response.status}`);
      buffer = Buffer.from(await response.arrayBuffer());
    } else {
      const response = await fetchWithTimeout(value, {
        headers: {
          Authorization: basicAuth(cloud.data.username, cloud.data.password),
          'User-Agent': 'xphoto/1.0 WebDAV client'
        }
      }, 45000);
      if (!response.ok) throw new CloudError(`缩略图下载失败：HTTP ${response.status}`);
      buffer = Buffer.from(await response.arrayBuffer());
    }
    const key = `cloud|${cloud.id}|${cloud.type}|${value}|${version || ''}`;
    const thumb = await this.media.getBufferThumb(buffer, key, size);
    if (!thumb) throw new CloudError('无法生成缩略图');
    const data = thumb.buffer || await fsp.readFile(thumb.file);
    res.writeHead(200, {
      'Content-Type': 'image/webp',
      'Content-Length': data.length,
      'Cache-Control': 'private, max-age=2592000'
    });
    res.end(data);
  }

  async readCloudFile(cloud, kind, value) {
    if (cloud.type === '123') {
      const url = await this.downloadUrl123(cloud, value);
      const response = await fetchWithTimeout(url, {}, 120000);
      if (!response.ok) throw new CloudError(`下载失败：HTTP ${response.status}`);
      return { buffer: Buffer.from(await response.arrayBuffer()), contentType: 'application/octet-stream' };
    }
    const response = await fetchWithTimeout(value, {
      headers: {
        Authorization: basicAuth(cloud.data.username, cloud.data.password),
        'User-Agent': 'xphoto/1.0 WebDAV client'
      }
    }, 120000);
    if (!response.ok) throw new CloudError(`下载失败：HTTP ${response.status}`);
    return {
      buffer: Buffer.from(await response.arrayBuffer()),
      contentType: response.headers.get('content-type') || 'application/octet-stream'
    };
  }

  async saveToLocal(id, { kind, value, name, folder }) {
    const cloud = this.store.getCloud(id);
    if (!cloud) throw new CloudError('云盘不存在', 404);
    const payload = await this.readCloudFile(cloud, kind, value);
    const dir = this.store.subDir('云盘', safeName(cloud.name), safeName(folder || '根目录'));
    const target = uniqueFile(dir, safeName(name || 'image.jpg'));
    await fsp.writeFile(target, payload.buffer);
    this.store.addDownload({
      source: 'cloud',
      cloud: cloud.name,
      name: path.basename(target),
      path: target,
      size: payload.buffer.length
    });
    return { path: target, name: path.basename(target), size: payload.buffer.length };
  }

  async downloadToResponse(id, { kind, value, name, folder, deviceName, archive = true }, res) {
    const cloud = this.store.getCloud(id);
    if (!cloud) throw new CloudError('云盘不存在', 404);
    const fileName = safeName(name || 'image.jpg');
    const dir = archive
      ? this.store.subDir('云盘', safeName(cloud.name), safeName(folder || '根目录'))
      : null;
    const payload = await this.readCloudFile(cloud, kind, value);
    if (dir) {
      const target = uniqueFile(dir, fileName);
      await fsp.writeFile(target, payload.buffer);
      this.store.addDownload({
        source: 'cloud',
        cloud: cloud.name,
        name: path.basename(target),
        path: target,
        size: payload.buffer.length,
        device: deviceName || ''
      });
    }
    res.writeHead(200, {
      'Content-Type': payload.contentType || 'application/octet-stream',
      'Content-Length': payload.buffer.length,
      'Content-Disposition': `attachment; filename*=UTF-8''${encodeURIComponent(fileName)}`,
      'Cache-Control': 'no-store',
      'X-Xphoto-Saved': archive ? '1' : '0'
    });
    res.end(payload.buffer);
  }
}

module.exports = { CloudManager, CloudError, normalizeBaseUrl };
