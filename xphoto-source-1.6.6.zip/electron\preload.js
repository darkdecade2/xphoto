'use strict';

const { contextBridge, ipcRenderer } = require('electron');

const api = {
  desktop: true,
  platform: process.platform,
  getInfo: () => ipcRenderer.invoke('xphoto:info'),
  pickFolders: () => ipcRenderer.invoke('xphoto:pick-folders'),
  pickFolder: () => ipcRenderer.invoke('xphoto:pick-folder'),
  openDownloads: () => ipcRenderer.invoke('xphoto:open-downloads'),
  openPath: (target) => ipcRenderer.invoke('xphoto:open-path', target),
  reveal: (target) => ipcRenderer.invoke('xphoto:reveal', target),
  copy: (text) => ipcRenderer.invoke('xphoto:copy', text),
  openExternal: (url) => ipcRenderer.invoke('xphoto:open-external', url),
  openFirewall: () => ipcRenderer.invoke('xphoto:open-firewall'),
  setTheme: (theme) => ipcRenderer.invoke('xphoto:set-theme', theme),
  shareChanged: () => ipcRenderer.invoke('xphoto:share-changed'),
  showWindow: () => ipcRenderer.invoke('xphoto:show-window'),
  quit: () => ipcRenderer.invoke('xphoto:quit'),
  onShareChanged: (callback) => {
    const listener = () => callback();
    ipcRenderer.on('xphoto:share-changed', listener);
    return () => ipcRenderer.removeListener('xphoto:share-changed', listener);
  },
  onThemeChanged: (callback) => {
    const listener = (event, theme) => callback(theme);
    ipcRenderer.on('xphoto:theme-changed', listener);
    return () => ipcRenderer.removeListener('xphoto:theme-changed', listener);
  }
};

contextBridge.exposeInMainWorld('xphoto', api);
