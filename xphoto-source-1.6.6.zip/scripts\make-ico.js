﻿const fs = require('fs');
(async () => {
  const mod = require('png-to-ico');
  const pngToIco = mod.default || mod;
  const ico = await pngToIco(['assets/icon-256.png','assets/icon-128.png','assets/icon-64.png','assets/icon-48.png','assets/icon-32.png','assets/icon-16.png']);
  fs.writeFileSync('assets/icon.ico', ico);
  console.log('ico bytes', fs.statSync('assets/icon.ico').size);
})().catch(e => { console.error(e); process.exit(1); });
