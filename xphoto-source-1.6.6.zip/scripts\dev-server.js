'use strict';

const path = require('path');
const fs = require('fs');
const { Store } = require('../server/store');
const { Library } = require('../server/library');
const { MediaService } = require('../server/media');
const { CloudManager } = require('../server/clouds');
const { createAppServer } = require('../server/index');

const dataDir = process.env.XPHOTO_DATA || path.join(__dirname, '..', '.testdata');
const port = Number(process.env.XPHOTO_PORT || 18575);
const rootPath = process.env.XPHOTO_ROOT || path.join(__dirname, '..', '.test-photos');

fs.mkdirSync(dataDir, { recursive: true });
const store = new Store(dataDir);
if (rootPath && fs.existsSync(rootPath) && !store.config.roots.some((root) => path.resolve(root.path) === path.resolve(rootPath))) {
  store.addRoot(rootPath, { name: '示例相册' });
}
const media = new MediaService(store);
const library = new Library(store);
const clouds = new CloudManager(store, media);

const context = {
  store,
  library,
  media,
  clouds,
  port,
  version: require('../package.json').version,
  hooks: {
    pickFolders: async () => [],
    reveal: () => {},
    openPath: () => {},
    openFirewall: async () => ({ started: false, message: '测试环境' }),
    onShareChanged: () => {},
    onSettingsChanged: () => {}
  }
};

const { server } = createAppServer(context);
server.listen(port, '0.0.0.0', () => {
  console.log(`xphoto dev server http://127.0.0.1:${port}/?t=${store.share.token}`);
  console.log(`data: ${dataDir}`);
  console.log(`root: ${rootPath}`);
});
process.on('SIGINT', () => { server.close(() => process.exit(0)); });
process.on('SIGTERM', () => { server.close(() => process.exit(0)); });
